package com.jacquesb.wifimessages;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;

import java.util.*;
import java.lang.*;
import java.nio.*;
import java.math.*;
import java.text.*;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;    
import android.content.Intent;     
import android.content.IntentFilter;    
import android.net.wifi.ScanResult;    
import android.net.wifi.WifiConfiguration;   
import android.net.wifi.WifiManager;    
import android.os.Bundle;    
import android.util.Log;   
import android.view.View;    
import android.view.View.OnClickListener;    
import android.widget.*;
import android.widget.LinearLayout.*;
import android.net.wifi.*;
import android.net.*;

import android.os.*;
import android.os.PowerManager.*;

public class MainActivity extends Activity
{

    public boolean verbose = false;
	MainActivity ma;
	EditText text1;
	TextView textStatus; 
	Button buttonServer, buttonClient, buttonSet, buttonSend;
	EditText editMyId, editParam, editMessages, editTo, editData; 
	Spinner spinnerParam;

	String me = "myuserid";

	public boolean connected;
	public boolean clientRunning;
	
	WakeLock wl;
	
	int maxMessageList = 3000;
	int maxMessageSent = 1000;
	
	long selectedParam = 0;
	
	String ssidPrefix = "WFM";
	int port = 1234;
	// String userId = "me";
	String groups = "";
	
	int scanPeriod = 60;
	
	ServerSocket server;
	
	/*
	public void trace(String s)
	{
		Toast.makeText(this, "WifiClient: " + s, 
			Toast.LENGTH_LONG).show(); 
		text1.append("\nmain: " + s);
		Log.d("WifiClient", s);
	}
	*/

	public void trace (final String s)
	{
		ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					text1.append("\nmain: "+s);
					text1.setSelection(text1.length(), text1.length());
				}
			});
	}
	
	public String encode(String s)
	{
		return s
		.replace("\\","\\\\")
		.replace("\n","\\n")
		.replace("|","\\p");
		
	}
	
	public String decode(String s)
	{
		return s
		.replace("\\n","\n")
		.replace("\\p","|")
		.replace("\\\\","\\");
	}
	
	public void saveParams()
	{
		try
		{
			 PrintWriter out = new PrintWriter(openFileOutput("params.txt", MODE_PRIVATE));
			 out.println(ssidPrefix);
			 out.println(Integer.toString(port));
			 out.println(me);
			 out.println(groups);
			 out.println(Integer.toString(maxMessageList));
			 out.println(Integer.toString(maxMessageSent));
			 out.println(Integer.toString(scanPeriod));
			 out.close();	
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}
	
	public void readParams()
	{
		try
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(openFileInput("params.txt")));
			ssidPrefix = in.readLine();
			port = Integer.parseInt(in.readLine());
			me = in.readLine();
			groups = in.readLine();
			maxMessageList = Integer.parseInt(in.readLine());
			maxMessageSent = Integer.parseInt(in.readLine());
			scanPeriod = Integer.parseInt(in.readLine());
			in.close();
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}
	
	public void saveMessages()
	{
		try
		{
			PrintWriter out = new PrintWriter(openFileOutput("tosend.txt", MODE_PRIVATE)); 
			MessageList l = toSend;
			while (!(l.isEmpty()))
			{
				out.println(l.first.intForm());
				l = l.next;
			}
			out.close();
			out = new PrintWriter(openFileOutput("received.txt", MODE_PRIVATE));
			l = received;
			while (!(l.isEmpty()))
			{
				out.println(l.first.intForm());
				l = l.next;
			}
			out.close();
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}
	
	public void readMessages()
	{
		BufferedReader in = null;
		String line;
		MessageList p, n;
		Message m;
		try
		{
			in = new BufferedReader(new InputStreamReader(openFileInput("tosend.txt")));
			/*
			while (true)
			{
				line = in.readLine();
				trace("toSend: line read: " + line);
				toSend = toSend.add(new Message(line));
			}
			*/
			toSend = new MessageList();
			p = toSend;
			while (true)
			{
				line = in.readLine();
				m = new Message(line);
				n = new MessageList();
				p.first = m;
				p.next = n;
				p = n;
			}
		}
		catch (Exception e1)
		{
			trace(e1.toString());
			try
			{
				in.close();
				in = new BufferedReader(new InputStreamReader(openFileInput("received.txt")));
				/*
				while (true)
				{
					line = in.readLine();
					trace("received: line read: " + line);
					received = received.add(new Message(line));
				}
				*/
				received = new MessageList();
				p = received;
				while (true)
				{
					line = in.readLine();
					m = new Message(line);
					n = new MessageList();
					p.first = m;
					p.next = n;
					p = n;
				}
			}
			catch (Exception e2)
			{
				trace(e2.toString());
				try
				{
					in.close();
				}
				catch (Exception e3)
				{
					trace(e3.toString());
				}
			}
		}
	}
	
	public void wakeLock()
	{
		PowerManager mgr = (PowerManager)this.getSystemService(Context.POWER_SERVICE); 
		wl = mgr.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WifiServerWakeLock");
		wl.acquire();
	}
	
	public void wakeUnlock()
	{
		wl.release();
	}

	public String formatTime(long ms)
	{
		DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(ms);
		return fmt.format(cal.getTime());
	}
	
	public long nowSeconds()
	{
		return System.currentTimeMillis() / 1000;
	}

	public String serverIPAddress()
	{
		
		try
		{
			WifiManager wifi = (WifiManager) getSystemService(WIFI_SERVICE);
			WifiInfo info = wifi.getConnectionInfo();
			int i = info.getIpAddress();
			if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN))
			{
				i = Integer.reverseBytes(i);
			}
			// String ipAddress = Formatter.formatIpAddress(i);
			byte[] b = BigInteger.valueOf(i).toByteArray();
			b[3] = 1;
			InetAddress a = InetAddress.getByAddress(b);
			String s = a.getHostAddress();
			return s;
		
		// s = "ip: " + (i>>24) + "." + ((i>>16)&0xff) + "." + ((i>>8)&0xff) + "." + (i&0xff);
		// s = "ip: "+(b[3]&0xff)+"."+(b[2]&0xff)+"."+(b[1]&0xff)+"."+(b[0]&0xff);
	    // s = s+"\nserver: "+(b[3]&0xff)+"."+(b[2]&0xff)+"."+(b[1]&0xff)+".1";
			
			// text1.setText(s);
		}
		catch(Exception e)
		{
			// text1.setText(e.toString());
			return "";
		}
		
	}

	public class Message
	{
		public String from, to, via, data;
		public long time;
		public boolean isNew;
		
		public Message()
		{
			
		}

		public Message(String line)
		{
			String fields[] = line.split("\\|");
			// Message m = new Message();
			from = decode(fields[0]);
			to = decode(fields[1]);
			// trace("to: " + to);
			via = decode(fields[2]) + ";" + me;
			// trace("via: " + via);
			data = decode(fields[3]);
			// trace("get time "+fields[4]);
			time = Long.parseLong(fields[4]);
			// trace("time: "+time);
			isNew = true;
		}

		public String intForm()
		{
			return encode(from) + "|" +
				encode(to) + "|" +
				encode(via) + "|" +
				encode(data) + "|" +
				new Long(time).toString();
		}
		
		public String extForm()
		{
			return formatTime(time) + " " + from + " to " + to + " : " + data + "\n";
		}
		
		public boolean same(Message m)
		{
			// trace("begin same");
			boolean r;
			r = 
				from.equals(m.from) &&
				to.equals(m.to) &&
				time == m.time;
			// trace("same=" + r + " for " + this + " and " + m);
			return r;
		}
		
		public boolean isForMe()
		{
			int i, j;
			String toArray[] = to.split(",");
			String groupsArray[] = groups.split(",");
			for (i=0; i<toArray.length; i++)
			{
				if (toArray[i].equals(me))
					return true;
				for (j=0; j<groupsArray.length; j++)
				{
					if (toArray[i].equals(groupsArray[j]))
						return true;
				}	
			}
			return false;
		}
	}

	public class MessageList
	{
		public Message first;
		public MessageList next;

		public MessageList()
		{
			first = null;
			next = null;
		}

		public MessageList(Message f, MessageList n) 
		{
			first = f;
			next = n;
		}

		public boolean isEmpty()
		{
			return first == null;
		}

		public MessageList add (Message m)
		{
			trace("add");
			boolean found = false;
			// trace("l");
			MessageList l = this;
			// trace("loop");
			while (!(l.isEmpty()) && !found)
			{
				// trace("in loop");
				if (l.first.same(m))
				{
					// trace("same");
					found = true;
					m.isNew = false;
				}
				else
				{
					// trace("not same");
					l = l.next;
				}
			}
			// trace("found="+found);
			if (found)
			{
				// trace("found, not added: " + m);
				return this;
			}
			// trace("not found, added: " + m);
			truncate(maxMessageList-1);
			// l = new MessageList(m, truncate(3));
			l = new MessageList(m, this);
			// l.truncate(3);
			return l;
		}

		public void truncate(int n)
		{
			if (isEmpty())
				return;
			if (n == 0)
			{
				first = null;
				next = null;
				return;
			}
			next.truncate(n-1);
		}
		
		public MessageList truncate2(int n)
		{
			if (isEmpty())
				return this;
			if (n == 0)
				return new MessageList();
			// return next.truncate(n-1).add(first);
			return new MessageList(first, next.truncate2(n-1));
		}

	}
	
	MessageList toSend, received;
	Message message;
	

	public class ServerTask extends AsyncTask <Void, Void, Void>
	{

		EditText text1;
		MainActivity ma;
		// ServerSocket server;

		public void trace (final String s)
		{
			// Toast.makeText(ma, "Server: " + s, Toast.LENGTH_LONG).show();
			// text1.append("\n" + s);
			ma.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						text1.append("\n(task) "+s);
						text1.setSelection(text1.length(), text1.length());
					}
				});
		}

		public void appendMessage(final String s)
		{
			ma.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						editMessages.append(s);
						editMessages.setSelection(editMessages.length(), editMessages.length());
					}
				});
		}

		public ServerTask (MainActivity ma1)
		{
			super();
			this.ma = ma1;

		}

		@Override
		protected Void doInBackground (Void... params)
		{
			Looper.prepare();

			text1 = (EditText) ma.findViewById(R.id.text1);
			trace("doInBackground");

			try
			{

				// int port = 1234;
				trace("Server");
				server = null;
				try
				{
					server = new ServerSocket(port);
					// server.setSoTimeout(2000);
				}
				catch (Exception e)
				{
					trace("Cannot initialize server: " + e);
				}

				trace("Loop");

				while (true)
				{

					trace("Waiting");
					Socket client = server.accept();
					trace("Connected");

					BufferedReader in = new BufferedReader(
						new InputStreamReader(client.getInputStream()));

					// PrintStream out = new PrintStream(client.getOutputStream());
					PrintWriter out = new PrintWriter(client.getOutputStream(),true); 
					/*
					 trace("Send");
					 out.println("Hello from server");
					 trace("Read");
					 String message = in.readLine();
					 trace ("Received: " + message);
					 // Toast.makeText(this, "Received: " + message, Toast.LENGTH_LONG).show();
					 */

					MessageList l = toSend;
					int i = 0;
					String line;

					// while (l != null)
					while (!(l.isEmpty()))
					{
						if (i >= maxMessageSent) break;
						i++;
						line = l.first.intForm();
						/*
						 l.first.from + "|" +
						 l.first.to + "|" +
						 l.first.via + "|" +
						 l.first.data + "|" +
						 new Long(l.first.time).toString();
						 */
						trace("send: " + line);
						out.println(line);
						l = l.next;
					}
					// out.println("END"); 

					l = received;
					i = 0;
					while (!(l.isEmpty()))
					{
						if (i >= maxMessageSent) break;
						i++;
						line = l.first.intForm();
						/*
						 l.first.from + "|" +
						 l.first.to + "|" +
						 l.first.via + "|" +
						 l.first.data + "|" +
						 new Long(l.first.time).toString();
						 */
						trace("send: " + line);
						out.println(line);
						l = l.next;
					}
					out.println("END"); 

					while (true)
					{
						line = in.readLine();
						trace("received: " + line);
						if (line.equals("END"))
							break;
						/*
						 String fields[] = line.split("\\|");
						 Message m = new Message();
						 m.from = fields[0];
						 m.to = fields[1];
						 trace("to: " + m.to);
						 m.via = fields[2] + ";" + me;
						 m.data = fields[3];
						 m.time = Long.parseLong(fields[4]);
						 m.isNew = true;
						 */
						Message m = new Message(line); 
						/*
						 received = new MessageList(m, received);
						 toSend = new MessageList(m, toSend); 
						 */
						received = received.add(m);
						// received.truncate(3);
						// toSend = toSend.add(m);		
						// toSend.truncate(3); 
						// if (m.isNew && m.to.equals(me))
						if (m.isNew && m.isForMe())
						{
							trace("display message");
							// editMessages.append(m.from + ": " + m.data + "\n");
							appendMessage(formatTime(m.time) + " " + m.from + " to " + m.to + " : " + m.data + "\n");
						}
					}

					saveMessages();

					client.close();
					trace("Disconnected");

				}	


			}
			catch (Exception e)
			{
				// Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
				trace("Exception: " + e); 
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			trace("onPostExecute");
			super.onPostExecute(result);
		}

		@Override
		protected void onPreExecute()
		{

		}

		@Override
		protected void onProgressUpdate(Void... values)
		{

		}


	}
	
	public class ClientTask extends AsyncTask <Void, Void, Void>
	{
		MainActivity ma;
		EditText text1;
		
		public ClientTask (MainActivity ma1)
		{
			super();
			this.ma = ma1;
			text1 = (EditText) ma.findViewById(R.id.text1);
		}
		
		public void trace (final String s)
		{
			ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					text1.append("\nclient: "+s);
					text1.setSelection(text1.length(), text1.length());
				}
			});
		}
		
		public void appendMessage(final String s)
		{
			ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					editMessages.append(s);
					editMessages.setSelection(editMessages.length(), editMessages.length());
				}
			});
		}

		public boolean isNetworkAvailable()
		{
			ConnectivityManager cm = (ConnectivityManager)
			 getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo ni = cm.getActiveNetworkInfo();
			if (ni == null)
				return false;
			return ni.isConnected();
		}
		
		@Override
		protected Void doInBackground(Void... params)
		{
			trace("doInBackground");
			try
			{
				Looper.prepare();
			}
			catch (Exception e)
			{
				trace(e.toString());
			}
			// clientRunning = true;
			
			/*
			{
				StrictMode.ThreadPolicy policy = 
					new StrictMode.ThreadPolicy.Builder().permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}		
			*/

			// text1 = (TextView) findViewById(R.id.text1);

			try
			{
				// int port = 1234;
				String host = serverIPAddress();
				// String host = "192.168.43.1";
				// String host = "localhost";
				// String host = "127.0.0.1";
				
				trace("wait connection");		
				while (!isNetworkAvailable())
				{
					Thread.sleep(1000);
				}
				trace("connected");
				
				clientRunning = true; 
				
				InetAddress server = InetAddress.getByName(host);
				trace("Socket server=" + server + " port=" + port);
				Socket socket = null;
				for (int t=1; t<=6; t++)
				{
					try
					{
						trace("connect trial " + t);
						// socket = new Socket(server, port);
						socket = new Socket();
						socket.connect(new InetSocketAddress(server, port), 20000);
						break;
					}
					catch (Exception e)
					{
						trace("failed: " + e);
						Thread.sleep(1000);
					}
				}
				if (socket == null)
				{
					trace("connect failed");
					return null;
				}
				trace("socket="+socket.toString());
				socket.setSoTimeout(15000);
				trace("in");
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				trace("out");
				PrintWriter out = new PrintWriter(socket.getOutputStream(),true); 
				/*
				trace("Read");
				String message = in.readLine();
				trace("Received: " + message);
				out.println("Hello from client");
				*/

				// MessageList l = toSend;
				String line;
				
				while (true)
				{
					trace("read line");
					line = in.readLine();
					trace("received: " + line);
					if (line.equals("END"))
						break;
					/*
					String fields[] = line.split("\\|");
					Message m = new Message();
					m.from = fields[0];
					m.to = fields[1];
					trace("to: " + m.to);
					m.via = fields[2] + ";" + me;
					trace("via: " + m.via);
					m.data = fields[3];
					trace("get time "+fields[4]);
					m.time = Long.parseLong(fields[4]);
					m.isNew = true;
					trace("time: "+m.time);
					*/
					Message m = new Message(line);
					/*
					received = new MessageList(m, received);
					toSend = new MessageList(m, toSend); 
					*/
					received = received.add(m);
					// toSend = toSend.add(m);
					// if (m.isNew && m.to.equals(me))
					if (m.isNew && m.isForMe())
					{
						trace("display message");
						// editMessages.append(m.from + ": " + m.data + "\n");
						// appendMessage(formatTime(m.time) + " " + m.from + " to " + m.to + " : " + m.data + "\n");
						appendMessage(m.extForm());
					}
				}
				
				saveMessages();
				
				MessageList l = toSend;
				int i = 0;
				trace("before send loop l="+l); 
				// while (l != null)
				while (!l.isEmpty())
				{
					if (i >= maxMessageSent) break;
					i++;
					line = l.first.intForm();
					/*
						l.first.from + "|" +
						l.first.to + "|" +
						l.first.via + "|" +
						l.first.data + "|" +
						new Long(l.first.time).toString();
					*/
					trace("send: " + line);
					out.println(line);
					l = l.next;
				}
				trace("after send loop");

				l = received;
				i = 0;
				trace("before send loop l="+l); 
				// while (l != null)
				while (!l.isEmpty())
				{
					if (i >= maxMessageSent) break;
					i++;
					line = l.first.intForm();
					/*
						l.first.from + "|" +
						l.first.to + "|" +
						l.first.via + "|" +
						l.first.data + "|" +
						new Long(l.first.time).toString();
					*/
					trace("send: " + line);
					out.println(line);
					l = l.next;
				}
				trace("after send loop");
				
				out.println("END"); 

				trace("Close");
				socket.close();
				

			}
			catch (Exception e)
			{
				trace ("Exception: " + e);
			}
			
			clientRunning = false;
			trace("End doInBackground");
			return null;
		}		
	}

	public class WiFiScanReceiver extends BroadcastReceiver 
	{
		private static final String TAG = "WiFiScanReceiver";
		MainActivity ma;
		EditText text1;
		public List<ScanResult> results = null;
		WifiManager wifi;
		boolean scanned;
		long scanTime;
		long now;

		public WiFiScanReceiver(MainActivity ma, WifiManager wifi) 
		{
			super();
			this.ma = ma;
			this.wifi = wifi;
			text1 = (EditText) ma.findViewById(R.id.text1);
			results = new ArrayList<ScanResult>();
			scanned = false;
			scanTime = 0;
		}

		public void trace (final String s)
		{
			ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					text1.append("\nreceiver: " + s);
					text1.setSelection(text1.length(), text1.length());
					// Log.d("WifiClient", "receiver: " + s);
				}
			});
		}

		@Override
		public void onReceive(Context c, Intent intent) 
		{
			/* if (scanned)
				return; */
			if (clientRunning)
				return;
			now = nowSeconds();
			trace("onReceive: now=" + now + " scanTime=" + scanTime + " scanPeriod=" + scanPeriod);
			if (now - scanTime < scanPeriod)
				return; 
			trace("scan at " + now);
			scanTime = now; 
			scanned = true;
			results = wifi.getScanResults();
			ScanResult bestSignal = null;
			// ma.edit1.append("\nSCAN RESULTS:\n"); 
			for (ScanResult result : results) 
			{
				// ma.edit1.append("\n"+result.toString()+"\n"); 
                if (verbose) trace ("result: " + result.toString());
				if (bestSignal == null
				|| WifiManager.compareSignalLevel(bestSignal.level, result.level) < 0)
					bestSignal = result;
				if (result.SSID.startsWith(ssidPrefix))
				{
					// if (!ma.connected)
					{
						WifiConfiguration wc = new WifiConfiguration();
						wc.SSID = "\"" + result.SSID + "\"";
						wc.hiddenSSID = false;
						wc.status = WifiConfiguration.Status.ENABLED;
						// Toast.makeText(ma, wc.toString(), Toast.LENGTH_LONG).show(); 
						if (verbose) trace("wc = " + wc.toString());
						int res = wifi.addNetwork(wc);
						// Toast.makeText(ma, "addNetwork -> " + res, Toast.LENGTH_LONG).show();
						trace("addNetwork -> " + res);
						boolean b = wifi.enableNetwork(res, true);
						// Toast.makeText(ma, "enableNetwork -> " + b, Toast.LENGTH_LONG).show();
						trace("enableNetwork -> " + b);
						ma.connected = true; 
					}
					trace("Client task");
					ClientTask task = new ClientTask(ma);
					trace("execute");
					task.execute();
					trace("done");
				}
			}

			String message = String.format("%s networks found. %s is the strongest.",
				results.size(), bestSignal.SSID);
			// Toast.makeText(ma, message, Toast.LENGTH_LONG).show();
			// Log.d(TAG, "onReceive() message: " + message);
			trace(message);
		}
	}

	public class ScanTask extends AsyncTask <Void, Void, Void>
	{
		MainActivity ma;
		EditText text1;
		
		public ScanTask(MainActivity ma1)
		{
			super();
			this.ma = ma1;
			text1 = (EditText) ma.findViewById(R.id.text1);
		}
		
		public void trace (final String s)
		{
			ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					text1.append("\nscan: " + s);
					text1.setSelection(text1.length(), text1.length());
					// Log.d("WifiClient", "scan: " + s);
				}
			});
		}
		
		@Override
		protected Void doInBackground(Void... params)
		{
			trace("begin doInBackground");
			try
			{
				trace("Get Wi-Fi manager");
				WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
				trace("Get connection info");
				WifiInfo info = wifi.getConnectionInfo();
				trace("Wi-Fi status: " + info.toString());
				List<WifiConfiguration> configs = wifi.getConfiguredNetworks();
				if (verbose)
				for (WifiConfiguration config : configs) 
				{
					trace("config: " + config.toString());
				}			
				trace("Receiver");	
				BroadcastReceiver receiver = new WiFiScanReceiver(ma, wifi);
				trace("register");
				registerReceiver(receiver, new IntentFilter(
					WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
				if (verbose)
				for (ScanResult result : ((WiFiScanReceiver)receiver).results)
				{
					trace("result: " + result.toString()); 
				}
				ma.connected = false;
				trace("start scan");
				wifi.startScan();
				trace("done");

			}
			catch (Exception e)
			{
				trace("Exception: " + e);
			}
			trace("end doInBackground");
			return null;
		}
	}

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		ma = this;
		
		clientRunning = false;

		text1 = (EditText) findViewById(R.id.text1);
		trace("gather the troops");
		textStatus = (TextView) findViewById(R.id.textStatus);
		// editMyId = (EditText) findViewById(R.id.editMyId);
		buttonServer = (Button) findViewById(R.id.buttonServer);
		buttonClient = (Button) findViewById(R.id.buttonClient);
		spinnerParam = (Spinner) findViewById(R.id.spinnerParam);
		editParam = (EditText) findViewById(R.id.editParam);
		buttonSet = (Button) findViewById(R.id.buttonSet);
		editMessages = (EditText) findViewById(R.id.editMessages);
		editTo = (EditText) findViewById(R.id.editTo);
		buttonSend = (Button) findViewById(R.id.buttonSend);
		editData = (EditText) findViewById(R.id.editData);
		
		trace("set listeners");
		

		buttonServer.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// Toast.makeText(ma, "Button Start clicked", Toast.LENGTH_LONG).show();
					trace("button Start");
					wakeLock();
					// me = editMyId.getText().toString();
					ServerTask task = new ServerTask(ma);
					trace("execute task");
					task.execute();
					trace("done Start");
				}

			}); 
		
		buttonClient.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// Toast.makeText(ma, "Button Start clicked", Toast.LENGTH_LONG).show();
					trace("button Client");
					wakeLock();
					// me = editMyId.getText().toString();
					ScanTask task = new ScanTask(ma);
					trace("execute task");
					task.execute();
					trace("done Start");
				}

			}); 

		buttonSend.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// Toast.makeText(ma, "Button Send clicked", Toast.LENGTH_LONG).show();
					trace("button Send");
					message = new Message();
					message.time = System.currentTimeMillis();
					message.from = me;
					message.to = editTo.getText().toString();
					message.via = "";
					message.data = editData.getText().toString();
					toSend = new MessageList(message, toSend);
					// toSend.add(message);
					saveMessages();
					trace("done Send");
				}

			}); 
			
		String params[] = {
				"SSID prefix",
				"Port",
				"User id",
				"Groups",
				"Messages kept",
				"Messages sent",
				"Scan period"};
				
		ArrayAdapter<String> paramAdapter = new ArrayAdapter<String>(this,
			 android.R.layout.simple_spinner_item, params);
		paramAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerParam.setAdapter(paramAdapter); 
			
		spinnerParam.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
			{
				@Override
				public void onItemSelected(AdapterView<?> parent,
				View view, int pos, long id)
				{
					selectedParam = id;
					if (id == 0)
					 editParam.setText(ssidPrefix);
					else if (id == 1)
					 editParam.setText(Integer.toString(port));
					else if (id == 2)
					 editParam.setText(me);
					else if (id == 3)
					 editParam.setText(groups);
					else if (id == 4)
					 editParam.setText(Integer.toString(maxMessageList));
					else if (id == 5)
					 editParam.setText(Integer.toString(maxMessageSent));
					else if (id == 6)
					 editParam.setText(Integer.toString(scanPeriod));
					
					
				}
				 
				public void onNothingSelected(AdapterView<?> parent)
				{
					
				}
			});
			
		buttonSet.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if (selectedParam == 0)
				 ssidPrefix = editParam.getText().toString();
				else if (selectedParam == 1)
				 port = Integer.parseInt(editParam.getText().toString());
				else if (selectedParam == 2)
				 me = editParam.getText().toString();
				else if (selectedParam == 3)
				 groups = editParam.getText().toString();
				else if (selectedParam == 4)
				 maxMessageList = Integer.parseInt(editParam.getText().toString());
				else if (selectedParam == 5)
				 maxMessageSent = Integer.parseInt(editParam.getText().toString());
				else if (selectedParam == 6)
				 scanPeriod = Integer.parseInt(editParam.getText().toString());
				saveParams();
			}
		});
			
			
		trace("...");
		/*
		toSend = null;
		received = null;
		*/
		readParams();
		toSend = new MessageList();
		received = new MessageList();
		readMessages();
		MessageList l = received;
		String s = "";
		while (!(l.isEmpty()))
		{
			if (l.first.isForMe())
			{
				s = l.first.extForm() + s; 
			}
			l = l.next;
		}
		editMessages.setText(s);
		editMessages.setSelection(editMessages.length(), editMessages.length());
		trace("done onCreate");
    }
	

	@Override
	public void onStop(Bundle state)
	{
		try
		{
			server.close();
		}
		catch (Exception e)
		{
			trace("Error closing server socket: " + e);
		}
		wakeUnlock();
		super.onStop();
	}

}

