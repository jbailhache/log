package com.jacquesb.wifiserver;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;

import java.util.*;
import java.text.*;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;    
import android.content.Intent;     
import android.content.IntentFilter;    
import android.net.wifi.ScanResult;    
import android.net.wifi.WifiConfiguration;   
import android.net.wifi.WifiManager;    
import android.os.Bundle;    
import android.util.Log;   
import android.view.View;    
import android.view.View.OnClickListener;    
import android.widget.*;
import android.widget.LinearLayout.*;
import android.net.wifi.*;

import android.os.*;
import android.os.PowerManager.*;

public class MainActivity extends Activity
{
	MainActivity ma;
	EditText text1;
	TextView textStatus; 
	Button buttonStart, buttonSet, buttonSend;
	EditText editMyId, editParam, editMessages, editTo, editData; 
	Spinner spinnerParam;
	
	String me = "myuserid";
	WakeLock wl;
	
	ServerSocket server;
	
	int maxMessageList = 3000;
	int maxMessageSent = 1000;

	long selectedParam = 0;

	String ssidPrefix = "WFM";
	int port = 1234;
	// String userId = "me";
	String groups = "";
	
	/*
	public void trace(String s)
	{
		Toast.makeText(this, "WifiServer: " + s, 
		 Toast.LENGTH_LONG).show(); 
		text1.append("\n" + s);
		Log.d("WifiServer", s);
	}
	*/

	public void trace (final String s)
	{
		// Toast.makeText(ma, "Server: " + s, Toast.LENGTH_LONG).show();
		// text1.append("\n" + s);
		ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					text1.append("\n(main) "+s);
					text1.setSelection(text1.length(), text1.length());
				}
			});
	}

	public String encode(String s)
	{
		return s
		.replace("\\","\\\\")
		.replace("\n","\\n")
		.replace("|","\\p");
	}
	
	public String decode(String s)
	{
		return s
		.replace("\\n","\n")
		.replace("\\p","|")
		.replace("\\\\","\\");
		
	}
	
	public void saveParams()
	{
		try
		{
			PrintWriter out = new PrintWriter(openFileOutput("params.txt", MODE_PRIVATE));
			out.println(ssidPrefix);
			out.println(Integer.toString(port));
			out.println(me);
			out.println(groups);
			out.println(Integer.toString(maxMessageList));
			out.println(Integer.toString(maxMessageSent));
			out.close();	
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}

	public void readParams()
	{
		try
		{
			BufferedReader in = new BufferedReader(new InputStreamReader(openFileInput("params.txt")));
			ssidPrefix = in.readLine();
			port = Integer.parseInt(in.readLine());
			me = in.readLine();
			groups = in.readLine();
			maxMessageList = Integer.parseInt(in.readLine());
			maxMessageSent = Integer.parseInt(in.readLine());
			in.close();
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}

	public void saveMessages()
	{
		try
		{
			PrintWriter out = new PrintWriter(openFileOutput("tosend.txt", MODE_PRIVATE)); 
			MessageList l = toSend;
			while (!(l.isEmpty()))
			{
				out.println(l.first.intForm());
				l = l.next;
			}
			out.close();
			out = new PrintWriter(openFileOutput("received.txt", MODE_PRIVATE));
			l = received;
			while (!(l.isEmpty()))
			{
				out.println(l.first.intForm());
				l = l.next;
			}
			out.close();
		}
		catch (Exception e)
		{
			trace(e.toString());
		}
	}

	public void readMessages()
	{
		BufferedReader in = null;
		String line;
		MessageList p, n;
		Message m;
		try
		{
			in = new BufferedReader(new InputStreamReader(openFileInput("tosend.txt")));
			/*
			 while (true)
			 {
			 line = in.readLine();
			 trace("toSend: line read: " + line);
			 toSend = toSend.add(new Message(line));
			 }
			 */
			toSend = new MessageList();
			p = toSend;
			while (true)
			{
				line = in.readLine();
				m = new Message(line);
				n = new MessageList();
				p.first = m;
				p.next = n;
				p = n;
			}
		}
		catch (Exception e1)
		{
			trace(e1.toString());
			try
			{
				in.close();
				in = new BufferedReader(new InputStreamReader(openFileInput("received.txt")));
				/*
				 while (true)
				 {
				 line = in.readLine();
				 trace("received: line read: " + line);
				 received = received.add(new Message(line));
				 }
				 */
				received = new MessageList();
				p = received;
				while (true)
				{
					line = in.readLine();
					m = new Message(line);
					n = new MessageList();
					p.first = m;
					p.next = n;
					p = n;
				}
			}
			catch (Exception e2)
			{
				trace(e2.toString());
				try
				{
					in.close();
				}
				catch (Exception e3)
				{
					trace(e3.toString());
				}
			}
		}
	}
	
	public void wakeLock()
	{
		PowerManager mgr = (PowerManager)this.getSystemService(Context.POWER_SERVICE); 
		wl = mgr.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WifiServerWakeLock");
		wl.acquire();
	}
	
	public void wakeUnlock()
	{
		wl.release();
	}
	
	public String formatTime(long ms)
	{
		DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(ms);
		return fmt.format(cal.getTime());
	}
	
	public class Message
	{
		public String from, to, via, data;
		public long time;
		public boolean isNew;
		
		public Message()
		{

		}

		public Message(String line)
		{
			String fields[] = line.split("\\|");
			// Message m = new Message();
			from = decode(fields[0]);
			to = decode(fields[1]);
			// trace("to: " + to);
			via = decode(fields[2]) + ";" + me;
			// trace("via: " + via);
			data = decode(fields[3]);
			// trace("get time "+fields[4]);
			time = Long.parseLong(fields[4]);
			// trace("time: "+time);
			isNew = true;
		}

		public String intForm()
		{
			return encode(from) + "|" +
				encode(to) + "|" +
				encode(via) + "|" +
				encode(data) + "|" +
				new Long(time).toString();
		}
		
		public String extForm()
		{
			return formatTime(time) + " " + from + " to " + to + " : " + data + "\n";
		}
		
		public boolean same(Message m)
		{
			return 
			 from.equals(m.from) &&
			 to.equals(m.to) &&
			 time == m.time;
		}

		public boolean isForMe()
		{
			int i, j;
			String toArray[] = to.split(",");
			String groupsArray[] = groups.split(",");
			for (i=0; i<toArray.length; i++)
			{
				if (toArray[i].equals(me))
					return true;
				for (j=0; j<groupsArray.length; j++)
				{
					if (toArray[i].equals(groupsArray[j]))
						return true;
				}	
			}
			return false;
		}
	}

	public class MessageList
	{
		public Message first;
		public MessageList next;

		public MessageList()
		{
			first = null;
			next = null;
		}

		public MessageList(Message f, MessageList n) 
		{
			first = f;
			next = n;
		}

		public boolean isEmpty()
		{
			return first == null;
		}

		public MessageList add (Message m)
		{
			trace("add");
			boolean found = false;
			// trace("l");
			MessageList l = this;
			// trace("loop");
			while (!(l.isEmpty()) && !found)
			{
				// trace("in loop");
				if (l.first.same(m))
				{
					// trace("same");
					found = true;
					m.isNew = false;
				}
				else
				{
					// trace("not same");
					l = l.next;
				}
			}
			// trace("found="+found);
			if (found)
			{
				// trace("found, not added: " + m);
				return this;
			}
			// trace("not found, added: " + m);
			truncate(maxMessageList-1);
			// l = new MessageList(m, truncate(3));
			l = new MessageList(m, this);
			// l.truncate(3);
			return l;
		}

		public void truncate(int n)
		{
			if (isEmpty())
				return;
			if (n == 0)
			{
				first = null;
				next = null;
				return;
			}
			next.truncate(n-1);
		}

		public MessageList truncate2(int n)
		{
			if (isEmpty())
				return this;
			if (n == 0)
				return new MessageList();
			// return next.truncate(n-1).add(first);
			return new MessageList(first, next.truncate2(n-1));
		}
	}
	
	MessageList toSend, received;
	Message message;
	

	public class ServerTask extends AsyncTask <Void, Void, Void>
	{

		EditText text1;
		MainActivity ma;

		public void trace (final String s)
		{
			// Toast.makeText(ma, "Server: " + s, Toast.LENGTH_LONG).show();
			// text1.append("\n" + s);
			ma.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						text1.append("\n(task) "+s);
						text1.setSelection(text1.length(), text1.length());
					}
				});
		}
		
		public void appendMessage(final String s)
		{
			ma.runOnUiThread(new Runnable()
			{
				@Override
				public void run()
				{
					editMessages.append(s);
					editMessages.setSelection(editMessages.length(), editMessages.length());
				}
			});
		}

		public ServerTask (MainActivity ma1)
		{
			super();
			this.ma = ma1;

		}

		@Override
		protected Void doInBackground (Void... params)
		{
			Looper.prepare();

			text1 = (EditText) ma.findViewById(R.id.text1);
			trace("doInBackground");

			try
			{

				// int port = 1234;
				trace("Server");
				server = null;
				try
				{
					server = new ServerSocket(port);
					// server.setSoTimeout(2000);
				}
				catch (Exception e)
				{
					trace("Cannot initialize server: " + e);
				}

				trace("Loop");

				while (true)
				{

					trace("Waiting");
					Socket client = server.accept();
					trace("Connected");

					BufferedReader in = new BufferedReader(
						new InputStreamReader(client.getInputStream()));

					// PrintStream out = new PrintStream(client.getOutputStream());
					PrintWriter out = new PrintWriter(client.getOutputStream(),true); 
					/*
					trace("Send");
					out.println("Hello from server");
					trace("Read");
					String message = in.readLine();
					trace ("Received: " + message);
					// Toast.makeText(this, "Received: " + message, Toast.LENGTH_LONG).show();
					*/
					
					MessageList l = toSend;
					int i = 0;
					String line;
					
					// while (l != null)
					while (!(l.isEmpty()))
					{
						if (i >= maxMessageSent) break;
						i++;
						line = l.first.intForm();
						/*
						 l.first.from + "|" +
						 l.first.to + "|" +
						 l.first.via + "|" +
						 l.first.data + "|" +
						 new Long(l.first.time).toString();
						*/
						trace("send: " + line);
						out.println(line);
						l = l.next;
					}
					// out.println("END"); 
					
					l = received;
					i = 0;
					while (!(l.isEmpty()))
					{
						if (i >= maxMessageSent) break;
						i++;
						line = l.first.intForm();
						/*
							l.first.from + "|" +
							l.first.to + "|" +
							l.first.via + "|" +
							l.first.data + "|" +
							new Long(l.first.time).toString();
						*/
						trace("send: " + line);
						out.println(line);
						l = l.next;
					}
					out.println("END"); 
					
					while (true)
					{
						line = in.readLine();
						trace("received: " + line);
						if (line.equals("END"))
							break;
						/*
						String fields[] = line.split("\\|");
						Message m = new Message();
						m.from = fields[0];
						m.to = fields[1];
						trace("to: " + m.to);
						m.via = fields[2] + ";" + me;
						m.data = fields[3];
						m.time = Long.parseLong(fields[4]);
						m.isNew = true;
						*/
						Message m = new Message(line); 
						/*
						received = new MessageList(m, received);
						toSend = new MessageList(m, toSend); 
						*/
						received = received.add(m);
						// received.truncate(3);
						// toSend = toSend.add(m);		
						// toSend.truncate(3); 
						// if (m.isNew && m.to.equals(me))
						if (m.isNew && m.isForMe())
						{
							trace("display message");
							// editMessages.append(m.from + ": " + m.data + "\n");
							appendMessage(formatTime(m.time) + " " + m.from + " to " + m.to + " : " + m.data + "\n");
						}
					}
					
					saveMessages();

					client.close();
					trace("Disconnected");

				}	


			}
			catch (Exception e)
			{
				// Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
				trace("Exception: " + e); 
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			trace("onPostExecute");
			super.onPostExecute(result);
		}

		@Override
		protected void onPreExecute()
		{

		}

		@Override
		protected void onProgressUpdate(Void... values)
		{

		}


	}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		ma = this;
		
		text1 = (EditText) findViewById(R.id.text1);
		trace("gather the troops");
		textStatus = (TextView) findViewById(R.id.textStatus);
		// editMyId = (EditText) findViewById(R.id.editMyId);
		buttonStart = (Button) findViewById(R.id.buttonStart);
		spinnerParam = (Spinner) findViewById(R.id.spinnerParam);
		editParam = (EditText) findViewById(R.id.editParam);
		buttonSet = (Button) findViewById(R.id.buttonSet);
		editMessages = (EditText) findViewById(R.id.editMessages);
		editTo = (EditText) findViewById(R.id.editTo);
		buttonSend = (Button) findViewById(R.id.buttonSend);
		editData = (EditText) findViewById(R.id.editData);
		
		trace("set listeners");
		buttonStart.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// Toast.makeText(ma, "Button Start clicked", Toast.LENGTH_LONG).show();
					trace("button Start");
					wakeLock();
					// me = editMyId.getText().toString();
					ServerTask task = new ServerTask(ma);
					trace("execute task");
					task.execute();
					trace("done Start");
				}

			}); 
			
		buttonSend.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// Toast.makeText(ma, "Button Send clicked", Toast.LENGTH_LONG).show();
					trace("button Send");
					message = new Message();
					message.time = System.currentTimeMillis();
					message.from = me;
					message.to = editTo.getText().toString();
					message.via = "";
					message.data = editData.getText().toString();
					toSend = new MessageList(message, toSend);
					saveMessages();
					trace("done Send");
				}

			}); 

		String params[] = {
			// "SSID prefix",
			"Port",
			"User id",
			"Groups",
			"Messages kept",
			"Messages sent"};

		ArrayAdapter<String> paramAdapter = new ArrayAdapter<String>(this,
		 android.R.layout.simple_spinner_item, params);
		paramAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerParam.setAdapter(paramAdapter); 
		
		spinnerParam.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
			{
				@Override
				public void onItemSelected(AdapterView<?> parent,
										   View view, int pos, long id)
				{
					selectedParam = id;
					// if (id == 0)
					//	editParam.setText(ssidPrefix);
					// else 
					if (id == 0)
						editParam.setText(Integer.toString(port));
					else if (id == 1)
						editParam.setText(me);
					else if (id == 2)
						editParam.setText(groups);
					else if (id == 3)
						editParam.setText(Integer.toString(maxMessageList));
					else if (id == 4)
						editParam.setText(Integer.toString(maxMessageSent));


				}

				public void onNothingSelected(AdapterView<?> parent)
				{

				}
			});

		buttonSet.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					// if (selectedParam == 0)
					//	ssidPrefix = editParam.getText().toString();
					// else 
					if (selectedParam == 0)
						port = Integer.parseInt(editParam.getText().toString());
					else if (selectedParam == 1)
						me = editParam.getText().toString();
					else if (selectedParam == 2)
						groups = editParam.getText().toString();
					else if (selectedParam == 3)
						maxMessageList = Integer.parseInt(editParam.getText().toString());
					else if (selectedParam == 4)
						maxMessageSent = Integer.parseInt(editParam.getText().toString());
					saveParams();
				}
			});
		
		trace("...");
		/*
		toSend = null;
		received = null;
		*/
		readParams();
		toSend = new MessageList();
		received = new MessageList(); 
		readMessages();
		MessageList l = received;
		String s = "";
		while (!(l.isEmpty()))
		{
			if (l.first.isForMe())
				s = l.first.extForm() + s;
			l = l.next;
		}
		editMessages.setText(s);
		editMessages.setSelection(editMessages.length(), editMessages.length()); 
	
		trace("done onCreate");
		
    }
	
	@Override
	public void onStop(Bundle state)
	{
		try
		{
			server.close();
		}
		catch (Exception e)
		{
			trace("Error closing server socket: " + e);
		}
		wakeUnlock();
		super.onStop();
	}
}
