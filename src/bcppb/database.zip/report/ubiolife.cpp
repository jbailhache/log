//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ubiolife.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TBiolifeDM *BiolifeDM;
//---------------------------------------------------------------------------
__fastcall TBiolifeDM::TBiolifeDM(TComponent* Owner)
        : TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
