//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ureport.h"
#include "ubiolife.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TQRListForm *QRListForm;
//--------------------------------------------------------------------- 
__fastcall TQRListForm::TQRListForm(TComponent* AOwner)
	: TQuickRep(AOwner)
{
}
//--------------------------------------------------------------------- 
