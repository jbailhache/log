//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("report.res");
USEFORM("uform.cpp", Form1);
USEFORM("ureport.cpp", QRListForm); /* TQuickRep: DesignClass */
USEFORM("ubiolife.cpp", BiolifeDM); /* TDataModule: DesignClass */
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TQRListForm), &QRListForm);
                 Application->CreateForm(__classid(TBiolifeDM), &BiolifeDM);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
