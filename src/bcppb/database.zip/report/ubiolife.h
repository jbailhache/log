//---------------------------------------------------------------------------
#ifndef ubiolifeH
#define ubiolifeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
//---------------------------------------------------------------------------
class TBiolifeDM : public TDataModule
{
__published:	// IDE-managed Components
        TTable *Table1;
        TDataSource *DataSource1;
private:	// User declarations
public:		// User declarations
        __fastcall TBiolifeDM(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TBiolifeDM *BiolifeDM;
//---------------------------------------------------------------------------
#endif
