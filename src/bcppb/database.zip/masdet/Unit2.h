//----------------------------------------------------------------------------
#ifndef Unit2H
#define Unit2H
//----------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Windows.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <Controls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <DB.hpp>
#include <DBTables.hpp>
#include <Db.hpp>
//----------------------------------------------------------------------------
class TDataModule2 : public TDataModule
{
__published:
	TFloatField *Query1CustNo;
	TStringField *Query1Company;
	TStringField *Query1Addr1;
	TStringField *Query1Addr2;
	TStringField *Query1City;
	TStringField *Query1State;
	TStringField *Query1Zip;
	TStringField *Query1Country;
	TStringField *Query1Phone;
	TStringField *Query1FAX;
	TFloatField *Query1TaxRate;
	TStringField *Query1Contact;
	TDateTimeField *Query1LastInvoiceDate;
	TFloatField *Query2OrderNo;
	TDateTimeField *Query2SaleDate;
	TDateTimeField *Query2ShipDate;
	TIntegerField *Query2EmpNo;
	TStringField *Query2ShipToContact;
	TStringField *Query2ShipToAddr1;
	TStringField *Query2ShipToAddr2;
	TStringField *Query2ShipToCity;
	TStringField *Query2ShipToState;
	TStringField *Query2ShipToZip;
	TStringField *Query2ShipToCountry;
	TStringField *Query2ShipToPhone;
	TStringField *Query2ShipVIA;
	TStringField *Query2PO;
	TStringField *Query2Terms;
	TStringField *Query2PaymentMethod;
	TCurrencyField *Query2ItemsTotal;
	TFloatField *Query2TaxRate;
	TCurrencyField *Query2Freight;
	TCurrencyField *Query2AmountPaid;
	TDataSource *DataSource1;
	TQuery *Query1;
	TQuery *Query2;
	TDataSource *DataSource2;
	void __fastcall DataModuleCreate(TObject *Sender);
private:
	// private declarations
public:
	// public declarations
	__fastcall TDataModule2(TComponent *Owner);
};
//----------------------------------------------------------------------------
extern TDataModule2 *DataModule2;
//----------------------------------------------------------------------------
#endif
