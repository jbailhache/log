//----------------------------------------------------------------------------
#ifndef masdetuH
#define masdetuH
//----------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Windows.hpp>
#include <Messages.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBCtrls.hpp>
#include <DB.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Mask.hpp>
//----------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:
	TScrollBox *ScrollBox;
	TLabel *Label1;
	TDBEdit *EditCustNo;
	TLabel *Label2;
	TDBEdit *EditCompany;
	TLabel *Label3;
	TDBEdit *EditAddr;
	TLabel *Label4;
	TDBEdit *EditAddr2;
	TLabel *Label5;
	TDBEdit *EditCity;
	TLabel *Label6;
	TDBEdit *EditState;
	TLabel *Label7;
	TDBEdit *EditZip;
	TLabel *Label8;
	TDBEdit *EditCountry;
	TLabel *Label9;
	TDBEdit *EditPhone;
	TLabel *Label10;
	TDBEdit *EditFAX;
	TLabel *Label11;
	TDBEdit *EditTaxRate;
	TLabel *Label12;
	TDBEdit *EditContact;
	TLabel *Label13;
	TDBEdit *EditLastInvoiceDate;
	TDBGrid *DBGrid1;
	TDBNavigator *DBNavigator;
	TPanel *Panel1;
	TPanel *Panel2;
	TPanel *Panel3;
private:
	// private declarations
public:
	// public declarations
	__fastcall TForm3(TComponent *Owner);
};
//----------------------------------------------------------------------------
extern TForm3 *Form3;
//----------------------------------------------------------------------------
#endif
