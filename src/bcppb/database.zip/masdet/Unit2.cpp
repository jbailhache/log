//----------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//----------------------------------------------------------------------------
#pragma resource "*.dfm"
TDataModule2 *DataModule2;
//----------------------------------------------------------------------------
__fastcall TDataModule2::TDataModule2(TComponent *Owner)
	: TDataModule(Owner)
{
}
//----------------------------------------------------------------------------
void __fastcall TDataModule2::DataModuleCreate(TObject *Sender)
{
	Query1->Open();
	Query2->Open();
}
//---------------------------------------------------------------------------- 