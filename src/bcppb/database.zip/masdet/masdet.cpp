//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("masdet.res");
USEFORM("Unit1.cpp", Form1);
USEFORM("Unit2.cpp", DataModule2); /* TDataModule: DesignClass */
USEFORM("masdetu.cpp", Form3);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm3), &Form3);
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TDataModule2), &DataModule2);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
