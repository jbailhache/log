//----------------------------------------------------------------------------
#ifndef formH
#define formH
//----------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Windows.hpp>
#include <Messages.hpp>
#include <Classes.hpp>
#include <Graphics.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <DBCtrls.hpp>
#include <DB.hpp>
#include <Db.hpp>
#include <DBTables.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
//----------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:
	TFloatField *Table1SpeciesNo;
	TStringField *Table1Category;
	TStringField *Table1Common_Name;
	TStringField *Table1SpeciesName;
	TFloatField *Table1Lengthcm;
	TFloatField *Table1Length_In;
	TMemoField *Table1Notes;
	TGraphicField *Table1Graphic;
	TScrollBox *ScrollBox;
	TLabel *Label1;
	TDBEdit *EditSpeciesNo;
	TLabel *Label2;
	TDBEdit *EditCategory;
	TLabel *Label3;
	TDBEdit *EditCommon_Name;
	TLabel *Label4;
	TDBEdit *EditSpeciesName;
	TLabel *Label5;
	TDBEdit *EditLengthcm;
	TLabel *Label6;
	TDBEdit *EditLength_In;
	TLabel *Label7;
	TDBEdit *EditNotes;
	TLabel *Label8;
	TDBEdit *EditGraphic;
	TDBNavigator *DBNavigator;
	TPanel *Panel1;
	TDataSource *DataSource1;
	TPanel *Panel2;
	TTable *Table1;
	void __fastcall FormCreate(TObject *Sender);
private:
	// private declarations
public:
	// public declarations
	__fastcall TForm2(TComponent *Owner);
};
//----------------------------------------------------------------------------
extern TForm2 *Form2;
//----------------------------------------------------------------------------
#endif
