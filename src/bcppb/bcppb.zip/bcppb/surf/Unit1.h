//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <NMHTML.hpp>
#include <OleCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TTabControl *tcURL;
        TPanel *Panel1;
        TPanel *Panel2;
        TBitBtn *bbGo;
        TBitBtn *bbHome;
        TComboBox *cbURL;
        THTML *htBrowser;
        void __fastcall tcURLChange(TObject *Sender);
        void __fastcall htBrowserBeginRetrieval(TObject *Sender);
        void __fastcall htBrowserEndRetrieval(TObject *Sender);
        void __fastcall bbGoClick(TObject *Sender);
        void __fastcall bbHomeClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
