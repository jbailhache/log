//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

String HomePage = "file:///c:/log/log.htm";

TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::tcURLChange(TObject *Sender)
{
        cbURL->Text = tcURL->Tabs->Strings[tcURL->TabIndex];
        cbURL->SelectAll();
        bbGo->Click();

}
//---------------------------------------------------------------------------

void __fastcall TForm1::htBrowserBeginRetrieval(TObject *Sender)
{
        Cursor = (TCursor) crHourGlass;
        if (cbURL->Items->IndexOf (htBrowser->URL) == -1)
        {
                cbURL->Items->Add (htBrowser->URL);
                cbURL->Text = htBrowser->URL;
                cbURL->SelectAll();
                tcURL->Tabs->Add (htBrowser->URL);
                tcURL->TabIndex = tcURL->Tabs->Count-1;
                bbGo->Click();
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::htBrowserEndRetrieval(TObject *Sender)
{
        Cursor = (TCursor) crDefault;        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bbGoClick(TObject *Sender)
{
        htBrowser->RequestDoc (cbURL->Text);        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::bbHomeClick(TObject *Sender)
{
        htBrowser->RequestDoc (HomePage);
}
//---------------------------------------------------------------------------
