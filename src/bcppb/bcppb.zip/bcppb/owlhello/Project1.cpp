//---------------------------------------------------------------------------

/*
#include <vcl.h>
#pragma hdrstop
USERES("Project1.res");
USEFORM("Unit1.cpp", Form1);
*/


//---------------------------------------------------------------------------

#include <OWLFiles\owl\applicat.h>
#include <OWLFiles\owl\framewin.h>

/*#pragma hdrstop*/

class TestWindow : public TWindow
{
public:
        TestWindow() : TWindow(0,0,0) {}
protected:
        void Paint (TDC&, bool, TRect&);
};

void TestWindow::Paint (TDC& dc, bool, TRect&)
{
        TRect rect = GetClientRect();
        dc.DrawText ("Hello World !", -1, rect,
                DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

class TestApp : public TApplication
{
public:
        TestApp() : TApplication ("") {}
        void InitMainWindow ()
        {
                TFrameWindow *frame = new TFrameWindow (0,
                        "OWL Hello World", new TestWindow);
                SetMainWindow (frame);
        }
};

int OwlMain  (int, char * [])
{
        return TestApp().Run();
}

//---------------------------------------------------------------------------

WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
TApplication ap;
        ap = new TestApp();
        try
        {
                 ap->Initialize();
                 ap->CreateForm(__classid(TForm1), &Form1);
                 /* Application->Run(); */
                 /* TestApp().Run(); */
                 ap->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}



