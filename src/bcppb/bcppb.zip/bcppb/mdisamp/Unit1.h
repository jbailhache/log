//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TMainMenu *MainMenu;
        TMenuItem *File1;
        TMenuItem *Exit1;
        TMenuItem *N1;
        TMenuItem *PrintSetup1;
        TMenuItem *Print1;
        TMenuItem *N2;
        TMenuItem *SaveAs1;
        TMenuItem *Save1;
        TMenuItem *Open1;
        TMenuItem *New1;
        TMenuItem *Edit1;
        TMenuItem *Object1;
        TMenuItem *Links1;
        TMenuItem *N3;
        TMenuItem *GoTo1;
        TMenuItem *Replace1;
        TMenuItem *Find1;
        TMenuItem *N4;
        TMenuItem *PasteSpecial1;
        TMenuItem *Paste1;
        TMenuItem *Copy1;
        TMenuItem *Cut1;
        TMenuItem *N5;
        TMenuItem *Repeatcommand1;
        TMenuItem *Undo1;
        TMenuItem *Window1;
        TMenuItem *Show1;
        TMenuItem *Hide1;
        TMenuItem *N6;
        TMenuItem *ArrangeAll1;
        TMenuItem *Cascade1;
        TMenuItem *Tile1;
        TMenuItem *NewWindow1;
        TMenuItem *Help1;
        TMenuItem *About1;
        TMenuItem *HowtoUseHelp1;
        TMenuItem *Tutorial1;
        TMenuItem *SearchforHelpOn1;
        TMenuItem *Keyboard1;
        TMenuItem *Procedures1;
        TMenuItem *Commands1;
        TMenuItem *Index1;
        TMenuItem *Contents1;
        TOpenDialog *OpenDialog;
        TSaveDialog *SaveDialog;
        void __fastcall Open1Click(TObject *Sender);
        void __fastcall SaveAs1Click(TObject *Sender);
        void __fastcall Tile1Click(TObject *Sender);
        void __fastcall Cascade1Click(TObject *Sender);
        void __fastcall ArrangeAll1Click(TObject *Sender);
        void __fastcall About1Click(TObject *Sender);
        void __fastcall Exit1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
