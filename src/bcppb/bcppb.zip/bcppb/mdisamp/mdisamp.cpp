//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("mdisamp.res");
USEFORM("Unit1.cpp", MainForm);
USEFORM("MDIChild.cpp", Child);
USEFORM("PVAbout.cpp", AboutBox);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TMainForm), &MainForm);
                 Application->CreateForm(__classid(TChild), &Child);
                 Application->CreateForm(__classid(TAboutBox), &AboutBox);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
