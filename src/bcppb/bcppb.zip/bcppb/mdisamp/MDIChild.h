//---------------------------------------------------------------------------
#ifndef MDIChildH
#define MDIChildH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TChild : public TForm
{
__published:	// IDE-managed Components
        TImage *Image;
private:	// User declarations
public:		// User declarations
        __fastcall TChild(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TChild *Child;
//---------------------------------------------------------------------------
#endif
