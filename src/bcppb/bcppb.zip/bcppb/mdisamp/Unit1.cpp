//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "MDIChild.h"
#include "PVAbout.h"
//---------------------------------------------------------------------------
/*#pragma package(smart_init)*/
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Open1Click(TObject *Sender)
{
        if (OpenDialog->Execute())
        {
                TChild *child = new TChild (this);
                child->Parent = this;
                child->Image->Picture->LoadFromFile (OpenDialog->FileName);
                child->ClientWidth = child->Image->Picture->Width;
                child->ClientHeight = child->Image->Picture->Height;
                child->Caption = OpenDialog->FileName;
                child->Show();
        }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::SaveAs1Click(TObject *Sender)
{
        TChild *child = dynamic_cast<TChild *> (ActiveMDIChild);
        if (!child)
                return;
        if (SaveDialog->Execute())
        {
                child->Image->Picture->SaveToFile (SaveDialog->FileName);
        }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Tile1Click(TObject *Sender)
{
        Tile ();        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::Cascade1Click(TObject *Sender)
{
        Cascade ();        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::ArrangeAll1Click(TObject *Sender)
{
        ArrangeIcons();        
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::About1Click(TObject *Sender)
{
        AboutBox->ShowModal();        
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Exit1Click(TObject *Sender)
{
        Application->Terminate ();
}
//---------------------------------------------------------------------------

