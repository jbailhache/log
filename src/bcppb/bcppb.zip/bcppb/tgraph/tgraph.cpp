//---------------------------------------------------------------------------
#include <vcl.h>
#include <math.h>

#pragma hdrstop

#include "tgraph.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

float f (float x)
{
        return 100 + 50 * sin (x / 10);
}

void __fastcall TForm1::FormCreate(TObject *Sender)
{
/*
        Windows::TBitmap *bitmap = new Windows::TBitmap ();
        bitmap->Width = 300;
        bitmap->Height = 200;
        Image1->Picture->Graphic = bitmap;

        HDC hdc;
        hdc = GetDC (this);
        */
        Canvas->Pen->Color = clRed;
}

void __fastcall TForm1::FormPaint (TObject *Sender)
{
        for (int x=1; x<300; x++)

                /* bitmap-> */
                /*Canvas->Pixels[x][100+50*sin((float)x/10)] = clRed;*/
                /*SetPixel (hdc, x, f(x), clRed);*/
                Canvas->LineTo (x, f(x));

}


//---------------------------------------------------------------------------
