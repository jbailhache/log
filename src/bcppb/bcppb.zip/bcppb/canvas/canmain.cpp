//----------------------------------------------------------------------------
//Borland C++Builder
//Copyright (c) 1987, 1998 Borland International Inc. All Rights Reserved.
//----------------------------------------------------------------------------
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "canmain.h"
#include "math.h"
#include <stdlib.h>
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	Canvas->Pen->Color = clTeal;
}
//---------------------------------------------------------------------
void __fastcall TForm1::FormPaint(TObject *Sender)
{
	int centerX = ClientWidth / 2;
	int centerY = ClientHeight / 2;
	int radius = min(centerY, centerX);

	Canvas->Ellipse(0, 0, radius*2, radius*2);

        Canvas->MoveTo(10, 30);

        Canvas->LineTo(40, 80);

        int x, y;
        for (x=1; x<60; x++)
        for (y=1; y<40; y++)
                Canvas->Pixels[x][y] = x * y;

	// A challenge:  Turn the rotating figure into a ball that bounces off the
	// walls of the window.  Don't forget the english (spin) on the ball should
	// pick up when bouncing off the wall...
}
//---------------------------------------------------------------------
