//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TMyThread : public TThread
{
private:
protected:
        void __fastcall Execute();
public:
        __fastcall TMyThread(bool CreateSuspended, int n);
        int Param;
};
//---------------------------------------------------------------------------
#endif
 