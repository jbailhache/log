//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"

#include <stdio.h>

#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TMyThread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
__fastcall TMyThread::TMyThread(bool CreateSuspended, int n)
        : TThread(CreateSuspended)
{
        Param = n;
        Priority = tpNormal;
}
//---------------------------------------------------------------------------
void __fastcall TMyThread::Execute()
{
        //---- Place thread code here ----
        printf ("Hello from thread, Param=%d\n", Param);
}
//---------------------------------------------------------------------------
 