
#include <condefs.h>
#pragma hdrstop

#include "Unit1.h"

//---------------------------------------------------------------------------
USEUNIT("Unit1.cpp");
//---------------------------------------------------------------------------
#pragma argsused
int main(int argc, char* argv[])
{
        TMyThread *thread1 = new TMyThread (false, 3);

        return 0;
}
