//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"

#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
char buf[60];
int total;

        total = 0;
        Query1->DisableControls();
        try
        {
                Query1->First ();
                while (!Query1->Eof)
                {
                        /* process record */
                        /* total += Query1->FieldValues["WEIGHT"].AsType(varInteger); */
                        total += Query1->FieldByName("WEIGHT")->AsInteger;
                        Query1->Next();
                }
        }
        __finally
        {
                Query1->EnableControls();
        }
        sprintf (buf, "Total : %d", total);
        Edit1->Text = buf;
}
//---------------------------------------------------------------------------
 