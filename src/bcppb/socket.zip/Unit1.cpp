//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"

#include <stdio.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ButtonGetClick(TObject *Sender)
{
TWinSocketStream *Stream;
char buf[30000];

        ClientSocket->Host = EditHost->Text;
        ClientSocket->Port = 80;
        ClientSocket->Open();

        Stream = new TWinSocketStream (ClientSocket->Socket, 60000);

        sprintf (buf, "GET %s\r\n", EditFile->Text.c_str());
        Stream->Write (buf, strlen(buf)+1);

        Stream->Read (buf, sizeof(buf));
        MemoCont->Text = buf;

        ClientSocket->Close();


}
//---------------------------------------------------------------------------
 