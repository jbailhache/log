//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        Table1->SetKey ();
        /*Table1->Fields[0]->AsString = Edit1->Text;*/
        Table1->FieldByName("ByCompany")->AsString = Edit1->Text;
        Table1->GotoNearest();
        Edit2->Text = Table1->FieldByName("Addr1")->AsString;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
        Query1->Active = False;
        Query1->ParamByName("pays")->AsString = Edit3->Text;
        Query1->Active = True;
                
}
//---------------------------------------------------------------------------
