
#ifndef _STATICLD_H
#define _STATICLD_H

#if defined (BUILD_DLL)
#       define DLL_EXP __declspec(dllexport)
#else
#       if defined (BUILD_APP)
#               define DLL_EXP __declspec(dllimport)
#       else
#               define DLL_EXP
#       endif
#endif

extern "C" void DLL_EXP SayHello (HWND);

class DLL_EXP MyClass
{
        public:
                MyClass (HWND hwnd);
                void SaySomething (char *text);
                void Beep ();
        private:
                HWND hWnd;
};

#endif