//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Db.hpp>
#include <DBGrids.hpp>
#include <DBTables.hpp>
#include <Grids.hpp>
#include <ActnList.hpp>
#include <DBActns.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <StdActns.hpp>
#include <ToolWin.hpp>
#include <DBCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TTable *Table1;
        TStatusBar *StatusBar1;
        TDataSource *DataSource1;
        TDBGrid *DBGrid1;
        TImageList *ImageList1;
        TActionList *ActionList1;
        TDataSetFirst *DataSetFirst1;
        TDataSetLast *DataSetLast1;
        TDataSetNext *DataSetNext1;
        TDataSetPrior *DataSetPrior1;
        TEditCopy *EditCopy1;
        TEditCut *EditCut1;
        TEditPaste *EditPaste1;
        TMainMenu *MainMenu1;
        TMenuItem *File1;
        TMenuItem *Save1;
        TMenuItem *N1;
        TMenuItem *Exit1;
        TMenuItem *Edit1;
        TMenuItem *Cut1;
        TMenuItem *Copy1;
        TMenuItem *Paste1;
        TMenuItem *Record1;
        TMenuItem *First1;
        TMenuItem *Prior1;
        TMenuItem *Next1;
        TMenuItem *Last1;
        TToolBar *ToolBar1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton5;
        TToolButton *ToolButton6;
        TToolButton *ToolButton7;
        TToolButton *ToolButton8;
        TPanel *Panel1;
        TDBImage *DBImage1;
        TDBMemo *DBMemo1;
        TDBText *DBText1;
        TSaveDialog *SaveDialog1;
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall Exit1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
