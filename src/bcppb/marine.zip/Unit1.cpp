//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Save1Click(TObject *Sender)
{
FILE *outfile;
char buf[120];
        sprintf (buf, "Save info for: %s", DBText1->Field->AsString.c_str());
        SaveDialog1->Title = buf;
        if (SaveDialog1->Execute())
        {
                outfile = fopen (SaveDialog1->FileName.c_str(), "wt");
                if (outfile)
                {
                        fprintf (outfile, "Facts on the %s\n\n",
                                DBText1->Field->AsString.c_str());
                        for (int i=0; i<DBGrid1->FieldCount; i++)
                                fprintf (outfile, "%s: %s\n",
                                        DBGrid1->Fields[i]->FieldName.c_str(),
                                        DBGrid1->Fields[i]->AsString.c_str());
                                fprintf (outfile, "\n%s\n", DBMemo1->Text.c_str());
                }
                fclose (outfile);
        }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
        Close();        
}
//---------------------------------------------------------------------------
