//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("testdb.res");
USEFORM("Unit1.cpp", Form1);
USEFILE("..\..\..\Program Files\Borland\CBuilder4\Lib\Obj\dbtables.dcu");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
