package com.jacquesb.wifiserver;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity
{
    MainActivity ma;
    TextView textStatus; 
	Button buttonStart, buttonSend;
	EditText editMessages, editTo, editMessage; 
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		ma = this;
		
		textStatus = (TextView) findViewById(R.id.textStatus);
		buttonStart = (Button) findViewById(R.id.buttonStart);
		editMessages = (EditText) findViewById(R.id.editMessages);
		editTo = (EditText) findViewById(R.id.editTo);
		buttonSend = (Button) findViewById(R.id.buttonSend);
		editMessage = (EditText) findViewById(R.id.editMessage);
		
		buttonStart.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					Toast.makeText(ma, "Button Start clicked", Toast.LENGTH_LONG).show();
					
				}

			}); 
			
		buttonSend.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					Toast.makeText(ma, "Button Send clicked", Toast.LENGTH_LONG).show();
					
				}

			}); 
    }
}
