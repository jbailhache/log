g++ -o cvm-linux-interp -DINTERP cvm.cpp dbg.cpp target.cpp
 

