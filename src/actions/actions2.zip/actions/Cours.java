
public class Cours
{
 public int annee, mois, jour, heure, min;
 public String nomAction;
 public float cours;
}

