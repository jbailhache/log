
public class LigneProgression
{
 public String nomAction;
 public double reference, cours, progression;
}
 