
public class Parametres
{
 public int nDatesChoix;
 public double seuil;
 public String ordre; // saisie alphabetique progression
 public String ordreActions; // saisie alphabetique
 public int maxDateRef;
 public int nEnregs;
}


