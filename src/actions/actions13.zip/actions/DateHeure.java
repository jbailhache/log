
public class DateHeure
{
 public int annee, mois, jour, heure, min;
}
