arm-linux-gnueabi-gcc -static -w -g -DLINUX -DCONSOLE -o minischeme-android maincsl.c mslpia-mpf.c ext-linux.c -lm
