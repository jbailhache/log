RMail is a java library for sending and receiving e-mail messages with Mime extensions (attachments, html ...). Some features are:

- SMTP (sending) and POP3 (receiving) protocols.
- Attachments supported, images, programs, videos ... (base64 encoding).
- you can send HTML also.
- Special characters (� , � , � .... common in languages other than english) supported (quoted-printable encoding).
-Alternative parts supported. You can send an email with two parts, one plain text and the other HTML. The recipient will be able to select which one he/she wants to see. 
- in general full mime 1.0 support on sending and receiving.
- Several recipients, copy , blind copy , reply-to ..... User defined fields supported.
- compatible with jdk 1.1 and 1.2
- furthermore you get the source code on registration.


ABOUT THIS VERSION

The unregistered version add a copyright notice to outgoing messages.
The unregistered version can retrieve up to 4 messages per POP connection.


LICENSE

You may use the product for you personal use providing that you include a link in your web page or application. 

Commercial use (or if you need the source code) require registration.

QUESTIONS, COMMENTS ...

In case of questions, comments... you can contact the author to RReport@confluencia.net

REGISTRATION

If you are interested in the product please check http:\\www.java4less.com or send an e-mail to java4less@confluencia.net

On registration you will get the source code.

--------------------------------------------------------------------------------------