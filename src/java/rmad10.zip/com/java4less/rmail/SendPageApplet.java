//  RMail
//  Copyright (C)
//
//  java4less@Confluencia.net
//  All rights reserved
//
// Adquisition , use and distribution of this code is subject to restriction:
//  - You may modify the source code in order to adapt it to your needs.
//  - Redistribution of this ( or a modifed version) source code is prohibited. You may only redistribute compiled versions.
//  - You may not remove this notice from the source code
//  - This notice disclaim all warranties of all material
//
package com.java4less.rmail;

import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import  com.java4less.rmime.*;

/**

<p>This sample applet sends a html page per e-mail. The parameters are:</p>
<ul>
  <li>SMTP_SERVER: smtp server.</li>
  <li>MY_MAIL: e-mail address of the sender.</li>
  <li>MY_COMPUTER: computer address/name of the sender</li>
  <li>SUBJECT: subject of the mail</li>
  <li>TEXT: text of the body.</li>
  <li>PAGE_URL: Page to send.</li>
  <li>RMAIL:SERVLET: The address of the servlet. For example: &quot;<a href="http://localhost:8080/servlet/RMailServlet">http://localhost:8080/servlet/RMailServlet</a>&quot;.
    This is used to run the applet as a client of a servlet.</li>
</ul>
<p>The size of the applet must be 188*55.</p>
<p><b>Warning: </b>This applet can be used in a web page however the user needs
to have a smtp connection available.</p>

 */
public class SendPageApplet extends Applet implements ActionListener, ProgressSMTPListener, MouseListener
{
	
	Label lblTo=new Label("To: ");
	TextField To= new TextField();
	Label lblStatus=new Label("");
	RButton cmdSend= new RButton("send.gif","Send");
	
	String smtpServer="";
	String smtpMyComputer="";
	String smtpMyemail="";
	String eMailSubject="";
	String eMailText="";
	String myURL="http://rreport.8m.com";
	String myPageURL="http://rreport.8m.com/entry_e_ma.htm";
	int sendCount=0;
	String servletURL="";
	
	public void init() {
		
	  smtpServer=getStringParam("SMTP_SERVER","this.getCodeBase().getHost()");
	  smtpMyemail=getStringParam("MY_MAIL","");
	  smtpMyComputer=getStringParam("MY_COMPUTER","127.0.0.1");
	  eMailSubject=getStringParam("SUBJECT","Recommended page");
	  eMailText=getStringParam("TEXT","");
	  myPageURL=getStringParam("PAGE_URL",this.getDocumentBase().toString());
	  servletURL=getStringParam("RMAIL_SERVLET","");  
	  
	  if (smtpServer.length()==0) smtpServer=this.getCodeBase().getHost();	  
	  if (smtpMyComputer.length()==0) smtpMyComputer="127.0.0.1";
		
	  if (smtpServer.length()==0) smtpServer="127.0.0.1"; 
	  
	  this.setBackground(java.awt.Color.lightGray);
	  
	  this.setSize(180,55);
				   
      this.setLayout(null);
	  
	  
	  lblStatus.addMouseListener(this);
	  
	  // labels
	  lblTo.setBackground(java.awt.Color.lightGray);
	  lblStatus.setBackground(java.awt.Color.lightGray);
	  lblStatus.setForeground(java.awt.Color.blue);
	  lblStatus.setText("Courtesy of "+myURL);
	  
	  lblTo.setBounds(40,5,20,20);
	  lblStatus.setBounds(5,30,170,20);
	  
	  lblTo.setFont(new Font("Arial",Font.BOLD,12));
	  lblStatus.setFont(new Font("Arial",Font.PLAIN,10));
	  
	  this.add(lblTo);

	  
	  // fields  
	  To.setBounds(60,5,115,20);
	    
	  To.setFont(new Font("Arial",Font.PLAIN,12));

	  
	  this.add(To);
	  this.add(lblStatus);
	  
	  // buttons	  
	  cmdSend.setBounds(5,5,30,25);
	  cmdSend.setActionCommand("SEND");
	  cmdSend.addActionListener(this);
	  
	  this.add(cmdSend);

	
	}
	
	private String[] splitAddress(String add) {
      String[] a=new String[100];
		int count=0;
		int p;
					   
	    p=add.indexOf(";");
		while (p>0) {
			if (add.substring(0,p).length()>0) a[count++]=add.substring(0,p);
			add=add.substring(p+1,add.length());
			p=add.indexOf(";");
		}
		
		if (add.length()>0) a[count++]=add;
		
		String[] result=new String[count];
		for (int i=0;i<count;i++) result[i]=a[i];
		
		return result;
	}
	
	public void progressText(String t) {
		 lblStatus.setText(t);
	}
	
	
   // normalize a POST parameter	
   private String normalizeParam(String param) {
	    int p;
		
		// remove & from value 
		p=param.indexOf("&");
		while (p!=-1) {
			param=param.substring(0,p)+" "+param.substring(p+1,param.length());
			p=param.indexOf("&");
		}
		
		return param;
		
   }
	
   public void sendMsgViaServlet() {
	
	  // avoid spamming
	  sendCount++;
	  if (sendCount>3) lblStatus.setText("Reload page. More than 3 mails not allowed.");
			   
		
	  try {
		  
		lblStatus.setText("Opening: "+servletURL);	  
	   // connect to servlet	   
	   URL url = new URL(servletURL);
	   URLConnection connection = url.openConnection();
	   connection.setDoOutput(true);
	   
	   lblStatus.setText("Posting to: "+servletURL);	

	    PrintWriter out = new PrintWriter(
                              connection.getOutputStream());
		
        String requestStr;
	    requestStr="to=" + normalizeParam(To.getText())+"&";
		requestStr=requestStr+"subject=" + normalizeParam(eMailSubject)+"&";
		requestStr=requestStr+"body=" + normalizeParam(eMailText)+"&";
		requestStr=requestStr+"sendUrl=" +normalizeParam( myPageURL);
	    out.println(requestStr);
	    out.close();
		
		lblStatus.setText("Waiting for response: "+servletURL);		

		// read response from servlet
	    BufferedReader in = new BufferedReader(
				new InputStreamReader(
				connection.getInputStream()));
	     String inputLine;

	    while ((inputLine = in.readLine()) != null)
	       lblStatus.setText(inputLine);

	    in.close();
	
     } catch (Exception e) {lblStatus.setText(e.getMessage());}

	}	
	
	public void sendMsg() {
		// avoid spamming
		sendCount++;
		if (sendCount>3) lblStatus.setText("Reload page. More than 3 mails not allowed.");
		
		MailMsg msg =new MailMsg();
		MailMsgPart attach= new MailMsgPart();
		MailMsgPart body= new MailMsgPart();
		
		msg.liste=this;
		
		msg.smtpServer=smtpServer;
		msg.smtpMyAddress=this.smtpMyComputer;
		msg.from=this.smtpMyemail;
		msg.subject=eMailSubject;
		
		// to
		String[] to=splitAddress(To.getText());
		for (int i=0;i<to.length;i++) msg.addRecipient(to[i]);
		
		if (eMailText.length()>0) {
		  // add text
		  body.setData(eMailText,MimeEncoder.NO_ENCODE);
		  msg.addPart(body);
		}
		
		// add html page as attachment
		
			
		  // try to load the html page in a string
		   String htmlPage="";
		   
		   try { 
			   
		     // open URL
			 byte[] b=new byte[1]; 
		     InputStream IS=null;
			 
			 if (myPageURL.length()==0)
			    IS= this.getDocumentBase().openStream();
			 else 
				IS=new java.net.URL(myPageURL).openStream();  
			 
		     while (IS.available()>0) {
			   IS.read(b); // read 1 byte at a time  
		       htmlPage=htmlPage+ ((char) b[0]);	   
		     }
		     IS.close();
		   
		     // create new part for the e mail message
		   
		    attach.ContentType="Text"; 
		    attach.ContentSubType="html"; // the new part will be html
		    attach.setData(htmlPage,MimeEncoder.BASE64);
		    msg.addPart(attach);	
		   }
		   catch (Exception e) {}
		   
		
		
		if (msg.mail()!=0)lblStatus.setText("disconnected. "+lblStatus.getText());
		else lblStatus.setText("disconnected. OK");
	}
	
  private String getStringParam(String Param,String def) {

      return this.getParameter(Param, def);

    }


  //Get a parameter value
  public String getParameter(String key, String def) {
    if (getParameter(key) != null) return getParameter(key) ;
    else return def;
  }	
	
	public void actionPerformed(ActionEvent a) {
		String action=a.getActionCommand();

		
		if (action.compareTo("SEND")==0) {
			 if (servletURL.length()==0) sendMsg();
			 else sendMsgViaServlet();
		}		
		
	}
	
	public void mousePressed(MouseEvent e) {
	}
	public void mouseReleased(MouseEvent e) {
	}
	public void mouseEntered(MouseEvent e) {
		 lblStatus.setForeground(java.awt.Color.red);
	}
	public void mouseExited(MouseEvent e) {
		lblStatus.setForeground(java.awt.Color.blue);
	}
	public void mouseClicked(MouseEvent e) {
		try{
		  this.getAppletContext().showDocument(new java.net.URL(myURL));
		} catch (Exception e1){}
	}
	
	
}
