import com.java4less.rmail.*;
import com.java4less.rmime.*;

public class SmtpApp
{
	
	public static void main(String[] args) {
		
	  PopServer pop= new PopServer();
	  MailMsg m;
	  MailMsgPart p=new MailMsgPart();
  
	  // HOW TO SEND AN E-MAIL
	  m=new MailMsg();
	  m.from="user@mycompany.com";
	  m.addRecipient("user2@mycompany.com");
	  m.subject="Test";
	  
	  //create body
	  p.setData("This is a test message",MimeEncoder.QUOTED);
	  m.addPart(p);
	 // m.addFile(new java.io.File("d:\\mydocument.doc"));

	  m.smtpServer="smtp.mycompany.com";
	  m.mail();
	  
	  // HOW TO RECEIVE 
	  
	  pop.connect("pop.mycompany.com","user","psw");
	  for (int i=1;i<=pop.msgs;i++) {
		   m=pop.retrieveMsg(i);
		   pop.deleteMsg(i);
		   
		   // do here something with the message m
	  }
	  pop.disconnect();
	  
	}
	
}
