
import java.sql.*;

public class compteur
{

	public static int get (String name) 
	throws java.sql.SQLException
	{
		int compteur;
		db db1 = new db ("postes");
		ResultSet rec;
		rec = db1.st.executeQuery (
			"SELECT * FROM Compteur WHERE Nom = '"
			+ name + "'");
		if (rec.next())
			compteur = rec.getInt ("Valeur");
		else
			compteur = 0;
		db1.st.close();
		return compteur;
	}

	public static int put (String name, int value)
	throws java.sql.SQLException
	{
		db db1 = new db ("postes");
		int rowsUpdated = db1.st.executeUpdate (
			"UPDATE Compteur SET Valeur = "
			+ value + " WHERE Nom = '" + name + "'");
		db1.st.close();
		return rowsUpdated;
	}

	public static int incr (String name)
	throws java.sql.SQLException
	{
		return put (name, get(name) + 1);
	} 
}
