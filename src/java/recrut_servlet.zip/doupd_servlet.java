
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
 
public class doupd_servlet extends HttpServlet
{
	static ResultSet rec;
	static PrintWriter out;

	public static void trace (String s)
	{
		System.out.println ("trace doupd: " + s); 
		out.println ("trace doupd: " + s + "<br>"); 
	}

	public static int analyze (String line, String vars[], String vals[])
	{
		String line1;
		int i;
		int j;
                int k;
		line1 = line;
		i = 0;
		for (;;)
		{
			trace ("var #" + i);

			j = line1.indexOf ('=');
			if (j == -1)
				return i;
			k = line1.indexOf ('&');
			vars[i] = line1.substring (0, j);
			trace ("var \"" + vars[i] + "\"");
			if (k == -1)
			{
				vals[i] = util.decode(line1.substring (j+1));
				return i+1;
			}
			vals[i] = util.decode(line1.substring (j+1, k));
			trace ("val \"" + vals[i] + "\"");
			i++;
			line1 = line1.substring (k+1);
		}
	}

        public static void display (int n, String vars[], String vals[])
	{
		for (int i=0; i<n; i++)
		{
			System.out.println (vars[i] + " = " + vals[i] + "<br>");
		}
	}

	public static String update_query (int n, String ref, String reference, String vars[], String vals[])
	{
		String query;
		query = "UPDATE Postes SET " + /*vars[3]*/ "Reference" + " = '" + util.quotequote(/*vals[3]*/ reference) + "'";
		for (int i=/*4*/0; i<n; i++)
		{
			if (!(vals[i].equals("")))
				query = query + " , " + vars[i] + " = '" + util.quotequote(vals[i]) + "'";
		}
		query = query + " WHERE Reference = '" + /*vals[2]*/ ref + "'";
		return query;
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			html.header (out, "Enregistrement de la modification");

			String inLine;
			String newtext;
			String ref_update;
			int ln;
			String vars[];
			String vals[];
			int n;
			String query;
			int rowsUpdated;
			
			n = 0;

			vars = new String[20];
			vals = new String[20];

			util u = new util();

			ref_update = "";
			newtext = "";

			String ref = "";
			String reference = "";
			String username = "";
			String password = "";
			boolean identif;

			Enumeration values = request.getParameterNames();
			while (values.hasMoreElements())
			{
				String name = (String)values.nextElement();
				/* trace ("name=" + name + "."); */
				String value = request.getParameterValues(name)[0];
				/* trace ("value=" + value + "."); */
				trace (name + "=" + value);
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
				else if (name.equals ("Reference1"))
					ref = value;
				else if (name.equals ("Reference"))
					reference = value;
				else
				{
					vars[n] = name;
					vals[n] = value;
					n++;
				}
			}
			
/*
			BufferedReader in = new BufferedReader
    				(new InputStreamReader(System.in));
 
			for (ln=0; ln<1; ln++)
			{
				inLine = in.readLine ();
				System.out.println ("read:" + inLine + "."); 
 		
				if (inLine.length() > 9)	
				if (inLine.substring(0,9).equals("Username="))
				{
					System.out.println ("Data : \"" + inLine + "\"");
					n = analyze (inLine, vars, vals);
					display (n, vars, vals);
					break;
 					
				}
 			}
 
			System.out.println ("Ident :" + vals[0] + "/" + vals[1] + ".");
			boolean identif = ident.check (vals[0], vals[1]);
*/
			int status = ident.check (username, password);
			identif = status > 0;

			if (!identif)
			{
				out.println ("Vous n'&ecirc;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es");
			}
			else
			{
 			db db1 = new db ("postes");
			trace ("update");

 			if (/*vals[2]*/ref.equals(""))
			{
				query = "INSERT INTO Postes (Reference) VALUES ('" + util.quotequote(/*vals[3]*/ reference) + "')";
				trace ("SQL query : " + query);
				rowsUpdated = db1.st.executeUpdate (query);			
				trace (rowsUpdated + " rows updated.");				
 				/* vals[2] = vals[3]; */
				ref = reference;
 			}
			query = update_query (n, ref, reference, vars, vals);
			/* System.out.println ("<p>SQL query : " + query + "<p>"); */
			trace ("SQL query : " + query);
			rowsUpdated = db1.st.executeUpdate (query);
			trace (rowsUpdated + " rows updated.");
			out.println ("Modification enregistr&eacute;e");

				out.println ("<form method=\"POST\" action=\"recrut\">");
				out.println ("<input type=\"hidden\" name=\"Username\" value=\"" + username + "\">");
				out.println ("<input type=\"hidden\" name=\"Password\" value=\"" + password + "\">");
				out.println ("<input type=\"submit\" value=\"Continuer\">"); 			     

			}			
	  	}
		catch (Exception e)
		{
			System.out.println (e.getMessage());
		}
		html.trailer (out);
	
 	}
}
