
import java.sql.*;

public class db
{
	public static Statement st;
	public static Connection co;
	
	db (String dbname)
	{
		try
		{
			String data = "jdbc:odbc:" + dbname;
	 		Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");

			co = DriverManager.getConnection (data, "", "");
			st = co.createStatement ();
		}
		catch (Exception e)
		{
			System.out.println ("Cannot access database " + dbname + " : " + e.getMessage());
		}
	}

	public static void commit ()
	{
		try
		{
			st.close();
			st = co.createStatement ();
		}
		catch (Exception e)
		{
			System.out.println ("Error recreating statement : " + e.getMessage());
		}
	}

}
