
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class download_servlet extends HttpServlet
{
	static PrintWriter out;

	public static void trace (String text)
	{
		System.out.println ("trace download: " + text); 
		out.println ("trace download: " + text + "<br>"); 
	}

	public static void link (String prog, String name, String username, String password)
	{
		out.println ("<form method=\"POST\" action=\""
			+ prog + "\">");
		out.println ("<input name=\"Username\" type=\"hidden\" value=\"" 
			+ username + "\">");
		out.println ("<input name=\"Password\" type=\"hidden\" value=\"" 
			+ password + "\">");
		out.println ("<input type=\"submit\" value=\""
			+ name + "\">");
		out.println ("</form>");
	}

	public static int analyze (String line, String vars[], String vals[])
	{
		String line1;
		int i;
		int j;
                int k;
		line1 = line;
		i = 0;
		for (;;)
		{
			/* trace ("var #" + i); */

			j = line1.indexOf ('=');
			if (j == -1)
				return i;
			k = line1.indexOf ('&');
			vars[i] = line1.substring (0, j);
			/* trace ("var \"" + vars[i] + "\""); */
			if (k == -1)
			{
				vals[i] = util.decode(line1.substring (j+1));
				return i+1;
			}
			vals[i] = util.decode(line1.substring (j+1, k));
			/* trace ("val \"" + vals[i] + "\""); */
			i++;
			line1 = line1.substring (k+1);
		}
	}


	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		

		try
		{
			/* En-tete HTML */
			/* out.println ("<HTML><head><title>Recrutement</title></head><body>"); */
			
			String username;
			String password;
			boolean identif;

			out = response.getWriter(); 

			ident id = new ident ();
			/* identif = id.read_id (request); */
			int status = id.read_id1 (request);
			trace ("status = " + status);
			identif = status > 0;
			trace ("identif = " + identif);
			username = id.username;
			trace ("username = " + username);
			password = id.password;
			trace ("password = " + password);

			if (!identif) 
 			{
				// set content type and other response header fields first
        			response.setContentType("text/html");

				// then write the data of the response
				/* out = response.getWriter(); */

				html.header (out, "Acc&egrave; refus&eacute;");
				out.println ("Identification incorrecte");
				html.trailer (out);
			}
			else
			{
				// set content type and other response header fields first
        			/* response.setContentType("application/x-compress"); */
        			/* response.setContentType("application/ms-dos");  */
        			/* response.setContentType("image/bmp"); */	
				/* response.setContentType("multipart/form-data"); */

				// then write the data of the response

				/*				
				out = response.getWriter();

				FileInputStream f = new FileInputStream ("C:\\jacques\\test.exe");
				boolean eof = false;
				while (!eof)
				{
					int octet = f.read();
					if (octet == -1)
						eof = true;
					else
					{
						char car = (char) octet;
						out.print (car);
						*//* System.out.print (" " + octet); *//*
					}
				}
				*/

				/* out = response.getWriter(); */

				html.header (out, "Download");

				trace ("status = " + status);

				if ((status & 1) != 0)
					out.println ("<a href=\"http://localhost/Download/arch.exe\">T&eacute;l&eacute;chargement du logiciel</a>");				

				if ((status & 2) != 0)
				{
					trace ("Gestion des comptes");
					out.println ("<p>Gestion des comptes");



					db db1 = new db ("postes"); 

					ResultSet rec = db1.st.executeQuery ("SELECT * FROM Ident");

					out.println ("<form method=\"POST\" action=\"doupd_id\">");

					out.println ("<input type=\"submit\" value=\"Enregistrer\">");

					out.println ("<input name=\"Username\" type=\"hidden\" value=\"" + username + "\">");
					out.println ("<input name=\"Password\" type=\"hidden\" value=\"" + password + "\">");

					out.println ("<table border=\"1\"><caption>Gestion des comptes</caption>");
					out.println ("<tr>");
					out.println ("<td> Username </td>");
					out.println ("<td> Password </td>");
					out.println ("<td> Status </td>");

					int i = 0;
					while (rec.next())
					{
						i++;

						out.println ("<tr>");
						/*
						System.out.println ("<td>" + rec.getString ("Username") + "</td>");
						System.out.println ("<td>" + rec.getString ("Password") + "</td>");
						System.out.println ("<td>" + rec.getLong ("Status") + "</td>");
						*/
								
						out.println ("<td><input name=\"Username" + i + "\" value=\"" + rec.getString ("Username") + "\"></td>");
						out.println ("<td><input name=\"Password" + i + "\" value=\"" + rec.getString ("Password") + "\"></td>");
						out.println ("<td><input name=\"Status" + i + "\" value=\"" + rec.getLong ("Status") + "\"></td>");

						out.println ("</tr>");
						
					}
					
					for (int j=i+1; j<i+21; j++)
					{
						out.println ("<tr>");

						out.println ("<td><input name=\"Username" + j + "\" value=\"\"></td>");
						out.println ("<td><input name=\"Password" + j + "\" value=\"\"></td>");
						out.println ("<td><input name=\"Status" + j + "\" value=\"\"></td>");

						out.println ("</tr>");
						
					}
					out.println ("</form>");
		
				



				}
				
				html.trailer (out);
				

			}
 		}
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer (out);
		out.close();
	}

	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		doGet (request, response);
	}


}
