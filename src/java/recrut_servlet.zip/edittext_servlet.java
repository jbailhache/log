
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class edittext_servlet extends HttpServlet
{
	static ResultSet rec;
	static PrintWriter out;
 
	public static void trace (String text)
	{
		System.out.println ("trace edittext: " + text);  
		out.println ("trace edittext: " + text + "<br>"); 
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		String profil;

		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			String username;
			String password;
			boolean identif;

			ident id = new ident ();
			identif = id.read_id (request);
			username = id.username;
			password = id.password;

			if (identif == false)
			{
				html.header (out, "Acc&egrave;s refus&eacute;");
				System.out.println ("Vous n'&egrave;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es.");
			}
			else
			{

			html.header (out, "Modification du texte de pr&eacute;sentation");

			db db1 = new db ("postes"); 
  			rec = db1.st.executeQuery (
				"SELECT * FROM Presentation");  

			out.println ("Modifiez le texte puis cliquez sur le bouton ci-dessous :");

			out.println ("<form method=\"POST\" action=\"savetext\">");
			out.println ("<input name=\"Username\" type=\"hidden\" value=\"" + username + "\">");
			out.println ("<input name=\"Password\" type=\"hidden\" value=\"" + password + "\">");

			out.println ("<input type=\"submit\" value=\"Enregistrer\"><p>");
			out.println ("<textarea name=\"Texte\" cols=80 rows=20>");
			while (rec.next())
			{
				String line = rec.getString ("Ligne");
				out.println (line); 				
			}
			out.println ("</textarea><p>");
			out.println ("</form>");

			db1.st.close();
			}
		}
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer (out);
	}

}
