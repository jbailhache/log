
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ident
{
	public static String username;
	public static String password;

	public static void trace (String text)
	{
		/* System.out.println ("trace ident: " + text); */
		/* out.println ("trace ident: " + text + "<br>"); */
	}

        public static int check (String username, String password)
	{
	    trace ("check (" + username + "," + password + ")");
	    try
	    {
		boolean ok;
		db db1 = new db ("postes");
		ResultSet rec;
		rec = db1.st.executeQuery ("SELECT * FROM Ident WHERE Username = '" 
			+ username + "' AND Password = '" + password + "'");
		trace ("avant next");
		ok = rec.next();
		trace ("apr�s next");
		int status = (int) rec.getLong ("Status"); 
		trace ("status=" + status);
		db1.st.close();
		/* return ok; */
		if (ok)
			return status;
		else
			return 0;
	    }
	    catch (Exception e)
	    {
		/* return false; */
		trace ("exception " + e.getMessage()); 
		return 0;
	    }
	}

        public static /*boolean*/ int read_id1 ()
	{
		String inLine;
		String vars[] = new String[3];
		String vals[] = new String[3];
		/*
		String username;
		String password;
		*/
		/* boolean identif; 

		identif = false; */

		int identif = 0;

		try
		{			
			username = "";
			password = "";

			BufferedReader in = new BufferedReader
    				(new InputStreamReader(System.in));

			inLine = in.readLine ();
			System.out.println ("read:" + inLine + "."); 
			trace ("read:" + inLine + ".");			

			if (inLine == null)
			{
				System.out.println ("No data");
				trace ("No data");
				identif = 0;
			}
			else
			{
				doupd_cgi.analyze (inLine, vars, vals);
				username = vals[0];
				password = vals[1];
				/* System.out.println ("<p>Username :" + username + ".<p>Password :" + password + "."); */
				trace ("<p>Username :" + username + ".<p>Password :" + password + "."); 
				/*identif*/ int status = check (username, password);
				trace ("status = " + status);
				if (status > 0)
					identif = status;
				else
					identif = -1;
				trace ("identif = " + identif);

                                /* if (identif)
					System.out.println ("Identification correcte");
				else
                                        System.out.println ("Acc�s refus�"); */
			}
		}
		catch (Exception e)
		{
			System.out.println ("Error in read_id : " 
				+ e.getMessage());
		}
		return identif;			
	} 

	public static boolean read_id ()
	{
		return read_id1() > 0;
	}

        public static /*boolean*/ int read_id1 (HttpServletRequest req)
	{
                /*
                boolean identif;
		identif = false;
                */

		trace ("read_id1...");
                int identif = 0;

		try 
		{
			Enumeration values = req.getParameterNames();
			while(values.hasMoreElements()) 
			{
                		String name = (String)values.nextElement();
				trace ("name=" + name + ".");
				String value = req.getParameterValues(name)[0];
				trace ("value=" + value + ".");
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
            		}
 	
			/* System.out.println ("<p>Username :" + username + ".<p>Password :" + password + "."); */
			trace ("<p>Username :" + username + ".<p>Password :" + password + "."); 

			/*identif*/ int status = check (username, password);
			trace ("status =  " + status);

			if (status > 0)
				identif = status;
			else
				identif = -1;
			trace ("identif = " + identif);

                        /* if (identif)
				System.out.println ("Identification correcte");
			else
                                System.out.println ("Acc�s refus�"); */
		}
		catch (Exception e)
		{
			System.out.println ("Error in read_id : " 
				+ e.getMessage());
		}
		return identif;			
	} 

	public static boolean read_id (HttpServletRequest req)
	{
		return read_id1(req) > 0;
	}

	 
}
