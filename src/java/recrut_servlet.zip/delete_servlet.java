
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class delete_servlet extends HttpServlet
{
	static PrintWriter out;

	public static void trace (String text)
	{
		System.out.println ("trace delete: " + text);  
		out.println ("trace delete: " + text + "<br>"); 
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{

		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{	
			String username;
			String password;
			boolean identif;

			ident id = new ident ();
			identif = id.read_id (request);
			username = id.username;
			password = id.password;

			if (identif == false)
			{
				html.header (out, "Acc&egrave;s refus&eacute;");
				out.println ("Vous n'&egrave;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es.");
			}
			else
			{
				String ref = /*args[0]*/ request.getParameter ("Reference"); 
				html.header (out, "Suppression poste " + ref);
				db db1 = new db ("postes");
				String query = "DELETE FROM Postes WHERE Reference = '" + ref + "'";
				/* System.out.println ("SQL query : " + query + "<p>"); */
				int status = db1.st.executeUpdate (query);
				/* System.out.println ("Status = " + status + "<p>"); */

				out.println ("Poste " + ref + " supprim&eacute;<p>");
					
				out.println ("<form method=\"POST\" action=\"recrut\">");
				out.println ("<input type=\"hidden\" name=\"Username\" value=\"" + username + "\">");
				out.println ("<input type=\"hidden\" name=\"Password\" value=\"" + password + "\">");
				out.println ("<input type=\"submit\" value=\"Continuer\">"); 			     

			}
		}
		catch (Exception e)
		{
			out.println ("Erreur : " + e.getMessage());
		}
		html.trailer (out);
	}
}
