
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class addnew_servlet extends HttpServlet
{
	static ResultSet rec;
	static PrintWriter out;

	public static void trace (String text)
	{
		System.out.println ("trace addnew: " + text);  
		out.println ("trace addnew: " + text + "<br>"); 
	}

	public static void field (String name, String text)
	{
		try
		{
			out.println ("<tr><td> " + text + " </td><td> <input name=\"" + name + "\" size=60 maxlength=250 value=\"\"></td></tr>"); 
		}
		catch (Exception e)
		{
			out.println ("Erreur champ " + name + " : " + e.getMessage());
		}
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		String profil;

		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			String username;
			String password;
			boolean identif;

			ident id = new ident ();
			identif = id.read_id (request);
			username = id.username;
			password = id.password;

			if (identif == false)
			{
				html.header (out, "Acc&egrave;s refus&eacute;");
				System.out.println ("Vous n'&egrave;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es.");
			}
			else
			{
			html.header (out, "Ajout d'un nouveau poste");
 			db db1 = new db ("postes"); 
			String  ref;
			ref = "";
 			String ref1 = "";
  			out.println ("<form method=\"POST\" action=\"doupd\">");
			out.println ("<input name=\"Username\" type=\"hidden\" value=\"" + username + "\">");
			out.println ("<input name=\"Password\" type=\"hidden\" value=\"" + password + "\">");

			out.println ("<table>");
			out.println ("<input name=\"Reference1\" type=\"hidden\" value=\"" + ref + "\">"); 
			/* System.out.println ("<input name=\"Profil\" size=60 maxlength=250 value=\"" + detail_cgi.format(rec.getString("Profil")) + "\"><p>"); */
			/* field ("Reference");  */
			out.println ("<tr><td> R&eacute;f&eacute;rence </td><td> <input name=\"Reference\" size=60 maxlength=250 value=\"" + detail_cgi.format(ref) + "\"></td></tr>"); 
			field ("Position", "Position");
			field ("Profil", "Profil");
			field ("Debut", "D&eacute;but");
			field ("Duree", "Dur&eacute;e");
			field ("Lieu", "Lieu");
			field ("Contrat", "Contrat");
			field ("Taux", "Taux");
			field ("Contact", "Contact");
			field ("Email", "E_Mail");
			field ("Telephone", "T&eacute;l&eacute;phone");
			field ("Fax", "Fax");
			field ("Publiele", "Publi&eacute; le");
					
			out.println ("</table>");

			out.println ("<input type=\"submit\" value=\"Enregistrer\">");
					System.out.println ("</form>");
			}
		}
 		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer (out);
	}
}
