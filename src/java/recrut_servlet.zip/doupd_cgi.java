
import java.io.*;
 
class doupd_cgi 
{
	public static void trace (String s)
	{
		System.out.println ("Trace: " + s + "<br>");
	}

	public static int analyze (String line, String vars[], String vals[])
	{
		String line1;
		int i;
		int j;
                int k;
		line1 = line;
		i = 0;
		for (;;)
		{
			trace ("var #" + i);

			j = line1.indexOf ('=');
			if (j == -1)
				return i;
			k = line1.indexOf ('&');
			vars[i] = line1.substring (0, j);
			trace ("var \"" + vars[i] + "\"");
			if (k == -1)
			{
				vals[i] = util.decode(line1.substring (j+1));
				return i+1;
			}
			vals[i] = util.decode(line1.substring (j+1, k));
			trace ("val \"" + vals[i] + "\"");
			i++;
			line1 = line1.substring (k+1);
		}
	}

        public static void display (int n, String vars[], String vals[])
	{
		for (int i=0; i<n; i++)
		{
			System.out.println (vars[i] + " = " + vals[i] + "<br>");
		}
	}

	public static String update_query (int n, String vars[], String vals[])
	{
		String query;
		query = "UPDATE Postes SET " + vars[3] + " = '" + util.quotequote(vals[3]) + "'";
		for (int i=4; i<n; i++)
		{
			if (!(vals[i].equals("")))
				query = query + " , " + vars[i] + " = '" + util.quotequote(vals[i]) + "'";
		}
		query = query + " WHERE Reference = '" + vals[2] + "'";
		return query;
	}

	public static void main (String args[])
	{
		try
		{
			html.header ("Enregistrement de la modification");

			String inLine;
			String newtext;
			String ref_update;
			int ln;
			String vars[];
			String vals[];
			int n;
			String query;
			int rowsUpdated;
			
			n = 0;

			vars = new String[20];
			vals = new String[20];

			util u = new util();

			ref_update = "";
			newtext = "";

			BufferedReader in = new BufferedReader
    				(new InputStreamReader(System.in));
 
			for (ln=0; ln<1; ln++)
			{
				inLine = in.readLine ();
				System.out.println ("read:" + inLine + "."); 
 		
				if (inLine.length() > 9)	
				if (inLine.substring(0,9).equals("Username="))
				{
					System.out.println ("Data : \"" + inLine + "\"");
					n = analyze (inLine, vars, vals);
					display (n, vars, vals);
					break;
					/*
					int j = inLine.indexOf ('&');
					ref_update = u.decode (inLine.substring(10,j));
					newtext = u.decode (inLine.substring(j+7));
					*/
					
				}
				/*else if (inLine.substring(0,6).equals("texte="))
				{
					newtext = inLine.substring(6);
				}*/
			}
			/*
  			System.out.println ("<p>Ref :" + ref_update + ".<p>");
			System.out.println ("<p>New text :" + newtext + ".<p>");
 			*/

			System.out.println ("Ident :" + vals[0] + "/" + vals[1] + ".");
			boolean identif = ident.check (vals[0], vals[1]);

			if (!identif)
			{
				System.out.println ("Vous n'&ecirc;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es");
			}
			else
			{
 			db db1 = new db ("postes");
			/*				 				
			int rowsUpdated = db1.st.executeUpdate (
					"UPDATE Postes set Profil = '"
					+ newtext 
					+ "' where Reference = '"
					+ ref_update + "'");			
			*/
			if (vals[2].equals(""))
			{
				query = "INSERT INTO Postes (Reference) VALUES ('" + util.quotequote(vals[3]) + "')";
				System.out.println ("<p>SQL query : " + query + "<p>");
				rowsUpdated = db1.st.executeUpdate (query);			
				System.out.println ("<p>" + rowsUpdated + " rows updated.<p>");				
				/* vals[0] = vals[1]; */
				vals[2] = vals[3];
				/* db1.co.commit(); */
				/* db1 = new db ("postes"); */
			}
			query = update_query (n, vars, vals);
			System.out.println ("<p>SQL query : " + query + "<p>");
			rowsUpdated = db1.st.executeUpdate (query);
			System.out.println ("<p>" + rowsUpdated + " rows updated.<p>");
			}			
	  	}
		catch (Exception e)
		{
			System.out.println (e.getMessage());
		}
		html.trailer ();
	
 	}
}
