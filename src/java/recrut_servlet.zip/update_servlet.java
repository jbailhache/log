
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class update_servlet extends HttpServlet
{
	static ResultSet rec;
	static PrintWriter out;

	public static void trace (String text)
	{
		/* System.out.println ("trace update: " + text);  */
		/* out.println ("trace update: " + text + "<br>"); */
	}

	public static void field (String name, String text)
	{
		try
		{
			out.println ("<tr><td> " + text + " </td><td> <input name=\"" + name + "\" size=60 maxlength=250 value=\"" + detail_cgi.format(rec.getString(name)) + "\"></td></tr>"); 
		}
		catch (Exception e)
		{
			out.println ("Erreur champ " + name + " : " + e.getMessage());
		}
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		String profil;
		String ref;

		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
 
			String username = "";
			String password = "";
			boolean identif;

			Enumeration values = request.getParameterNames();
			while (values.hasMoreElements())
			{
				String name = (String)values.nextElement();
				trace ("name=" + name + ".");
				String value = request.getParameterValues(name)[0];
				trace ("value=" + value + ".");
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
				else if (name.equals ("Reference"))
					ref = value;
			}
/* 	
			ident id = new ident ();
			identif = id.read_id (request);
			username = id.username;
			password = id.password;
*/
			int status = ident.check (username, password);
			identif = status > 0;
		
			if (identif == false)
			{
				html.header (out, "Acc&egrave;s refus&eacute;");
				out.println ("Vous n'&egrave;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es.");
			}
			else
			{
			db db1 = new db ("postes"); 
			/* String  ref; */
  			/* ref = args[0]; */
			ref = request.getParameter ("Reference"); 
			trace ("ref:" + ref + ".");
			html.header (out, "Modification du poste " + ref);
 			rec = db1.st.executeQuery (
				"SELECT * FROM Postes WHERE Reference = '" + ref + "'");  

			while (rec.next())
			{
				String ref1 = rec.getString ("Reference");
				if (ref1.equals(ref))
				{
					/* profil = rec.getString ("Profil"); */
					out.println ("<form method=\"POST\" action=\"doupd\">");
					out.println ("<input name=\"Username\" type=\"hidden\" value=\"" + username + "\">");
					out.println ("<input name=\"Password\" type=\"hidden\" value=\"" + password + "\">");

					out.println ("<table>");
					/* System.out.println ("Update the text :<p>"); */
					out.println ("<input name=\"Reference1\" type=\"hidden\" value=\"" + ref + "\">"); 
					
					/* System.out.println ("<input name=\"Profil\" size=60 maxlength=250 value=\"" + detail_cgi.format(rec.getString("Profil")) + "\"><p>"); */
					/* field ("Reference");  */
					out.println ("<tr><td> R&eacute;f&eacute;rence </td><td> <input name=\"Reference\" size=60 maxlength=250 value=\"" + detail_cgi.format(ref) + "\"></td></tr>"); 
					field ("Position", "Position");
					field ("Profil", "Profil");
					field ("Debut", "D&eacute;but");
					field ("Duree", "Dur&eacute;e");
					field ("Lieu", "Lieu");
					field ("Contrat", "Contrat");
					field ("Taux", "Taux");
					field ("Contact", "Contact");
					field ("Email", "E_Mail");
					field ("Telephone", "T&eacute;l&eacute;phone");
					field ("Fax", "Fax");
					field ("Publiele", "Publi&eacute; le");
					
					out.println ("</table>");

					out.println ("<input type=\"submit\" value=\"Enregistrer\">");
					out.println ("</form>");
				}
			}
			db.st.close();
			}
		}
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer(out);
	}
}
