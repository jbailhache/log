
import java.sql.*;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class detail_servlet extends HttpServlet
{ 
static PrintWriter out;

	public static void trace (String text)
	{
		System.out.println ("trace detail: " + text); 
		/* out.println ("trace detail: " + text + "<br>");  */
	}

	public static String format (String s)
	{
		if (s == null)
			return "";
		else
			return s;
	}

	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		/* PrintWriter out; */
		
		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		/*
		String profil;
		String email;
		*/
		try
		{
			db db1 = new db ("postes"); 
			String  ref;
			/* ref = args[0]; */
			ref = request.getParameter ("Reference"); 
			/* out.println ("ref :" + ref + ".<p>");  */

			/*
			BufferedReader in = request.getReader ();
			String inLine = in.readLine(); 
			String inLine = "Test";
			out.println ("read :" + inLine + ".<p>");			
			*/
			
			/*
			InputStreamReader isr = new InputStreamReader (client.getInputStream());
			BufferedReader is = new BufferedReader (isr);

			String inLine = is.readLine();		
			*/
 	
			/*		
			Enumeration values = req.getParameterNames();
			while(values.hasMoreElements()) 
			{
                		String name = (String)values.nextElement();
				trace ("name=" + name + ".");
				String value = req.getParameterValues(name)[0];
				trace ("value=" + value + ".");
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
				else if (name.equals ("Reference"))
					ref = value;
				
            		}
			*/
			

			html.header (out, "Details poste " + ref);

			trace ("ref:" + ref);
			ResultSet rec = db1.st.executeQuery (
				"SELECT * FROM Postes WHERE Reference = '" + ref + "'");

			while (rec.next())
			{
				trace ("debut boucle");
				String ref1 = rec.getString ("Reference");
				if (ref1.equals(ref))
				{
					/* 
					profil = rec.getString ("Profil");
					System.out.println (profil);
					System.out.println ("<p>");
					System.out.println ("email : <a href=mailto:" + email + ">" + email + "</a>");
					*/


					out.println ("<table border=\"1\"><caption>D&eacute;tails du poste</caption>");
					out.println ("<tr><td> R&eacute;f&eacute;rence </td><td> " + format(ref) + "</td></tr>");
					out.println ("<tr><td> Position </td><td> " + format(rec.getString("Position")) + " </td></tr>");
					out.println ("<tr><td> Profil </td><td> " + format(rec.getString("Profil")) + " </td></tr>");
					out.println ("<tr><td> D&eacute;but </td><td> " + format(rec.getString("Debut")) + " </td></tr>");
					out.println ("<tr><td> Dur&eacute;e </td><td> " + format(rec.getString("Duree")) + " </td></tr>");
					out.println ("<tr><td> Lieu </td><td> " + format(rec.getString("Lieu")) + " </td></tr>");
				 	out.println ("<tr><td> Contrat </td><td> " + format(rec.getString("Contrat")) + " </td></tr>");
					out.println ("<tr><td> Taux </td><td> " + format(rec.getString("Taux")) + " </td></tr>");
					out.println ("<tr><td> Contact </td><td> " + format(rec.getString("Contact")) + " </td></tr>");
					String email = format(rec.getString ("Email"));
					out.println ("<tr><td> E_Mail </td><td> <a href=mailto:" + email + ">" + email + "</a> </td></tr>");
					out.println ("<tr><td> T&eacute;l&eacute;phone </td><td> " + format(rec.getString("Telephone")) + " </td></tr>");
					out.println ("<tr><td> Fax </td><td> " + format(rec.getString("Fax")) + " </td></tr>");
					out.println ("<tr><td> Publi&eacute; le </td><td> " + format(rec.getString("Publiele")) + " </td></tr>");
         				out.println ("</table>");
					
				}

			}
			/* out.println ("<p><a href=update?" + ref + ">Modifier</a>"); */

			db.st.close();
			html.trailer(out);
		}
		catch (Exception e)
		{
			System.out.println ("Error : " + e.getMessage());
		}
        }
}
