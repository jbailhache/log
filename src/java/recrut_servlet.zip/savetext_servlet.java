
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class savetext_servlet extends HttpServlet
{
	static PrintWriter out;

	public static void trace (String s)
	{
		/*
		System.out.println ("trace savetext: " + s); 
		out.println ("trace savetext: " + s + "<br>"); 
		*/
	}

	/* public static void main (String args[]) */
	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		int ln;
		String inLine;
		String newtext;
		String query;
		int rowsUpdated;
		String buf;
		int pos;
		String line;

		String vars[];
		String vals[];
		int n;

		vars = new String[20];
		vals = new String[20];

		db db1;
		db1 = null;

		String username = "";
		String password = "";
		boolean identif;

		newtext = "";

		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			html.header (out, "Enregistrement de la modification du texte");

			/* BufferedReader in = new BufferedReader
    				(new InputStreamReader(System.in)); */

			Enumeration values = request.getParameterNames();
			while (values.hasMoreElements())
			{
				String name = (String)values.nextElement();
				trace ("name=" + name + ".");
				String value = request.getParameterValues(name)[0];
				trace ("value=" + value + ".");
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
				else if (name.equals ("Texte"))
					newtext = value;
			}

			int status = ident.check (username, password);
			identif = status > 0;

			/*for (ln=0; ln<1; ln++)
			{*/
				/* inLine = in.readLine (); */
				 
 				/*if (inLine.length() > 9)
				if (inLine.substring(0,9).equals("Username="))
				{
 					n = doupd_cgi.analyze (inLine, vars, vals);
 					
 					boolean identif = ident.check (vals[0], vals[1]);
					*/

					if (!identif)
					{
						out.println ("Vous n'&ecirc;tes pas autoris&eacute; &agrave; modifier la base de donn&eacute;es");
					}
					else
					{
					 
	 					/*newtext = vals[2];*/
 						db1 = new db ("postes");
						query = "DELETE FROM Presentation";	
						rowsUpdated = db1.st.executeUpdate (query);
 						buf = newtext;
						while (true)
						{
							pos = buf.indexOf ('\r');
							if (pos < 0)
								break;
							line = buf.substring (0, pos);
							buf = buf.substring (pos+2);
							query = "INSERT INTO Presentation (Ligne) VALUES ('" 
								+ util.quotequote(line) + "')";											
 							rowsUpdated = db1.st.executeUpdate (query);
 						
						}
					}
					out.println ("Modification enregistr&eacute;e<p>");
					
					out.println ("<form method=\"POST\" action=\"recrut\">");
					out.println ("<input type=\"hidden\" name=\"Username\" value=\"" + username + "\">");
					out.println ("<input type=\"hidden\" name=\"Password\" value=\"" + password + "\">");
					out.println ("<input type=\"submit\" value=\"Continuer\">"); 			     

					db1.st.close ();
					/* break;
				}
			}*/
			
		}
		catch (Exception e)
		{
			out.println (e.getMessage());
		}
		html.trailer (out);
	}
}
