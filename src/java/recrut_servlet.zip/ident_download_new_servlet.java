
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ident_download_new_servlet extends HttpServlet
{
	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		PrintWriter out;
		
		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			html.header (out, "Identification");

			db db1 = new db ("postes");

                        out.println ("<form method=\"POST\" action=\"download_new\">");
			out.println ("<p>Nom d'utilisateur : <input name=\"Username\" size=40 maxlength=40><p>");
			out.println ("Mot de passe : <input type=\"password\" name=\"Password\" size=30 maxlength=30><p>");
			out.println ("<input type=\"submit\" value=\"Valider\">"); 			     

		}	
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer(out);
	}
}
