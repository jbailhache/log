
import java.io.*;

class html
{
	public static void header (PrintWriter out, String title)
	{
		out.println ("<HTML><head><title>" + title + "</title></head><body>");
	}

	public static void header (String title)
	{
		/* header (System.out, title); */
		System.out.println ("<HTML><head><title>" + title + "</title></head><body>");
	}
	

	public static void trailer (PrintWriter out)
	{
		out.println ("</body></HTML>");
		out.close();
	}

	public static void trailer ()
	{
		/* trailer (System.out); */
		System.out.println ("</body></HTML>");
	}
	
}
