
public class util
{
 
	public static String string1 (char c)
	{
		String s;
		s = "x";
		s = s.replace ('x', c);
		return s;  
	}

	public static int hexval (char c)
	{
		if (c == '0') return 0;
		if (c == '1') return 1;
		if (c == '2') return 2;
		if (c == '3') return 3;
		if (c == '4') return 4;
		if (c == '5') return 5;
		if (c == '6') return 6;
		if (c == '7') return 7;
		if (c == '8') return 8;
		if (c == '9') return 9;
		if (c == 'A') return 10;
		if (c == 'B') return 11;
		if (c == 'C') return 12;
		if (c == 'D') return 13;
		if (c == 'E') return 14;
		if (c == 'F') return 15;
		return 0;
 	}

	public static char hexa1 (byte x)
	{
 		if (x < (byte)10)
			return (char)(0x30 + x);
		return (char)(0x41 + x - 10);
	}

	public static String hexa (byte x)
	{
		int ix;
		int iy;
		int iz;
		byte y;
		char z;
		String s1;
		String s2;
		String s;

		ix = (int) x;
 		iy = ix >> 4;
 		iz = iy & 15;
 		z = hexa1 ((byte)iz);
 		s1 = string1 (z);

		ix = (int) x;
 		iy = ix;
 		iz = iy & 15;
 		z = hexa1 ((byte)iz);
 		s2 = string1 (z);

		s = s1 + s2;

		return s;
			
/*
		return (String) ((hexa1(x>>4))&15) + 
		       (String) ((hexa1(x))&15); 
*/

	}

	public static String encode (String s)
	{
		String r;
		int i;
		r = "";
		for (i=0; i<s.length(); i++)
		{
			if (s.charAt(i) == '/')
				r += "%" + hexa ((byte)s.charAt(i)); 
			else
				r += string1 (s.charAt(i));
		}	
		return r;
	}

	public static String decode (String s)
	{
		String r;
		int i;
		r = "";
		for (i=0; i<s.length(); i++)
		{
			if (s.charAt(i) == '%')
			{
				if (s.charAt(i+1) == '9' && s.charAt(i+2) == '2')
					r = r + "'";
				else
					r = r + string1 ((char) (hexval(s.charAt(i+1))<<4 | hexval(s.charAt(i+2))));
				i += 2;
			}
			else if (s.charAt(i) == '+')
				r = r + string1 (' ');
			else
				r = r + string1 (s.charAt(i));    
		}
		return r;
		
	} 	

	public static String quotequote (String s)
	{
		String r;
		int i;
		r = "";
		for (i=0; i<s.length(); i++)
		{
			if (s.charAt(i) == '\'')
				r = r + "''";
			else
				r = r + string1 (s.charAt(i));
		}
		return r;				
	}
}
