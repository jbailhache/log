
import java.sql.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

class doupd_id_servlet extends HttpServlet
{
	public static void trace (String s)
	{
		/* System.out.println ("Trace: " + s + "<br>"); */
	}

	public static int analyze (String line, String vars[], String vals[])
	{
		String line1;
		int i;
		int j;
                int k;
		line1 = line;
		i = 0;
		for (;;)
		{
			trace ("var #" + i);
			trace ("line1 = (" + line1 + ")");
			j = line1.indexOf ('=');
			trace ("j = " + j);
			if (j == -1)
				return i;
			trace ("...");
			k = line1.indexOf ('&');
			trace ("k = " + k);
			try
			{
				trace ("a");
				vars[i] = line1.substring (0, j);
				trace ("b");
			}
			catch (Exception e)
			{
				trace ("c");
				vars[i] = "";
				trace ("d");
			}
			trace ("var \"" + vars[i] + "\"");
			if (k == -1)
			{
				trace ("avant decode k == -1");
				vals[i] = util.decode(line1.substring (j+1));
				trace ("vals[i] = " + vals[i]);
				return i+1;
			}
			trace ("avant decode");
			vals[i] = util.decode(line1.substring (j+1, k));
			trace ("val \"" + vals[i] + "\"");
			i++;
			line1 = line1.substring (k+1);
		}
	}

	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		try
		{
			html.header ("Enregistrement de la modification");

			String inLine;
			int ln;
			int n;
			String vars[];
			String vals[];
			String username = "";
			String password = "";

			n = 0;

			vars = new String[200];
			vals = new String[200];

			Enumeration values = request.getParameterNames ();
			while (values.hasMoreElements())
			{
				String name = (String)values.nextElement();
				trace ("name=" + name + ".");
				String value = request.getParameterValues(name)[0];
				trace ("value=" + value + ".");
				if (name.equals ("Username"))
					username = value;
				else if (name.equals ("Password"))
					password = value;
			}
			
			trace ("username=" + username + "password=" + password);

  		}
		catch (Exception e)
		{
			System.out.println (e.getMessage());
		}
		html.trailer ();
	
 	}
}
