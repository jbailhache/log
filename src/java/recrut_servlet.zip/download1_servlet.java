
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class download1_servlet extends HttpServlet
{
	static PrintWriter out;

	public static void trace (String text)
	{
		System.out.println ("trace download: " + text); 
		out.println ("trace download: " + text + "<br>"); 
	}

 
	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		

		try
		{
			/* En-tete HTML */
			/* out.println ("<HTML><head><title>Recrutement</title></head><body>"); */
			
			String username;
			String password;
			boolean identif;

			out = response.getWriter(); 

			ident id = new ident ();
			/* identif = id.read_id (request); */
			int status = id.read_id1 (request);
			trace ("status = " + status);
			identif = status > 0;
			trace ("identif = " + identif);
			username = id.username;
			trace ("username = " + username);
			password = id.password;
			trace ("password = " + password);

			if (!identif) 
 			{
				// set content type and other response header fields first
        			response.setContentType("text/html");

				// then write the data of the response
				/* out = response.getWriter(); */

				html.header (out, "Acc&egrave; refus&eacute;");
				out.println ("Identification incorrecte");
				html.trailer (out);
			}
			else
			{
				// set content type and other response header fields first
        			/* response.setContentType("application/x-compress"); */
        			/* response.setContentType("application/ms-dos"); */
        			/* response.setContentType("image/bmp"); */	
				/* response.setContentType("multipart/form-data"); */

				// then write the data of the response

				/*								
				out = response.getWriter();

				FileInputStream f = new FileInputStream ("C:\\jacques\\test.exe");
				boolean eof = false;
				while (!eof)
				{
					int octet = f.read();
					if (octet == -1)
						eof = true;
					else
					{
						char car = (char) octet;
						out.print (car);
						*//* System.out.print (" " + octet); *//*
					}
				}
				*/							

				out = response.getWriter();

				html.header (out, "Download");

				out.println ("Download<p>");


				/* out.println ("<applet code=\"file:///c:\\xitami\\webpages\\download_applet.java\" width=400 height=300>"); */
				out.println ("<applet code=\"download_applet.java\" width=400 height=300>");


				out.println ("</applet>");				

				html.trailer (out);

				
			}
 		}
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer (out);
		out.close();
	}

	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		doGet (request, response);
	}


}
