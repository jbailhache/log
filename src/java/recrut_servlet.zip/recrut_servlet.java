
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class recrut_servlet extends HttpServlet
{
	static PrintWriter out;

	public static void link (String prog, String ref, String name, String username, String password)
	{
		out.println ("<form method=\"POST\" action=\""
			+ prog + "\">");
		out.println ("<input name=\"Reference\" type=\"hidden\" value=\""
			+ ref + "\">");
		out.println ("<input name=\"Username\" type=\"hidden\" value=\"" 
			+ username + "\">");
		out.println ("<input name=\"Password\" type=\"hidden\" value=\"" 
			+ password + "\">");
		out.println ("<input type=\"submit\" value=\""
			+ name + "\">");
		out.println ("</form>");
	}

	public static int analyze (String line, String vars[], String vals[])
	{
		String line1;
		int i;
		int j;
                int k;
		line1 = line;
		i = 0;
		for (;;)
		{
			/* trace ("var #" + i); */

			j = line1.indexOf ('=');
			if (j == -1)
				return i;
			k = line1.indexOf ('&');
			vars[i] = line1.substring (0, j);
			/* trace ("var \"" + vars[i] + "\""); */
			if (k == -1)
			{
				vals[i] = util.decode(line1.substring (j+1));
				return i+1;
			}
			vals[i] = util.decode(line1.substring (j+1, k));
			/* trace ("val \"" + vals[i] + "\""); */
			i++;
			line1 = line1.substring (k+1);
		}
	}

	/* public static void main (String args[]) */
	public void doGet (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		
		// set content type and other response header fields first
        	response.setContentType("text/html");

		// then write the data of the response
		out = response.getWriter();

		try
		{
			/* En-tete HTML */
			/* out.println ("<HTML><head><title>Recrutement</title></head><body>"); */
			html.header (out, "Recrutement");

			String  ref;
			ResultSet rec;

/*
			String inLine;
			String vars[] = new String[3];
			String vals[] = new String[3];
*/
			String username;
			String password;
			boolean identif;
/*
			username = "";
			password = "";

			BufferedReader in = new BufferedReader
    				(new InputStreamReader(System.in));

			inLine = in.readLine ();
			out.println ("read:" + inLine + "."); 
			if (inLine == null)
			{
				out.println ("No data");
				identif = false;
			}
			else
			{
				doupd_cgi.analyze (inLine, vars, vals);
				username = vals[0];
				password = vals[1];
				out.println ("<p>Username :" + username + ".<p>Password :" + password + ".");
				identif = ident.check (username, password);
				if (identif)
					out.println ("Identification correcte");
				else
					out.println ("Acc�s refus�");
			}
*/
			
			ident id = new ident ();
			identif = id.read_id (request);
			username = id.username;
			password = id.password;

			db db1 = new db ("postes"); 

			/* Affichage du texte de presentation */

			rec = db1.st.executeQuery ("SELECT * FROM Presentation");
			while (rec.next())
			{
				String line = rec.getString("Ligne");
				out.println (line);
			}
			/* db1.st.close(); */

			if (identif)
			{
/*
				out.println ("<p><a href=edittext>Modifier ce texte</a> - ");
				out.println ("<a href=addnew>Ajouter un poste</a><p>");
*/
				link ("edittext", "", "Modifier ce texte", username, password);
				link ("addnew", "", "Ajouter un poste", username, password);
                                    
			}

			/* Affichage du tableau des postes a pourvoir */

			rec = db1.st.executeQuery ("SELECT * FROM Postes");

			out.println ("<table border=\"1\"><caption>Postes disponibles</caption>");
			out.println ("<tr>");
			out.println ("<td> R&eacute;f&eacute;rence </td>");
			out.println ("<td> Position </td>");
			out.println ("<td> Profil </td>");
			out.println ("<td> Dur&eacute;e </td>");
			out.println ("<td> Lieu </td>");
			out.println ("<td> Click </td>"); 
			int i = 0;
			while (rec.next())
			{
				i++;
				ref = rec.getString("Reference");
			
				String profil = rec.getString("Profil");
				if (profil != null)
				{
					int pos = profil.indexOf('<');
					if (pos != -1)
						profil = profil.substring (0, pos);
				}
				/* out.println (ref); */
				/* out.println ("<li><a href=detail?" + ref + ">" + ref + "</a>"); */
				out.println ("<tr>");
				out.println ("<td> <a href=detail?" + ref + ">" + ref + "</a> </td>");				
				out.println ("<td> " + detail_cgi.format(rec.getString("Position")) + " </td>");
				out.println ("<td> " + detail_cgi.format(profil) + " </td>");
				out.println ("<td> " + detail_cgi.format(rec.getString("Duree")) + " </td>");
				out.println ("<td> " + detail_cgi.format(rec.getString("Lieu")) + " </td>");
				/* out.println ("<td><a href=detail?Reference=" + ref + "> &nbsp; </a></td>"); */
				/* out.println ("<td> &nbsp </td></a>"); */
				out.println ("<td> <a href=detail?Reference=" + ref + ">D&eacute;tails</a> ");
				if (identif)
				{
					/*
					out.println ("<a href=update?" + ref + ">Modifier</a> ");
					out.println ("<a href=delete?" + ref + ">Supprimer</a> </td>");     
					*/
					/*
					link ("update?Reference=" + ref, "Modifier", username, password);
					link ("delete?Reference=" + ref, "Supprimer", username, password);   
					*/
					link ("update", ref, "Modifier", username, password);
					link ("delete", ref, "Supprimer", username, password);   

				}
				out.println ("</tr>"); 				
			}
			out.println ("</table>");
			compteur.incr ("Recrut");
			int compt = compteur.get ("Recrut");
			out.println ("<p>Cette page a &eacute;t&eacute consult&eacute;e " 
				+ compt + " fois.<p>");
			/* out.println ("</body></HTML>"); */
			db1.st.close();
		}
		catch (Exception e)
		{
			out.println ("Error : " + e.getMessage());
		}
		html.trailer (out);
		out.close();
	}

	public void doPost (
		HttpServletRequest	request,
		HttpServletResponse	response
    			  ) throws ServletException, IOException
	{
		doGet (request, response);
	}


}
