<HTML>
<head>
<title>Cyber-discussions</title>
</head>
<body>
 
<h3>Cyber-discussions</h3>

<p>
<a href=creation.php>Cr�er une nouvelle discussion</a>

<p>
<form method=post action=debat.php>

<input type=hidden name=table value=discussions>

Lire la discussion
<input type=text name=discussion value="">

<input type=submit value="Valider">

</form>

<p><a href=debat.zip>T�l�charger les sources PHP</a>

<p>
Discussions publiques :

<ul>

<?php

	include ("connexion.php");

	if (connexion () > 0)
	{
		$query = "SELECT * FROM discussions WHERE position = 0";
		$data = mysql_query ($query);
		while ($rec = mysql_fetch_object ($data))
		{
			if ($rec->statut & 1)
			{
				echo ("<p><li> <a href=debat.php?table=discussions&discussion=");
				echo (urlencode($rec->discussion));
				echo (">");
				echo ($rec->discussion);
				/*echo (" statut:");
				echo ($rec->statut);*/
				echo ("</a>");
			}
		} 
		
	}
?>

</ul>

</body>
</HTML>

