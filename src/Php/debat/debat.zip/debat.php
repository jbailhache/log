<HTML>
<head>
<title>Discussion</title>
</head>
<body>

<?php

	include ("connexion.php");

	echo ("<h3>Discussion $discussion</h3>");

	$posprec = 0;
        $texteurl = ""; 
	if (connexion () > 0)
	{
		/*$query = "SELECT * FROM $discussion ORDER BY position";*/
		/*$query = "SELECT * FROM discussions WHERE discussion = '$discussion' ORDER BY position";*/
		$query = "SELECT * FROM $table WHERE discussion = '$discussion' ORDER BY position";
		/*echo ($query);*/
		$data = mysql_query ($query);
		echo ("<ul>");
		while ($interv = mysql_fetch_object($data))
		{
			if ($interv->position > 0)
			{
				$discussionurl = urlencode ($discussion);
				echo ("<br><a href=repondre.php?table=$table&discussion=$discussionurl&position=$posprec&possuiv=");
				echo ($interv->position);
				/*
				echo ("&texte=");
 				echo ($texteurl);
				*/
				echo (">R�pondre</a>");
			}
			echo ("<p><li> ");
			echo ($interv->position);
			echo (" : ");
			echo ($interv->auteur);
			echo (" r�pond � ");
			echo ($interv->reponsea);
			if ($interv->date && !($interv->date == ""))
				echo (" le ");
			echo ($interv->date);
			echo (" : <br>");
			echo ($interv->texte);
			/*$texteurl = urlencode ($interv->texte);*/
			$posprec = $interv->position;
		}
	}
	
?>

</body>
</HTML>
