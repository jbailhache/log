<HTML>
<head>
<title>Cr�ation d'une nouvelle discussion</title>
</head>
<body>

<h3>Cr�ation d'une nouvelle discussion</h3>

<form method=post action=creer.php>

<p>Nom de la discussion : 
<input type=text name=discussion value="">

<p>Votre nom : 
<input type=text name=nom value="">

<p>Phrase d'introduction :
<input type=text name=introduction value="Bonjour, je vous propose de commencer la discussion.">

<p>Phrase de conclusion :
<input type=text name=conclusion value="Merci et au revoir.">

<p>Discussion 
<input type=radio name=statut value="pub" checked> 
publique ou 
<input type=radio name=statut value="priv"> priv�e.

<p>

<input type=submit value="Valider">

</form>

</body>
</HTML>
