//---------------------------------------------------------------------------
#include <vcl.h>
#include <stdio.h>
#include <vcl\Controls.hpp>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

TColor rgb (int r, int g, int b)
{
        return r | (g<<8) | (b<<16);
}

TColor f (int i, int j, int e)
{
        return rgb (i*e, j, 0);
}

void __fastcall TForm1::ButtonDrawClick(TObject *Sender)
{
        TCanvas *canvas = Image->Canvas;
        int height = Image->Height;
        int width = Image->Width;
        int e = Edit1->Text.ToInt();
        for (int i=1; i<width; i++)
        for (int j=1; j<height; j++)
                canvas->Pixels[i][j] = f (i, j, e);
}
//---------------------------------------------------------------------------

/*
void __fastcall TForm1::ImageClick(TObject *Sender)
{
        extern PACKAGE TMouse *Mouse;
        int x = Mouse->CursorPos.x - Image->Left;
        int y = Mouse->CursorPos.y - Image->Top;
        Image->Canvas->Pixels[x][y] = rgb (100, 0, 0);
}
*/
//---------------------------------------------------------------------------

void __fastcall TForm1::ImageMouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
        Image->Canvas->Pixels[X][Y] = rgb (100, 0, 0);
}
//---------------------------------------------------------------------------

