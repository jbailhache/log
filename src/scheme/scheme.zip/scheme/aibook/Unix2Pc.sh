# Many of the names do not conform to DOS stylr names. This script
# converts all name to valid PC names
#
# First make all the new directories
mkdir ./app2
mkdir ./app3
mkdir ./app5
mkdir ./chapt2
mkdir ./chapt2/sect2.3
mkdir ./chapt2/sect2.4
mkdir ./chapt2/sect2.5
mkdir ./chapt2/sect2.5/simulato
mkdir ./chapt2/sect2.5/simulato/examples
mkdir ./chapt2/sect2.5/cflavour
mkdir ./chapt2/sect2.5/contsysa
mkdir ./chapt3
mkdir ./chapt3/examples
mkdir ./chapt3/examples/search
mkdir ./chapt3/examples/search/tests
mkdir ./chapt3/examples/games
mkdir ./chapt3/examples/games/tests
mkdir ./chapt3/examples/patterns
mkdir ./chapt3/examples/patterns/tests
mkdir ./chapt3/examples/knowledg
mkdir ./chapt3/examples/knowledg/tests
mkdir ./chapt3/examples/producti
mkdir ./chapt3/examples/producti/tests
mkdir ./chapt3/examples/associat
mkdir ./chapt3/examples/associat/tests
mkdir ./chapt3/examples/frames
mkdir ./chapt3/examples/frames/tests
mkdir ./chapt3/examples/atns
mkdir ./chapt3/examples/atns/tests
mkdir ./chapt3/examples/combined
mkdir ./chapt3/examples/combined/tests
mkdir ./chapt3/helpers
mkdir ./chapt3/helpers/t
mkdir ./chapt3/helpers/mac
mkdir ./chapt3/helpers/chez
mkdir ./chapt3/helpers/x
mkdir ./chapt3/helpers/pc
mkdir ./chapt3/toolboxe
mkdir ./chapt3/toolboxe/tests
mkdir ./chapt4
mkdir ./chapt4/stress
mkdir ./chapt4/stress/otheruti
#
# Now move over the files
#
mv ./App2/EventSimulator.flv  ./app2/eventsim.flv
mv ./App3/README  ./app3/readme
mv ./App5/Ex2-12.pro  ./app5/ex2-12.pro
mv ./App5/Ex2-24.flv  ./app5/ex2-24.flv
mv ./App5/Ex2-25.flv  ./app5/ex2-25.flv
mv ./App5/Ex2-3.scm  ./app5/ex2-3.scm
mv ./App5/Ex4-4.st  ./app5/ex4-4.st
mv ./App5/README  ./app5/readme
mv ./Chapt2/Ex2-23.flv  ./chapt2/ex2-23.flv
mv ./Chapt2/Ex2-9.flv  ./chapt2/ex2-9.flv
mv ./Chapt2/Sect2.3/Ex2-10.scm  ./chapt2/sect2.3/ex2-10.scm
mv ./Chapt2/Sect2.3/examples.scm  ./chapt2/sect2.3/examples.scm
mv ./Chapt2/Sect2.4/dungeon.pro  ./chapt2/sect2.4/dungeon.pro
mv ./Chapt2/Sect2.4/examples.pro  ./chapt2/sect2.4/examples.pro
mv ./Chapt2/Sect2.5/CFlavours/boot.scm  ./chapt2/sect2.5/cflavour/boot.scm
mv ./Chapt2/Sect2.5/CFlavours/call-we.scm  ./chapt2/sect2.5/cflavour/call-we.scm
mv ./Chapt2/Sect2.5/CFlavours/compat.scm  ./chapt2/sect2.5/cflavour/compat.scm
mv ./Chapt2/Sect2.5/CFlavours/coroutines.scm  ./chapt2/sect2.5/cflavour/coroutin.scm
mv ./Chapt2/Sect2.5/CFlavours/defFlavour.scm  ./chapt2/sect2.5/cflavour/defflavo.scm
mv ./Chapt2/Sect2.5/CFlavours/displayLine.scm  ./chapt2/sect2.5/cflavour/displayl.scm
mv ./Chapt2/Sect2.5/CFlavours/FirstFlavour.scm  ./chapt2/sect2.5/cflavour/firstfla.scm
mv ./Chapt2/Sect2.5/CFlavours/flavours.scm  ./chapt2/sect2.5/cflavour/flavours.scm
mv ./Chapt2/Sect2.5/CFlavours/vanilla.scm  ./chapt2/sect2.5/cflavour/vanilla.scm
mv ./Chapt2/Sect2.5/CFlavours/writ.scm  ./chapt2/sect2.5/cflavour/writ.scm
mv ./Chapt2/Sect2.5/ContSysAnal/expressions.scm  ./chapt2/sect2.5/contsysa/expressi.scm
mv ./Chapt2/Sect2.5/ContSysAnal/Paper.wrd  ./chapt2/sect2.5/contsysa/paper.wrd
mv ./Chapt2/Sect2.5/ContSysAnal/project.boot  ./chapt2/sect2.5/contsysa/project.boo
mv ./Chapt2/Sect2.5/ContSysAnal/Session.example  ./chapt2/sect2.5/contsysa/session.exa
mv ./Chapt2/Sect2.5/ContSysAnal/Systems.examples  ./chapt2/sect2.5/contsysa/systems.exa
mv ./Chapt2/Sect2.5/ContSysAnal/systems.scm  ./chapt2/sect2.5/contsysa/systems.scm
mv ./Chapt2/Sect2.5/ContSysAnal/systemsApplic.scm  ./chapt2/sect2.5/contsysa/systemsa.scm
mv ./Chapt2/Sect2.5/examples.flv  ./chapt2/sect2.5/examples.flv
mv ./Chapt2/Sect2.5/Simulator/dataCollectors.scm  ./chapt2/sect2.5/simulato/datacoll.scm
mv ./Chapt2/Sect2.5/Simulator/distributions.scm  ./chapt2/sect2.5/simulato/distribu.scm
mv ./Chapt2/Sect2.5/Simulator/Examples/ArtGallery.scm  ./chapt2/sect2.5/simulato/examples/artgalle.scm
mv ./Chapt2/Sect2.5/Simulator/Examples/GardenParty.scm  ./chapt2/sect2.5/simulato/examples/gardenpa.scm
mv ./Chapt2/Sect2.5/Simulator/Examples/Manuel.scm  ./chapt2/sect2.5/simulato/examples/manuel.scm
mv ./Chapt2/Sect2.5/Simulator/Examples/MM1.scm  ./chapt2/sect2.5/simulato/examples/mm1.scm
mv ./Chapt2/Sect2.5/Simulator/Examples/QNStest.scm  ./chapt2/sect2.5/simulato/examples/qnstest.scm
mv ./Chapt2/Sect2.5/Simulator/QN-modules.scm  ./chapt2/sect2.5/simulato/qn-modul.scm
mv ./Chapt2/Sect2.5/Simulator/simulator.scm  ./chapt2/sect2.5/simulato/simulato.scm
mv ./Chapt3/Examples/AssociativeNetworks/AnimalKingdom.scm  ./chapt3/examples/associat/animalki.scm
mv ./Chapt3/Examples/AssociativeNetworks/Bestiary.scm  ./chapt3/examples/associat/bestiary.scm
mv ./Chapt3/Examples/AssociativeNetworks/Tests/AnimalKingdom.tst  ./chapt3/examples/associat/tests/animalki.tst
mv ./Chapt3/Examples/AssociativeNetworks/Tests/Bestiary.tst  ./chapt3/examples/associat/tests/bestiary.tst
mv ./Chapt3/Examples/ATNs/AnimalQueries.scm  ./chapt3/examples/atns/animalqu.scm
mv ./Chapt3/Examples/ATNs/JanesGarden.scm  ./chapt3/examples/atns/janesgar.scm
mv ./Chapt3/Examples/ATNs/Tests/AnimalQueries.tst  ./chapt3/examples/atns/tests/animalqu.tst
mv ./Chapt3/Examples/ATNs/Tests/JanesGarden.tst  ./chapt3/examples/atns/tests/janesgar.tst
mv ./Chapt3/Examples/Combined/Rodney.scm  ./chapt3/examples/combined/rodney.scm
mv ./Chapt3/Examples/Combined/Tests/Rodney.tst  ./chapt3/examples/combined/tests/rodney.tst
mv ./Chapt3/Examples/Frames/MuppetLand.scm  ./chapt3/examples/frames/muppetla.scm
mv ./Chapt3/Examples/Frames/Tests/MuppetLand.tst  ./chapt3/examples/frames/tests/muppetla.tst
mv ./Chapt3/Examples/Frames/Tests/ToyLand.tst  ./chapt3/examples/frames/tests/toyland.tst
mv ./Chapt3/Examples/Frames/ToyLand.scm  ./chapt3/examples/frames/toyland.scm
mv ./Chapt3/Examples/Games/Dodgem-Perfect.scm  ./chapt3/examples/games/dodgem-p.scm
mv ./Chapt3/Examples/Games/Dodgem.scm  ./chapt3/examples/games/dodgem.scm
mv ./Chapt3/Examples/Games/Kalah.scm  ./chapt3/examples/games/kalah.scm
mv ./Chapt3/Examples/Games/Tests/Dodgem.tst  ./chapt3/examples/games/tests/dodgem.tst
mv ./Chapt3/Examples/Games/Tests/Kalah.tst  ./chapt3/examples/games/tests/kalah.tst
mv ./Chapt3/Examples/Games/Tests/TicTac.tst  ./chapt3/examples/games/tests/tictac.tst
mv ./Chapt3/Examples/Games/TicTac.scm  ./chapt3/examples/games/tictac.scm
mv ./Chapt3/Examples/KnowledgeBases/InnKeeper.scm  ./chapt3/examples/knowledg/innkeepe.scm
mv ./Chapt3/Examples/KnowledgeBases/KB-cookie-monster.scm  ./chapt3/examples/knowledg/kb-cooki.scm
mv ./Chapt3/Examples/KnowledgeBases/Shrink.scm  ./chapt3/examples/knowledg/shrink.scm
mv ./Chapt3/Examples/KnowledgeBases/Tests/InnKeeper.tst  ./chapt3/examples/knowledg/tests/innkeepe.tst
mv ./Chapt3/Examples/KnowledgeBases/Tests/KB-cookie-monster.tst  ./chapt3/examples/knowledg/tests/kb-cooki.tst
mv ./Chapt3/Examples/KnowledgeBases/Tests/Shrink.tst  ./chapt3/examples/knowledg/tests/shrink.tst
mv ./Chapt3/Examples/Patterns/cookie-monster.scm  ./chapt3/examples/patterns/cookie-m.scm
mv ./Chapt3/Examples/Patterns/Tests/cookie-monster.tst  ./chapt3/examples/patterns/tests/cookie-m.tst
mv ./Chapt3/Examples/Productions/GuessWho.scm  ./chapt3/examples/producti/guesswho.scm
mv ./Chapt3/Examples/Productions/Monkey.scm  ./chapt3/examples/producti/monkey.scm
mv ./Chapt3/Examples/Productions/Tests/GuessWho.tst  ./chapt3/examples/producti/tests/guesswho.tst
mv ./Chapt3/Examples/Productions/Tests/Monkey.tst  ./chapt3/examples/producti/tests/monkey.tst
mv ./Chapt3/Examples/Search/8-Puzzle.scm  ./chapt3/examples/search/8-puzzle.scm
mv ./Chapt3/Examples/Search/Cannibals.scm  ./chapt3/examples/search/cannibal.scm
mv ./Chapt3/Examples/Search/LineLand.scm  ./chapt3/examples/search/lineland.scm
mv ./Chapt3/Examples/Search/Monkey.scm  ./chapt3/examples/search/monkey.scm
mv ./Chapt3/Examples/Search/Tests/8-Puzzle.tst  ./chapt3/examples/search/tests/8-puzzle.tst
mv ./Chapt3/Examples/Search/Tests/Cannibals.tst  ./chapt3/examples/search/tests/cannibal.tst
mv ./Chapt3/Examples/Search/Tests/LineLand.tst  ./chapt3/examples/search/tests/lineland.tst
mv ./Chapt3/Examples/Search/Tests/Monkey.tst  ./chapt3/examples/search/tests/monkey.tst
mv ./Chapt3/Helpers/Chez/MakeHeap.scm  ./chapt3/helpers/chez/makeheap.scm
mv ./Chapt3/Helpers/Chez/README  ./chapt3/helpers/chez/readme
mv ./Chapt3/Helpers/Chez/TestExamples.scm  ./chapt3/helpers/chez/testexam.scm
mv ./Chapt3/Helpers/Chez/TestToolbox.scm  ./chapt3/helpers/chez/testtool.scm
mv ./Chapt3/Helpers/Mac/MakeHeap.scm  ./chapt3/helpers/mac/makeheap.scm
mv ./Chapt3/Helpers/Mac/TestExamples.scm  ./chapt3/helpers/mac/testexam.scm
mv ./Chapt3/Helpers/Mac/TestToolbox.scm  ./chapt3/helpers/mac/testtool.scm
mv ./Chapt3/Helpers/PC/Compile.scm  ./chapt3/helpers/pc/compile.scm
mv ./Chapt3/Helpers/PC/FastLoad.scm  ./chapt3/helpers/pc/fastload.scm
mv ./Chapt3/Helpers/PC/MakeHeap.scm  ./chapt3/helpers/pc/makeheap.scm
mv ./Chapt3/Helpers/PC/README  ./chapt3/helpers/pc/readme
mv ./Chapt3/Helpers/PC/TestExamples.scm  ./chapt3/helpers/pc/testexam.scm
mv ./Chapt3/Helpers/PC/TestToolbox.scm  ./chapt3/helpers/pc/testtool.scm
mv ./Chapt3/Helpers/T/MakeHeap.scm  ./chapt3/helpers/t/makeheap.scm
mv ./Chapt3/Helpers/T/TestExamples.scm  ./chapt3/helpers/t/testexam.scm
mv ./Chapt3/Helpers/T/TestToolbox.scm  ./chapt3/helpers/t/testtool.scm
mv ./Chapt3/Helpers/X/MakeHeap.scm  ./chapt3/helpers/x/makeheap.scm
mv ./Chapt3/Helpers/X/README  ./chapt3/helpers/x/readme
mv ./Chapt3/Helpers/X/TestExamples.scm  ./chapt3/helpers/x/testexam.scm
mv ./Chapt3/Helpers/X/TestToolbox.scm  ./chapt3/helpers/x/testtool.scm
mv ./Chapt3/Helpers/X/xscheme.ini  ./chapt3/helpers/x/xscheme.ini
mv ./Chapt3/README  ./chapt3/readme
mv ./Chapt3/Toolboxes/AssociativeNetworks.scm  ./chapt3/toolboxe/associat.scm
mv ./Chapt3/Toolboxes/ATNs.scm  ./chapt3/toolboxe/atns.scm
mv ./Chapt3/Toolboxes/CS-Systems.scm  ./chapt3/toolboxe/cs-syste.scm
mv ./Chapt3/Toolboxes/Frames.scm  ./chapt3/toolboxe/frames.scm
mv ./Chapt3/Toolboxes/Games.scm  ./chapt3/toolboxe/games.scm
mv ./Chapt3/Toolboxes/KnowledgeBases.scm  ./chapt3/toolboxe/knowledg.scm
mv ./Chapt3/Toolboxes/LoadTool.scm  ./chapt3/toolboxe/loadtool.scm
mv ./Chapt3/Toolboxes/Mac-Systems.scm  ./chapt3/toolboxe/mac-syst.scm
mv ./Chapt3/Toolboxes/Patterns.scm  ./chapt3/toolboxe/patterns.scm
mv ./Chapt3/Toolboxes/PC-Systems.scm  ./chapt3/toolboxe/pc-syste.scm
mv ./Chapt3/Toolboxes/Productions.scm  ./chapt3/toolboxe/producti.scm
mv ./Chapt3/Toolboxes/Search1.scm  ./chapt3/toolboxe/search1.scm
mv ./Chapt3/Toolboxes/Search2.scm  ./chapt3/toolboxe/search2.scm
mv ./Chapt3/Toolboxes/T-Systems.scm  ./chapt3/toolboxe/t-system.scm
mv ./Chapt3/Toolboxes/Tests/actions.tst  ./chapt3/toolboxe/tests/actions.tst
mv ./Chapt3/Toolboxes/Tests/alpha-beta.tst  ./chapt3/toolboxe/tests/alpha-be.tst
mv ./Chapt3/Toolboxes/Tests/AN.tst  ./chapt3/toolboxe/tests/an.tst
mv ./Chapt3/Toolboxes/Tests/ATN.tst  ./chapt3/toolboxe/tests/atn.tst
mv ./Chapt3/Toolboxes/Tests/BF.tst  ./chapt3/toolboxe/tests/bf.tst
mv ./Chapt3/Toolboxes/Tests/DF.tst  ./chapt3/toolboxe/tests/df.tst
mv ./Chapt3/Toolboxes/Tests/Frames.tst  ./chapt3/toolboxe/tests/frames.tst
mv ./Chapt3/Toolboxes/Tests/Hill.tst  ./chapt3/toolboxe/tests/hill.tst
mv ./Chapt3/Toolboxes/Tests/KB.tst  ./chapt3/toolboxe/tests/kb.tst
mv ./Chapt3/Toolboxes/Tests/levels.tst  ./chapt3/toolboxe/tests/levels.tst
mv ./Chapt3/Toolboxes/Tests/minimax.tst  ./chapt3/toolboxe/tests/minimax.tst
mv ./Chapt3/Toolboxes/Tests/paths.tst  ./chapt3/toolboxe/tests/paths.tst
mv ./Chapt3/Toolboxes/Tests/patterns.tst  ./chapt3/toolboxe/tests/patterns.tst
mv ./Chapt3/Toolboxes/Tests/problems.tst  ./chapt3/toolboxe/tests/problems.tst
mv ./Chapt3/Toolboxes/Tests/productions.tst  ./chapt3/toolboxe/tests/producti.tst
mv ./Chapt3/Toolboxes/Tests/spaces.tst  ./chapt3/toolboxe/tests/spaces.tst
mv ./Chapt3/Toolboxes/Tests/states.tst  ./chapt3/toolboxe/tests/states.tst
mv ./Chapt3/Toolboxes/Tests/Steepest.tst  ./chapt3/toolboxe/tests/steepest.tst
mv ./Chapt3/Toolboxes/Tests/triples.tst  ./chapt3/toolboxe/tests/triples.tst
mv ./Chapt3/Toolboxes/TestTool.scm  ./chapt3/toolboxe/testtool.scm
mv ./Chapt3/Toolboxes/X-Systems.scm  ./chapt3/toolboxe/x-system.scm
mv ./Chapt4/CookieMonsterWorld.st  ./chapt4/cookiemo.st
mv ./Chapt4/CugelsWorld.st  ./chapt4/cugelswo.st
mv ./Chapt4/Ex4-7.st  ./chapt4/ex4-7.st
mv ./Chapt4/FaceWorld.st  ./chapt4/faceworl.st
mv ./Chapt4/FlowerDraw.st  ./chapt4/flowerdr.st
mv ./Chapt4/GraphicsEditor.st  ./chapt4/graphics.st
mv ./Chapt4/JanesGarden.st  ./chapt4/janesgar.st
mv ./Chapt4/MagnifyingGlass.st  ./chapt4/magnifyi.st
mv ./Chapt4/MiscDemos.st  ./chapt4/miscdemo.st
mv ./Chapt4/MonsterDemo.st  ./chapt4/monsterd.st
mv ./Chapt4/ScrollingForm.st  ./chapt4/scrollin.st
mv ./Chapt4/Stress/Birdsville.stress  ./chapt4/stress/birdsvil.str
mv ./Chapt4/Stress/Birdsville.trial  ./chapt4/stress/birdsvil.tri
mv ./Chapt4/Stress/OtherUtilities/ChangeTrees.st  ./chapt4/stress/otheruti/changetr.st
mv ./Chapt4/Stress/OtherUtilities/VariableDictionaryInspector.st  ./chapt4/stress/otheruti/variable.st
mv ./Chapt4/Stress/README  ./chapt4/stress/readme
mv ./Chapt4/Stress/Stress.st  ./chapt4/stress/stress.st
mv ./Chapt4/Stress/StressUtilities.st  ./chapt4/stress/stressut.st
mv ./README  ./readme
