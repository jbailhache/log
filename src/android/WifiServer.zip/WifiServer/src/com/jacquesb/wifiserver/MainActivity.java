package com.jacquesb.wifiserver;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.*;

import java.util.ArrayList;
import java.util.HashMap;    
import java.util.List;    

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;    
import android.content.Intent;     
import android.content.IntentFilter;    
import android.net.wifi.ScanResult;    
import android.net.wifi.WifiConfiguration;   
import android.net.wifi.WifiManager;    
import android.os.Bundle;    
import android.util.Log;   
import android.view.View;    
import android.view.View.OnClickListener;    
import android.widget.*;
import android.widget.LinearLayout.*;
import android.net.wifi.*;

public class MainActivity extends Activity
{
    MainActivity ma;
    TextView textStatus; 
	Button buttonStart, buttonSend;
	EditText editMessages, editTo, editData; 
	
	String me = "polaroid";
	
	public class Message
	{
		public String from, to, via, data;
	}
	
	public class MessageList
	{
		public Message first;
		public MessageList next;
		public MessageList(Message f, MessageList n) 
		{
			first = f;
			next = n;
		}
	}
	
	MessageList toSend, received;
	Message message;
	

	public class ServerTask extends AsyncTask <Void, Void, Void>
	{

		TextView text1;
		MainActivity ma;

		public void trace (final String s)
		{
			// Toast.makeText(ma, "Server: " + s, Toast.LENGTH_LONG).show();
			// text1.append("\n" + s);
			ma.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						text1.append("\n"+s);
					}
				});
		}

		public ServerTask (MainActivity ma1)
		{
			super();
			this.ma = ma1;

		}

		@Override
		protected Void doInBackground (Void... params)
		{
			Looper.prepare();

			text1 = (TextView) ma.findViewById(R.id.text1);
			trace("doInBackground");

			try
			{

				int port = 1234;
				trace("Server");
				ServerSocket server = null;
				try
				{
					server = new ServerSocket(port);
					// server.setSoTimeout(2000);
				}
				catch (Exception e)
				{
					trace("Cannot initialize server: " + e);
				}

				trace("Loop");

				// while (true)
				{

					trace("Waiting");
					Socket client = server.accept();
					trace("Connected");

					BufferedReader in = new BufferedReader(
						new InputStreamReader(client.getInputStream()));

					// PrintStream out = new PrintStream(client.getOutputStream());
					PrintWriter out = new PrintWriter(client.getOutputStream(),true); 
					/*
					trace("Send");
					out.println("Hello from server");
					trace("Read");
					String message = in.readLine();
					trace ("Received: " + message);
					// Toast.makeText(this, "Received: " + message, Toast.LENGTH_LONG).show();
					*/
					
					MessageList l = toSend;
					while (l != null)
					{
						out.println(
						 l.first.from + "|" +
						 l.first.to + "|" +
						 l.first.via + "|" +
						 l.first.data);
						l = l.next;
					}
					out.println("END"); 
					
					while (true)
					{
						String line = in.readLine();
						if (line.equals("END"))
							break;
						String fields[] = line.split("|");
						Message m = new Message();
						m.from = fields[0];
						m.to = fields[1];
						m.via = fields[2] + ";" + me;
						m.data = fields[3];
						received = new MessageList(m, received);
						toSend = new MessageList(m, toSend); 
						if (m.to.equals(me))
						{
							editMessages.append(m.from + ": " + m.data + "\n");
						}
					}

					client.close();
					trace("Disconnected");

				}	


			}
			catch (Exception e)
			{
				// Toast.makeText(this, "Exception: " + e.getMessage(), Toast.LENGTH_LONG).show();
				trace("Exception: " + e); 
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			trace("onPostExecute");
			super.onPostExecute(result);
		}

		@Override
		protected void onPreExecute()
		{

		}

		@Override
		protected void onProgressUpdate(Void... values)
		{

		}


	}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		ma = this;
		
		textStatus = (TextView) findViewById(R.id.textStatus);
		buttonStart = (Button) findViewById(R.id.buttonStart);
		editMessages = (EditText) findViewById(R.id.editMessages);
		editTo = (EditText) findViewById(R.id.editTo);
		buttonSend = (Button) findViewById(R.id.buttonSend);
		editData = (EditText) findViewById(R.id.editData);
		
		buttonStart.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					Toast.makeText(ma, "Button Start clicked", Toast.LENGTH_LONG).show();
					
				}

			}); 
			
		buttonSend.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					Toast.makeText(ma, "Button Send clicked", Toast.LENGTH_LONG).show();
					message = new Message();
					message.from = me;
					message.to = editTo.getText().toString();
					message.via = "";
					message.data = editData.getText().toString();
					toSend = new MessageList(message, toSend);
				}

			}); 
		
		toSend = null;
		received = null;
		
    }
}
