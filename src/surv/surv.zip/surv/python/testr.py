HTTP/1.1 302 Found
Transfer-Encoding: chunked
Date: Fri, 29 Aug 2008 19:35:19 GMT
Content-Type: text/html; charset=iso-8859-1
Server: Apache
Location: http://www.multimania.lycos.fr/error/404.phtml

e2 
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0/
/EN">
<HTML><HEAD>
<TITLE>302 Found</TITLE>
</HEAD><BODY>
<H1>Found</H1>
The document has moved <A HREF="http://www.multimania.lycos.fr/error/404.phtml">here</A>.<P>
</BODY></HTML>

0


