
def encod(inp):
 outp=''
 i=0
 while i<len(inp):
  outp = outp + chr (0x40+(ord(inp[i])&0xf)) + chr (0x40+((ord(inp[i])&0xf0)>>4))
  i=i+1
 return outp
