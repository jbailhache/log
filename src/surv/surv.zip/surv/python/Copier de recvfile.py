
import sys
from socket import *
import time

def recvfile (filename):
  s=socket(AF_INET,SOCK_STREAM) 
  s.connect(('membres.lycos.fr',80))

  f=open(filename,'w')
 
  g= 'GET /teledev/' + filename + ' HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n'
  print g
  s.send(g)
  time.sleep(1)
  while 1:
    r=s.recv(256)
    print 'received <'+r+'>'
    # time.sleep(1)
    if len(r)==0:
      break
    f.write(r)
  s.close()
  f.close()


