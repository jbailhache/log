
import sys
from socket import *
import time

def codefile (filename):

 f=open(filename,'r')
 while 1:
  bloc=f.read(5)
  print 'bloc=<'+bloc+'>'
  if len(bloc)==0:
    break
  data=encod(bloc)
  print 'data=<'+data+'>'
  g= 'GET /teledev/tb8.php?filename=' + filename + '&data=' + data + ' HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n'
  print g 
  
  #print 'received <'+r+'>'
  
 f.close()


