
import sys
from socket import *
import time

def getfile (filename):
  data=''
  s=socket(AF_INET,SOCK_STREAM) 
  s.connect(('membres.lycos.fr',80))

  #f=open(filename,'w')
 
  g= 'GET /teledev/' + filename + ' HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n'
  print g
  s.send(g)
  time.sleep(1)
  s.setblocking(0)
  begin=time.time() 
  while 1:
    if time.time() - begin > 5: break
    try:
      r=s.recv(256)
      print 'received <'+r+'>'
      # time.sleep(1)
      # if len(r)==0:
      if not r :  
        time.sleep(1)
      else:
        #f.write(r)
        data=data+r
        begin=time.time() 
    except:
      pass
  print 'fin boucle'
  s.close()
  #f.close()
  print 'return'
  return data


