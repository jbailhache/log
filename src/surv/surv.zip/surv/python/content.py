
def content(str):
  pos=str.find('\r\n\r\n')
  cont=str[pos+4:]
  return cont
