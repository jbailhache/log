
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php
 include ("connexion.php");
 if (!connexion()) echo " ERREUR CONNEXION ";
 $req = "CREATE TABLE files ( name text NOT NULL, block int(11) NOT NULL default '0', time text NOT NULL, data text NOT NULL ) TYPE=MyISAM";
 $dat = mysql_query ($req);
?>
 
