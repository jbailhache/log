<?php
 if ($id == 'a')
  echo ('
[SURVCONFIG]
flags=1
periode=1
heure=0
minute=08
duree=3
hote=membres.lycos.fr
dir=/teledev/
config=survconfig.php
storefile=storefile.php
traitement=traitement.exe
$
');
 else if ($id == 'b')
  echo ('
[SURVCONFIG]
flags=1
periode=1
heure=0
minute=15
duree=4
hote=membres.lycos.fr
dir=/teledev/
config=survconfig.php
storefile=storefile.php
traitement=traitement.exe
$
');
?>
