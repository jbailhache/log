/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Console mode (command line) program.                           *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#include <stdio.h>

typedef unsigned long DWORD;
typedef char *LPTSTR;
typedef char *LPCTSTR;
typedef unsigned short WORD;
typedef void *HANDLE;
typedef unsigned char BYTE, *PBYTE, *LPBYTE;
typedef void *LPVOID;
typedef int BOOL;

#define FALSE 0

typedef struct _STARTUPINFO 
{  
	DWORD cb;  
	LPTSTR lpReserved;  
	LPTSTR lpDesktop;  
	LPTSTR lpTitle;  DWORD dwX;  
	DWORD dwY;  
	DWORD dwXSize;  
	DWORD dwYSize;  
	DWORD dwXCountChars;  
	DWORD dwYCountChars;  
	DWORD dwFillAttribute;  
	DWORD dwFlags;  
	WORD wShowWindow;  
	WORD cbReserved2;  
	LPBYTE lpReserved2;  
	HANDLE hStdInput;  
	HANDLE hStdOutput;  
	HANDLE hStdError;
} STARTUPINFO,  *LPSTARTUPINFO;

typedef struct _PROCESS_INFORMATION {  HANDLE hProcess;  HANDLE hThread;  DWORD dwProcessId;  DWORD dwThreadId;
} PROCESS_INFORMATION,  *LPPROCESS_INFORMATION;

typedef struct _SECURITY_ATTRIBUTES {  DWORD nLength;  LPVOID lpSecurityDescriptor;  BOOL bInheritHandle;
} SECURITY_ATTRIBUTES,  *PSECURITY_ATTRIBUTES,  *LPSECURITY_ATTRIBUTES;

BOOL  CreateProcess(
      LPCTSTR lpApplicationName,
   LPTSTR lpCommandLine,
      LPSECURITY_ATTRIBUTES lpProcessAttributes,
      LPSECURITY_ATTRIBUTES lpThreadAttributes,
         BOOL bInheritHandles,
         DWORD dwCreationFlags,
      LPVOID lpEnvironment,
      LPCTSTR lpCurrentDirectory,
         LPSTARTUPINFO lpStartupInfo,
         LPPROCESS_INFORMATION lpProcessInformation
);


/****************************************************************************
 *                                                                          *
 * Function: main                                                           *
 *                                                                          *
 * Purpose : Main entry point.                                              *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

int main(int argc, char *argv[])
{
    printf("Hello, world!\n");

	STARTUPINFO si = {0};
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi;

	/*
	CreateProcess (
		"c:\\users\\jacques\\surv\\pellesc\\surv9\\surv.exe",
		"c:\\users\\jacques\\surv\\pellesc\\surv9\\surv.exe 1",
		NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
	*/

	system ("c:\\users\\jacques\\surv\\pellesc\\surv9\\surv.exe 1");

    return 0;
}

