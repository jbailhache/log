
#include <stdio.h>

main (int argc, char *argv[])
{
FILE *f;
unsigned char c;
int i;
	f = fopen (argv[1], "rb");
	if (f==NULL)
	{
		perror(argv[1]);
		return;
	}

	for (i=0;;i++)
	{
		c = fgetc(f);
		if (feof(f)) break;
		if (i % 16 == 0)
			printf ("\n%4X:", i);
		printf ("%02X ", c);
	}
	
	fclose(f);		

}
