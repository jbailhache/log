
#include <stdio.h>

main ()
{
 FILE *f;
 f = fopen ("c:\\surv\\test.txt", "w");
 fprintf (f, "Test traitement quatrieme version\n");
 fclose(f);
}


