
#include <winsock.h>
#include <stdio.h>

#define MessageBox MessageBox1

void MessageBox1 (int hwnd, char *message, char *titre, int type)
{
 printf ("%s: %s\n", titre, message);
}

#define hwnd 0
#define MB_OK 0

WSADATA wsadata;
int port;
SOCKADDR_IN sa;
int status;
char buf[1000];
char mes[1000];
char rbuf[5000];
char abuf[10];
struct hostent *host;
SOCKET s;
IN_ADDR addr;

#define BLOCKSIZE 64
FILE *f;
char fbuf[BLOCKSIZE+1];
char cbuf[BLOCKSIZE*2+1];
int ofs, len;

encode(unsigned char *in, char *out, int len)
{
 int i;
 for (i=0; i<len; i++)
 {
  *out=0x40+*in&0xf;
  *(out+1)=0x40+(*in&0xf0)>>4;
 }
}

void bcopy (void *source, void *destination, int size)
{
	char *src = (char *)source;
	char *dst = (char *)destination;
	for (int i=0; i<size; i++)
		dst[i] = src[i];
}

void testweb ()
{
	
	MessageBox (hwnd, "Test", "Message", MB_OK);

	status = WSAStartup (0x101, &wsadata);

	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Socket cr��", "Message", MB_OK);

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr");
	if (host == NULL)
	{
		MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
		return;
	}
	MessageBox (hwnd, "gethost correct", "Message", MB_OK);

	 bcopy (host->h_addr_list[0], &sa.sin_addr.s_addr, host->h_length);  
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); */
       MessageBox (hwnd,  inet_ntoa(addr), "Adresse", MB_OK);

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));
	if (status)
	{
		MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Connect�", "Message", MB_OK);

	/*
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	/*
	sprintf (buf, "POST /teledev/cam/traiter.php HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\ndata=testdatafromc\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	*/

	/*sprintf (buf, "GET /teledev/cam/traiterget.php?data=testgetdatafromlcc HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
*/

 for (ofs=0; ; ofs++)
 {
  len=fread(fbuf,1,BLOCKSIZE,f);
  if (len<=0)
   break;
  encode(fbuf,cbuf,len);
  sprintf(buf,"GET /teledev/cam/traiterbloc.php?filename=capture.avi&ofs=%d&len=%d&data=%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n", ofs,len,cbuf);
  status=send(s,buf,strlen(buf),0)

	closesocket(s);
	status = WSACleanup();

}

main ()
{
 testweb ();
}

