main()
{
 printf ("Bonjour !\n");
}
