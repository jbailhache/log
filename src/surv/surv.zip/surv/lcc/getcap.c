
#include <winsock.h>
#include <stdio.h>
#include <errno.h>

#define MessageBox MessageBox1

void MessageBox1 (int hwnd, char *message, char *titre, int type)
{
 printf ("%s: %s\n", titre, message);
}

#define hwnd 0
#define MB_OK 0

WSADATA wsadata;
int port;
SOCKADDR_IN sa;
int status;
char buf[1000];
char mes[1000];
char rbuf[5000];
char abuf[10];
struct hostent *host;
SOCKET s;
IN_ADDR addr;

#define RSIZE 4096

void trace (int hw, char *s)
{
 printf ("trace: %s\n", s);
}

void bcopy (void *source, void *destination, int size)
{
	char *src = (char *)source;
	char *dst = (char *)destination;
	for (int i=0; i<size; i++)
		dst[i] = src[i];
}

int phase;
char c;
char buff[100];

void writedec (char *buf, int len, FILE *f)
{
char d;
int i;
 /* printf ("buf=<%s>\n", buf);  */
 for (i=0; i<len; i++)
 {
  if (buf[i] == '$')
  {
   printf ("Fin donnees i=%d reste=<%s>\n", i, buf+i);
   fclose(f);
   exit(0);
  }
  if (buf[i] >= '@' && buf[i] <= 'O')
  {
   if (phase == 0)
   {
    phase = 1;
    c = buf[i];
   }
   else
   {
    phase = 0;
    d = c - '@' + 16 * (buf[i] - '@');
    fputc (d, f);
    /* 
    printf ("i=%d phase=%d c='%c'=%02X buf[i]='%c' d=%02X", i, phase, c, c, buf[i], d);
    gets(buff);
    */
   }   
  }
 }

}

int main (int argc, char *argv[])
{
FILE *out;
int h, l, p, att, i, n;

	phase = 0;
	
	MessageBox (hwnd, "Test", "Message", MB_OK);

	status = WSAStartup (0x101, &wsadata);

	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Socket cr��", "Message", MB_OK);

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr");
	if (host == NULL)
	{
		MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
		return;
	}
	MessageBox (hwnd, "gethost correct", "Message", MB_OK);

	 bcopy (host->h_addr_list[0], &sa.sin_addr.s_addr, host->h_length);  
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); */
       MessageBox (hwnd,  inet_ntoa(addr), "Adresse", MB_OK);

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));
	if (status)
	{
		MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Connect�", "Message", MB_OK);

	/*
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	/*
	sprintf (buf, "POST /teledev/cam/traiter.php HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\ndata=testdatafromc\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	*/

	sprintf (buf, "GET /teledev/sendfile.php?name=%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n", argv[1]);
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	sprintf (mes, "Ouverture");
	trace (hwnd, mes);

	out = fopen (argv[1], "wb");
	if (out == NULL)
      {   
		MessageBox (hwnd, "Impossible d'ouvrir le fichier", "Erreur", MB_OK);
		return;
	}
	else
        {
		sprintf (mes, "out = %d", out);
		trace (hwnd, mes);
	}

	/*
	n = fwrite ("ABCDEF", 1, 6, out);
       sprintf (mes, "%d octets �crits errno=%d", n, errno);
	trace (hwnd, mes);
	*/
	h = 1;
	l = 0;
	p = 0;
loop:
	p++;
	status = recv (s, rbuf, RSIZE, 0);
	for (att=0; att<30000; att++);
	printf ("status = %d\n", status); 
        if (status > 0)
	{
		rbuf[status] = 0;
		/* printf ("Data received : <%s>\n", bigbuf); */
		/* printf ("rbuf=<%s>\n", rbuf); */
		/* trace (hwnd, rbuf); */

		if (p == 1)
		{
			for (i=0; i<status-4; i++)
			{
				if (!memcmp (rbuf+i, "DEBUT DES DONNEES", 17))
					break;
			}
			/*
			n = fwrite (rbuf+i+17, 1, status-i-17,  out);
			sprintf (mes, "%d octets �crits sur %d, errno=%d out=%d", n, status-i-17, errno, out);
			trace (hwnd, mes);
			*/
			writedec (rbuf+i+17, status-i-17, out);
		}
		else
	        {
			/*
			n = fwrite (rbuf, 1, status, out);
			sprintf (mes, "%d octets �crits sur %d, errno=%d out=%d", n, status, errno, out);
			trace (hwnd, mes);
			*/
			writedec (rbuf, status, out);
	        }
		/*for (i=0; i<status; i++)
			traiter(rbuf[i]);*/
		goto loop;
	}
	else
	{
		/* printf ("recv failed %d\n", status); */
		trace (hwnd,"\nDone.\n");
		fclose(out);
		trace (hwnd, "fichier ferm�");
	}


	closesocket(s);
	status = WSACleanup();

}


