/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Win32 application.                                     *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include "main.h"

#define NELEMS(a)  (sizeof(a) / sizeof((a)[0]))

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/

static HANDLE ghInstance;

#include <stdio.h>
#include <winsock.h>
#include <vfw.h>
#include <errno.h>

#define BLOCKSIZE 2048

#define FLAG_CAPTURE 1

struct config
{
	int flags, periode, heure, minute;
	char id[300], site[300], dir[300], config[300], storefile[300], traitement[300];
} config;

WSADATA wsadata;
int port;
SOCKADDR_IN sa;
int status;
char buf[1000];
char mes[30000];
char mes1[30000];
#define RSIZE 4096
char rbuf[RSIZE+16];
char abuf[10];
struct hostent *host;
SOCKET s;
IN_ADDR addr;
FILE *f;
char bloc[BLOCKSIZE+16];
char data[BLOCKSIZE*2+16];
int block;

FILE *f = NULL;

void trace1 (HWND hwnd, char *s)
{
	MessageBox (hwnd, s, "trace", MB_OK);
}

// #define trace(hw,str) { sprintf (mes1, "f=%d - %s", f, str); MessageBox (hw, mes1, "trace", MB_OK); } 

#define trace(hw,str) { sprintf (mes1, "f=%d - %s", f, str); }

#define erreur(hw,str)  trace(hw,str)

void bcopy (void *source, void *destination, int size)
{
	char *src = (char *)source;
	char *dst = (char *)destination;
	for (int i=0; i<size; i++)
		dst[i] = src[i];
}

void encod (char *in, char *out, int size)
{
	int i;
	for (i=0; i<size; i++)
	{
		out[2*i] = 0x40 + (in[i] & 0xF);
		out[2*i+1] = 0x40 + ((in[i] & 0xF0) >> 4);
		out[2*i+2] = 0;
	} 
}

/* #define OLD */

HWND capvideo;

void initcam (HWND hwnd)
{
	int i;

     capvideo = capCreateCaptureWindow(NULL,WS_CHILD|WS_VISIBLE,0,0,640,480, hwnd,1);

	/*for (i=0; i<10; i++) */

	/*
	i=1;
	{
		status = capDriverConnect (capvideo, i);
		sprintf (buf, "connect %d -> %d", i, status);
	}
	*/
}

void capturecam (HWND hwnd, char *filename)
{
       int i, status;
	char buf[1000];
	CAPTUREPARMS capparam;

	/*MessageBox (hwnd, "test", "Message", MB_OK);*/

#ifdef OLD
      HWND capvideo = capCreateCaptureWindow(NULL,WS_CHILD|WS_VISIBLE,0,0,640,480, hwnd,1);

	/*for (i=0; i<10; i++) */
	i=1;
	{
		status = capDriverConnect (capvideo, i);
		sprintf (buf, "connect %d -> %d", i, status);
		/* MessageBox (hwnd, buf, "Message", MB_OK); */
	}
#endif

	status = capDriverConnect (capvideo, 1);
	if (!status)
	{
		erreur (hwnd, "Impossible de connecter le pilote de la cam�ra");
		return;
	}

	status = capFileSetCaptureFile (capvideo, filename);
	if (!status)
	{
		erreur (hwnd, "Impossible de d�finir le fichier de capture");
		return;
	}

       status = capCaptureGetSetup(capvideo,&capparam,sizeof(capparam)) ;
	if (!status)
	{
		erreur (hwnd, "Impossible de r�cup�rer la configuration de capture");
		return;
	}

	capparam.dwRequestMicroSecPerFrame = 66667 ;
	capparam.fLimitEnabled = TRUE;
	capparam.wTimeLimit = 2;

	status = capCaptureSetSetup(capvideo,&capparam,sizeof(capparam)) ;
	if (!status)
	{
		erreur (hwnd, "Impossible de modifier la configuration de capture");
		return;
	}

	status = capCaptureSequence (capvideo);
	/*
	if (!status)
	{
		MessageBox (hwnd, "Impossible de capturer une s�quence", "Erreur", MB_OK);
		return;
	}
	*/

	status = capDriverDisconnect (capvideo);
	if (!status)
	{
		erreur (hwnd, "Impossible de d�connecter le pilote de la cam�ra");
		return;
	}

}

void sendfile (HWND hwnd, char *filename, SYSTEMTIME *pst)
{
	MSG msg;
	int fin;
	fin = 0;
	char strtime[100];

	trace (hwnd, "debut sendfile");

      status = WSAStartup (0x101, &wsadata);

	trace (hwnd, "ouverture");
      f = fopen (filename, "rb");
	
	block = 0;

	trace (hwnd, "avant boucle");
	for (;;)
	{
		trace (hwnd, "debut boucle");

		
			if (PeekMessage (&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage (&msg);
				DispatchMessage (&msg);
			}
		

		if (fin)
		{
			trace (hwnd, "fin");
			break;
	       }

		block++;

		sprintf (mes, "lecture %d", f);
		trace (hwnd, mes);
		status = fread (bloc, 1, BLOCKSIZE, f);
		sprintf (mes, "status=%d", status);
		trace (hwnd, mes);
		if (status < 1)
	      {
			status = 0;
			fin = 1;
	       }
		bloc[status]=0;
		/*MessageBox (hwnd, bloc, "bloc", MB_OK);*/
		/* trace (hwnd, bloc); */
		encod (bloc, data, BLOCKSIZE);
		trace (hwnd, data);
		/*MessageBox (hwnd, data, "data", MB_OK);*/

		trace (hwnd, "socket");
	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		// MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
			erreur (hwnd, "Impossible de cr�er socket");
		return;
       }
	/*MessageBox (hwnd, "Socket cr��", "Message", MB_OK);*/
		trace (hwnd, "socket cr��");

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr"); 
	/* host = gethostbyname("www.chez.com"); */
	if (host == NULL)
	{
		// MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
			erreur (hwnd, "Erreur gethostbyname");
		return;
	}
	/*MessageBox (hwnd, "gethost correct", "Message", MB_OK);*/
		trace (hwnd, "gethost correct");

	 bcopy (host->h_addr_list[0], &sa.sin_addr.s_addr, host->h_length); 

 
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); 

*/
       /*MessageBox (hwnd,  inet_ntoa(addr), "Adresse", MB_OK);*/

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));
	if (status)
	{
		// MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		erreur (hwnd, "Erreur connect");
		return;
       }
	/* MessageBox (hwnd, "Connect�", "Message", MB_OK); */
	trace (hwnd, "connect�");


	/* 
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n"); 
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	
		/* sprintf (buf, "GET /teledev/tb12.php?filename=%s&data=%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n", 
			filename, data); */
		/* sprintf (buf, "GET /log/tb12.php?filename=%s&data=%s HTTP/1.1\r\nHost: www.chez.com\r\n\r\n\r\n", 
			filename, data); */

		sprintf (strtime, "%04d-%02d-%02d-%02d-%02d",
			pst->wYear, pst->wMonth, pst->wDay, pst->wHour, pst->wMinute);
		sprintf (buf, "GET /teledev/storefile.php?name=%s&block=%d&time=%s&data=%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n",
			filename, block, strtime,  data);
		status = send (s, buf, strlen(buf), 0);
		sprintf (mes, "%d octets envoy�s", status);
		/*MessageBox (hwnd, mes, "Message", MB_OK);*/
		trace (hwnd, mes);

       status = recv (s, rbuf, RSIZE, 0);
	if (status > 0 && status < RSIZE)
	{
		rbuf[status] = 0;
		/*MessageBox (hwnd, rbuf, "Donn�es", MB_OK);*/
		trace (hwnd, rbuf);
	}
	else
	{
		/*MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);*/
		trace (hwnd, "fin des donn�es");
	}
		trace (hwnd, "closesocket");
		closesocket(s);
		trace (hwnd, "apr�s closesocket");
	}
	trace (hwnd, "fin sendfile");
}

void getfile (HWND hwnd, char *dist, char *loc, char *str)
{
int i;
FILE *out;
int h, l, p;
int n;
int pos;

	int att;

	status = WSAStartup (0x101, &wsadata);

	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		// MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
		erreur (hwnd, "Impossible de cr�er socket");
		return;
       }
	trace (hwnd, "Socket cr��"); 

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr");
	if (host == NULL)
	{
		// MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
		erreur (hwnd, "probl�me gethostbyname");
		return;
	}
	trace (hwnd, "gethost correct");

	 bcopy (host->h_addr_list[0], &sa.sin_addr.s_addr, host->h_length);  
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); */
       // trace (hwnd,  inet_ntoa(addr));

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));
	if (status)
	{
		// MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		erreur (hwnd, "Erreur connect");
		return;
       }
	trace (hwnd, "Connect�");

	/*
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	/*
	sprintf (buf, "POST /teledev/cam/traiter.php HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\ndata=testdatafromc\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	*/

	sprintf (buf, "GET /teledev/%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n", dist);
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	trace (hwnd, mes);

	sprintf (mes, "Ouverture <%s>", loc);
	trace (hwnd, mes);

	if (str != NULL)
	{
		pos = 0;
	}
	else
	{

	out = fopen (loc, "wb");
	if (out == NULL)
      {   
		// MessageBox (hwnd, "Impossible d'ouvrir le fichier de traitement", "Erreur", MB_OK);
		erreur (hwnd, "Impossible d'ouvrir le fichier de traitement");
		return;
	}
	else
      {
		sprintf (mes, "out = %d", out);
		trace (hwnd, mes);
	}
	}

	/*
	n = fwrite ("ABCDEF", 1, 6, out);
       sprintf (mes, "%d octets �crits errno=%d", n, errno);
	trace (hwnd, mes);
	*/
	h = 1;
	l = 0;
	p = 0;
loop:
	p++;
	status = recv (s, rbuf, RSIZE, 0);
	for (att=0; att<30000; att++);
	printf ("status = %d\n", status); 
      if (status > 0)
	{
		rbuf[status] = 0;
		/* printf ("Data received : <%s>\n", bigbuf); */
		printf ("%s", rbuf);/**/
		trace (hwnd, rbuf);

		if (p == 1)
		{
			for (i=0; i<status-4; i++)
			{
				if (!memcmp (rbuf+i, "\r\n\r\n", 4))
					break;
			}
			if (str != NULL)
		      {
				memcpy (str+pos, rbuf+i+4, status-i-4);
				pos += status-i-4;
			}
			else
			{
				n = fwrite (rbuf+i+4, 1, status-i-4,  out);
			}
			sprintf (mes, "%d octets �crits sur %d, errno=%d out=%d", n, status-i-4, errno, out);
			trace (hwnd, mes);
		}
		else
	      {
			if (str != NULL)
			{
				memcpy (str+pos, rbuf, status);
				pos += status;
			}
			else
			{
				n = fwrite (rbuf, 1, status, out);
			}
			sprintf (mes, "%d octets �crits sur %d, errno=%d out=%d", n, status, errno, out);
			trace (hwnd, mes);
	      }
		/*for (i=0; i<status; i++)
			traiter(rbuf[i]);*/
		goto loop;
	}
	else
	{
		/* printf ("recv failed %d\n", status); */
		trace (hwnd,"\nDone.\n");
		if (str != NULL)
		{
			str[pos]=0;
		}
		else
		{
			fclose(out);
		}
		trace (hwnd, "fichier ferm�");
	}

	closesocket(s);
	status = WSACleanup();

}

void getconfig ()
{
	FILE *cfg;
	char line[30000];

	cfg = fopen ("survconfig.txt", "r");
	for (;;)
	{
		fgets (line, sizeof(line), cfg);
		if (!strcmp(line,"[SURVCONFIG]\n"))
			break;
	}
	for (;;)
	{
		fgets (line, sizeof(line), cfg);
		if (!strcmp(line, "$\n"))
			break;
		
	}
}

void traitement (HWND hwnd, SYSTEMTIME *pst)
{
	char filename[1000];
	char configstr[1000];
	char configfile[1000];

	trace (hwnd, "debut");

	sprintf (configfile, "survconfig.php?id=%s", config.id);
	getfile (hwnd, configfile, "survconfig.txt", NULL);
	/* sscanf (configstr, "%d %d %d %d %s %s %s %s %s",
		&config.flags, &config.periode, &config.heure, &config.minute,
		config.site, config.dir, config.config, config.storefile, config.traitement); */
	getconfig ();

	sprintf (filename, "surv%02d%02d.avi", pst->wHour, pst->wMinute);
	trace (hwnd, "capture");
	capturecam (hwnd, filename);
	trace (hwnd, "envoi");
	sendfile (hwnd, filename, pst);   
	trace (hwnd, "getfile");
	getfile (hwnd, "traitement.exe", "traitement.exe", NULL);
	trace (hwnd, "system");
	system ("traitement");
	trace (hwnd, "fin");
}

void surv (HWND hwnd)
{
	SYSTEMTIME st;
	MSG msg;

	strcpy (config.id, "1");

	/*
	MessageBox (hwnd, "D�but", "message", MB_OK);
	traitement (hwnd, 31);
	MessageBox (hwnd, "Fin", "message", MB_OK);
	return;
	*/

	/*
	MessageBox (hwnd, "Transfert traitement.exe ...", "message", MB_OK);
	getfile (hwnd, "traitement.exe");
	MessageBox (hwnd, "fichier traitement.exe transf�r�", "message", MB_OK);
	*/

	/*
	GetLocalTime (&st);
	traitement (hwnd, st.wHour, st.wMinute);
	*/

	for (;;)
	{
		GetLocalTime (&st);
		/* if (st.wHour == 9 && (st.wMinute == 53 || st.wMinute == 55) && st.wSecond == 0) */
		/* if ((st.wHour % 4 == 1) && st.wMinute == 0) */
		/* if (st.wHour == 14 && st.wMinute == 4 && st.wSecond == 5) */
		if (st.wMinute % 10 == 6 && st.wSecond == 10)
		// if (st.wHour % 2 == 1 && st.wMinute == 15)
		// if (1)
			traitement(hwnd, &st);
		else
		{
			if (PeekMessage (&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage (&msg);
				DispatchMessage (&msg);
			}
		}
	}
}

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
    INITCOMMONCONTROLSEX icc;
    WNDCLASS wc;
    HWND hwnd;
    MSG msg;

    ghInstance = hInstance;

    /* Initialize common controls. Also needed for MANIFEST's */
    /*
     * TODO: set the ICC_???_CLASSES that you need.
     */
    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_WIN95_CLASSES /*|ICC_COOL_CLASSES|ICC_DATE_CLASSES|ICC_PAGESCROLLER_CLASS|ICC_USEREX_CLASSES*/;
    InitCommonControlsEx(&icc);

    /* Load Rich Edit control support */
    /*
     * TODO: uncomment one of the lines below, if you are using a Rich Edit control.
     */
    // LoadLibrary(_T("riched32.dll"));  // Rich Edit v1.0
    // LoadLibrary(_T("riched20.dll"));  // Rich Edit v2.0, v3.0

    /* Register the main window class */
    wc.lpszClassName = _T("survClass");
    wc.lpfnWndProc = MainWndProc;
    wc.style = CS_OWNDC|CS_VREDRAW|CS_HREDRAW;
    wc.hInstance = ghInstance;
    wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_ICO_MAIN));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName = MAKEINTRESOURCE(IDR_MNU_MAIN);
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    if (!RegisterClass(&wc))
        return 1;

    /* Create the main window */
    hwnd = CreateWindow(_T("survClass"),
        _T("surv Program"),
        WS_OVERLAPPEDWINDOW|WS_HSCROLL|WS_VSCROLL,
        0,
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        ghInstance,
        NULL
    );
    if (!hwnd) return 1;

    /* Show and paint the main window */
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

#ifndef OLD
	initcam (hwnd); 
#endif

	/* traitement (hwnd, 40, 1); */
	/*
	traitement (hwnd, 37, 2);
	traitement (hwnd, 37, 3);
	*/
	surv (hwnd);  

    /* Pump messages until we are done */
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT rc;

    BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);
    DrawText(ps.hdc, _T("Hello, Windows!"), -1, &rc, DT_SINGLELINE|DT_CENTER|DT_VCENTER);
    /* surv (hwnd);  */
	/* traitement (hwnd, 32); */
    EndPaint(hwnd, &ps);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}

/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
			/* surv(hDlg); */
			/* traitement (hDlg, 31, 0);  */
            /*
             * Nothing special to initialize.
             */
            return TRUE;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                    /*
                     * OK or Cancel was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}

