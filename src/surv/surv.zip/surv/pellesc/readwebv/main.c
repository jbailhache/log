/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Pocket PC application.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define UNICODE
#include <windows.h>
#include <windowsx.h>
#include <aygshell.h>
#include "main.h"

#include <winsock.h>

#define NELEMS(a)  (sizeof(a) / sizeof((a)[0]))

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static BOOL Main_OnCreate(HWND, CREATESTRUCT *);
static void Main_OnActivate(HWND, UINT, HWND, BOOL);
static void Main_OnSettingChange(HWND, UINT, PCTSTR);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/

static HANDLE ghInstance;
static HWND ghwndMB;
static SHACTIVATEINFO gsai = { sizeof(SHACTIVATEINFO) };

#define _stprintf swprintf

HWND ghwnd;
HWND hEdit1, hEdit2, hButton1;
int gotinput;
#define INSIZE 1000
wchar_t inbuf[INSIZE+1];
#define OUTSIZE 100
wchar_t outbuf[OUTSIZE+1];
int outptr = 0;
wchar_t *inptr = inbuf;
int insize = sizeof(inbuf);

char bigbuf[5000];

#define PAGESIZE 100000
wchar_t page[PAGESIZE];

int ptr;

wchar_t wbuf[6000];

int i, j;

printWSA (WSADATA *WSAdata)
{
	printf ("WSA data :\n");
	printf ("\tversion %x\n", WSAdata->wVersion);
	printf ("\thighest %x\n", WSAdata->wHighVersion);
	printf ("\tdescription <%s>\n", WSAdata->szDescription);
	printf ("\tstatus <%s>\n", WSAdata->szSystemStatus);
	printf ("\tmax sockets %d\n", WSAdata->iMaxSockets);
	printf ("\tmax datagram size %d\n", WSAdata->iMaxUdpDg);
}

readweb (HWND hwnd)
{
int x;
int status;
WORD version;
WSADATA WSAdata;
char buf[200 /*5000*/];
LPHOSTENT host;
LPSTR adr;
SOCKET s;
struct sockaddr FAR *addr;
/*struct sockaddr*/ SOCKADDR_IN sa;
int port;
LPPROTOENT proto;
int i;
char filename[120];
char buf1[80];
struct hostent *remotehost;

	version = 0x101;
       // status = WSAStartup (version, &WSAdata);
	status = 0;
	if (status)
	{
		swprintf   (wbuf,  100,L"WSAStartup failed %d", status); 
		MessageBox (hwnd, wbuf, L"Erreur", MB_OK); 
		return status;
    }

    printWSA (&WSAdata);
 
	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		MessageBox (hwnd, L"Cannot create socket", L"Erreur", MB_OK);
	}
	MessageBox  (hwnd, L"Socket created", L"Message", MB_OK);

	/*
	 printf ("Port [80] ? ");
	gets (buf);
    if (*buf)
		port = htons (atoi (buf));
	else
		port = htons (80);
	*/
	port = 80;

	
    /*
 	buf[0] = 194;
	buf[1] = 2;
	buf[2] = 222;
    buf[3] = 12;
	*/

	/*
	printf ("Server address : \n");
	for (i=0; i<4; i++)
	{
		printf ("\tpart %d ? ", i+1);
		gets (buf1);
             buf[i] = atoi (buf1);
       }
	

 	memcpy (&sa.sin_addr, buf, 4);
	*/

	// remotehost = gethostbyname ("www.commentcamarche.net");
	remotehost = gethostbyname ("www.eisti.fr");
	// remotehost = gethostbyname ("pagesperso-orange.fr");
	// remotehost = gethostbyname ("reinoldcat.free.fr");

	if (remotehost == NULL)
		MessageBox (hwnd, L"Erreur gethostbyname", L"Erreur", MB_OK);
	else
		MessageBox (hwnd, L"Succes gethostbyname", L"Message", MB_OK);

	memset  (&sa, 0, sizeof(sa));
	sa.sin_family = AF_INET;
	sa.sin_port = htons(port);
	memcpy (&sa.sin_addr, remotehost->h_addr, remotehost->h_length);

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));

	if (status)
	{
		swprintf (wbuf,100,L"Connect failed %d ", status);
		MessageBox (hwnd, wbuf, L"Erreur", MB_OK); 
		/*
		status = WSAGetLastError ();
		swprintf (wbuf,L"%d", status);
		MessageBox (hwnd, wbuf, L"Erreur", MB_OK); 
		*/
		return status;
	}
	MessageBox (hwnd, L"Connected",  L"Message", MB_OK);

	/*
	printf ("Data to send ? ");
	gets (buf);

	i = strlen (buf);
	buf[i] = 13;
	buf[i+1] = 10;
	buf[i+2] = 0;

	*/
/*
	printf ("File to receive ? ");
	gets (filename);
	sprintf (buf, "GET /%s\r\n", filename);
*/

	// sprintf (buf, "GET /sockets/sockintro.php3 HTTP/1.0\n\n");
	sprintf (buf, "GET /~bp/doc/reseaux/tp2.html HTTP/1.0\n\n");
	// sprintf (buf, "GET /mfturpaud/Cafe_philo.htm\n\n");
	//sprintf (buf, "GET /formation.htm\n\n");

	status = send (s, buf, /*sizeof(buf)*/ strlen(buf), 0);
 
	swprintf (wbuf, 100, L"%d bytes sent", status);
	MessageBox (hwnd, wbuf, L"Message", MB_OK); 
	swprintf (wbuf, 100,L"Data sent : <%s>", buf);
	MessageBox (hwnd, wbuf, L"Message", MB_OK);
	ptr = 0;
loop:
    // MessageBox  (hwnd, L"Data received : ", L"Message", MB_OK);

	status = recv (s, bigbuf, sizeof(bigbuf), 0);

	sprintf (wbuf, "recv -> %d", status);
	MessageBox (hwnd, wbuf, L"Message", MB_OK);

    if (status > 0) /* && status < sizeof(bigbuf))*/
	{
		bigbuf[status] = 0;
		/* printf ("Data received : <%s>\n", bigbuf); */
		/* printf ("%s", bigbuf); */
		for (i=0; i<status; i++)
			wbuf[i] = bigbuf[i];
		wbuf[i] = 0;
		// SendMessage (hEdit1, WM_SETTEXT, 0, (long)wbuf);
		if (ptr+status < PAGESIZE)
		{
			MessageBox (hwnd, L"Ajout�", L"Message", MB_OK);
			for (i=0, j=0; i<status; i++, j++)
			{
				if (wbuf[i] == (wchar_t)'\n')
					page[ptr+j++] = (wchar_t)'\r';
				page[ptr+j] = wbuf[i];
			}
			page[ptr+j] = 0;
			ptr += j;
			// memcpy (page+ptr, wbuf, ptr*sizeof(wchar_t)); 
		}
		else
		{
			MessageBox (hwnd, L"Non ajout�", L"Message", MB_OK);
		}
		goto loop; 
	}
	else
	{
		/* printf ("recv failed %d\n", status); */
		SendMessage (hEdit1, WM_SETTEXT, 0, (long)page);
		MessageBox  (hwnd, L"Done.", L"Message", MB_OK);
	}

    /*
    printf ("Data received : \n");
	for (i=0; i<200; i++)
	{
		status = recv (s, (char FAR *)buf, 1, 0);
        printf ("%c", buf[0]);
	}
	*/
    closesocket (s);

	/* gets (buf); */
	status = WSACleanup ();
	if (status)
	{
		MessageBox (hwnd, L"WSACleanup failed ", L"Erreur", MB_OK);
		return status;
	}
	return 0;
}

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

/*int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpszCmdLine, int nCmdShow)*/

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
    HWND hwnd;
    MSG msg;

    /* Always check first if program is already running */
    hwnd = FindWindow(L"readwebClass", NULL);
    if (hwnd)
    {
        /*
         * Set focus to the foremost child window. The "|0x01" is used to
         * bring any owned windows to the foreground and activate them.
         */
        SetForegroundWindow((HWND)((ULONG)hwnd|0x00000001));
        return 0;
    }

    if (!hPrevInstance)
    {
        WNDCLASS wc;

        wc.lpszClassName = L"readwebClass";
        wc.lpfnWndProc = MainWndProc;
        wc.style = CS_VREDRAW|CS_HREDRAW;
        wc.hInstance = hInstance;
        wc.hIcon = NULL;
        wc.hCursor = NULL;
        wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
        wc.lpszMenuName = NULL;
        wc.cbClsExtra = 0;
        wc.cbWndExtra = 0;

        if (!RegisterClass(&wc))
            return 1;
    }

    ghInstance = hInstance;

    hwnd = CreateWindowEx(
        0,
        L"readwebClass",
        L"readweb Program",
        WS_VISIBLE|WS_SYSMENU,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );
    if (!hwnd) return 1;

    /*
     * When CW_USEDEFAULT is used to create the main window, the height of the
     * menu bar is not considered. We must manually reserve space for the menu.
     */
    if (ghwndMB)
    {
        RECT rcWin, rcMB;

        GetWindowRect(hwnd, &rcWin);
        GetWindowRect(ghwndMB, &rcMB);
        rcWin.bottom -= (rcMB.bottom - rcMB.top);
        MoveWindow(hwnd, rcWin.left, rcWin.top, rcWin.right - rcWin.left, rcWin.bottom - rcWin.top, FALSE);
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_CREATE, Main_OnCreate);
        HANDLE_MSG(hwnd, WM_ACTIVATE, Main_OnActivate);
        HANDLE_MSG(hwnd, WM_SETTINGCHANGE, Main_OnSettingChange);
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCreate                                                  *
 *                                                                          *
 * Purpose : Process a WM_CREATE message.                                   *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static BOOL Main_OnCreate(HWND hwnd, CREATESTRUCT *pcs)
{
    SHMENUBARINFO mbi;

    memset(&mbi, 0, sizeof(mbi));
    mbi.cbSize = sizeof(mbi);
    mbi.hwndParent = hwnd;
    mbi.nToolBarId = IDR_MNU_MAIN;
    mbi.hInstRes = ghInstance;
    mbi.nBmpId = 0;
    mbi.cBmpImages = 0;
	/* specifique pocket pc
    if (!SHCreateMenuBar(&mbi))  
        return FALSE;
	*/

    ghwndMB = mbi.hwndMB;

 hEdit1 = CreateWindow (L"EDIT", L"", 
		WS_VISIBLE|WS_CHILD|WS_BORDER|WS_VSCROLL|WS_HSCROLL|
		ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL|ES_AUTOVSCROLL,
		// 10, 10, 300, 60,
		10, 1, 300, 80,
		hwnd, NULL, ghInstance, NULL);

 hEdit2 = CreateWindow (L"EDIT", L"",
		WS_CHILD | WS_VISIBLE | ES_LEFT | WS_BORDER,
		// 10, 80, 240, 20,
		10, 83, 240, 18,
		hwnd, NULL, ghInstance, NULL);

 hButton1 = CreateWindow (L"BUTTON", L"OK", 
		WS_CHILD | WS_VISIBLE | ES_LEFT | WS_BORDER,
		// 260, 80, 40, 20,
		260, 83, 40, 18,
		hwnd, NULL, ghInstance, NULL);

    return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnActivate                                                *
 *                                                                          *
 * Purpose : Process a WM_ACTIVATE message.                                 *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnActivate(HWND hwnd, UINT state, HWND hwndActDeact, BOOL fMinimized)
{
    /* Notify the shell of our activate message */

    /* specifique pocket pc
	SHHandleWMActivate(hwnd, MAKEWPARAM(state,fMinimized), (LPARAM)hwndActDeact, &gsai, 0); */

}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnSettingChange                                           *
 *                                                                          *
 * Purpose : Process a WM_SETTINGCHANGE message.                            *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnSettingChange(HWND hwnd, UINT uiAction, PCTSTR pszSection)
{
    switch (uiAction)
    {
        case SPI_SETSIPINFO:
        {
            /* Adjust window size depending on SIP panel */
            /* specifique pocket pc
			SHHandleWMSettingChange(hwnd, -1, 0, &gsai); */
            break;
        }
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT rc;

    BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);
    // DrawText(ps.hdc, L"Hello, Windows CE!", -1, &rc, DT_CENTER|DT_VCENTER);
    EndPaint(hwnd, &ps);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	if (hwndCtl == hButton1)
	{
		// SendMessage (hEdit1, WM_SETTEXT,  0, (long) L"Bonjour !");
		// OnButton1();
		readweb (hwnd);
		return;
	}
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE, 0, 0);
            break;

        default:
            FORWARD_WM_COMMAND(hwnd, id, hwndCtl, codeNotify, DefWindowProc);
            break;

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnDestroy(HWND hwnd)
{
    DestroyWindow(ghwndMB);
    PostQuitMessage(0);
}

/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            SHINITDLGINFO shidi;

            /*
             * Create a Done button and size the dialog.
             */
            shidi.dwMask = SHIDIM_FLAGS;
            shidi.dwFlags = SHIDIF_DONEBUTTON|SHIDIF_SIPDOWN|SHIDIF_SIZEDLGFULLSCREEN;
            shidi.hDlg = hDlg;
            /* specifique pocket pc
		 SHInitDialog(&shidi);  */
            return TRUE;
        }

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                    /*
                     * OK was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
			PostQuitMessage(0);
			exit(0);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}
