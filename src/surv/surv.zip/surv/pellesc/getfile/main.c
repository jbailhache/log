/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Win32 application.                                     *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <tchar.h>
#include "main.h"

#define NELEMS(a)  (sizeof(a) / sizeof((a)[0]))

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/

static HANDLE ghInstance;

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
    INITCOMMONCONTROLSEX icc;
    WNDCLASS wc;
    HWND hwnd;
    MSG msg;

    ghInstance = hInstance;

    /* Initialize common controls. Also needed for MANIFEST's */
    /*
     * TODO: set the ICC_???_CLASSES that you need.
     */
    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_WIN95_CLASSES /*|ICC_COOL_CLASSES|ICC_DATE_CLASSES|ICC_PAGESCROLLER_CLASS|ICC_USEREX_CLASSES*/;
    InitCommonControlsEx(&icc);

    /* Load Rich Edit control support */
    /*
     * TODO: uncomment one of the lines below, if you are using a Rich Edit control.
     */
    // LoadLibrary(_T("riched32.dll"));  // Rich Edit v1.0
    // LoadLibrary(_T("riched20.dll"));  // Rich Edit v2.0, v3.0

    /* Register the main window class */
    wc.lpszClassName = _T("getfileClass");
    wc.lpfnWndProc = MainWndProc;
    wc.style = CS_OWNDC|CS_VREDRAW|CS_HREDRAW;
    wc.hInstance = ghInstance;
    wc.hIcon = LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_ICO_MAIN));
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName = MAKEINTRESOURCE(IDR_MNU_MAIN);
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    if (!RegisterClass(&wc))
        return 1;

    /* Create the main window */
    hwnd = CreateWindow(_T("getfileClass"),
        _T("getfile Program"),
        WS_OVERLAPPEDWINDOW|WS_HSCROLL|WS_VSCROLL,
        0,
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        ghInstance,
        NULL
    );
    if (!hwnd) return 1;

    /* Show and paint the main window */
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    /* Pump messages until we are done */
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnPaint(HWND hwnd)
{
    PAINTSTRUCT ps;
    RECT rc;

    BeginPaint(hwnd, &ps);
    GetClientRect(hwnd, &rc);
    DrawText(ps.hdc, _T("Hello, Windows!"), -1, &rc, DT_SINGLELINE|DT_CENTER|DT_VCENTER);
    EndPaint(hwnd, &ps);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static void Main_OnDestroy(HWND hwnd)
{
    PostQuitMessage(0);
}

#include <winsock.h>
#include <stdio.h>

#define RSIZE 5000

WSADATA wsadata;
int port;
SOCKADDR_IN sa;
int status;
char buf[1000];
char mes[1000];
char rbuf[RSIZE+1];
char abuf[10];
struct hostent *host;
SOCKET s;
IN_ADDR addr;

int i;
FILE *out;
int h, l, p;

void bcopy (void *source, void *destination, int size)
{
	char *src = (char *)source;
	char *dst = (char *)destination;
	for (int i=0; i<size; i++)
		dst[i] = src[i];
}


void getfile (HWND hwnd, char *filename)
{
	/* MessageBox (hwnd, "Test", "Message", MB_OK); */

	status = WSAStartup (0x101, &wsadata);

	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
		return;
       }
	/* MessageBox (hwnd, "Socket cr��", "Message", MB_OK); */

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr");
	if (host == NULL)
	{
		MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
		return;
	}
	/* MessageBox (hwnd, "gethost correct", "Message", MB_OK); */

	 bcopy (host->h_addr_list[0], &sa.sin_addr.s_addr, host->h_length);  
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); */
       /* MessageBox (hwnd,  inet_ntoa(addr), "Adresse", MB_OK); */

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, (LPSOCKADDR)&sa, sizeof(sa));
	if (status)
	{
		MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		return;
       }
	/* MessageBox (hwnd, "Connect�", "Message", MB_OK); */

	/*
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	/*
	sprintf (buf, "POST /teledev/cam/traiter.php HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\ndata=testdatafromc\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	*/

	sprintf (buf, "GET /teledev/%s HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n", filename);
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	/* MessageBox (hwnd, mes, "Message", MB_OK); */

	out = fopen (filename, "wb");
	h = 1;
	l = 0;
	p = 0;
loop:
	p++;
	status = recv (s, rbuf, RSIZE, 0);
	printf ("status = %d\n", status); 
      if (status > 0)
	{
		rbuf[status] = 0;
		/* printf ("Data received : <%s>\n", bigbuf); */
		printf ("%s", rbuf);
		if (p == 1)
		{
			for (i=0; i<status-4; i++)
			{
				if (!memcmp (rbuf+i, "\r\n\r\n", 4))
					break;
			}
			fwrite (rbuf+i+4, status-i-4, 1, out);
		}
		else
			fwrite (rbuf, status, 1, out);
		/*for (i=0; i<status; i++)
			traiter(rbuf[i]);*/
		goto loop;
	}
	else
	{
		/* printf ("recv failed %d\n", status); */
		printf ("\nDone.\n");
		fclose(out);
	}

	closesocket(s);
	status = WSACleanup();
}


/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
			getfile (hDlg, "traitement.exe");
            /*
             * Nothing special to initialize.
             */
            return TRUE;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                    /*
                     * OK or Cancel was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}

