
#include <errno.h>


main (int argc, char *argv[])
{
 errno = atoi(argv[1]);
 perror("Erreur");
}