
#include <stdio.h>

main ()
{
 FILE *f;
 f = fopen ("test.txt", "w");
 fprintf (f, "Test traitement modifi�\n");
 fclose(f);
}


