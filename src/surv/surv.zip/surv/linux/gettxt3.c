
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>

#define MessageBox MessageBox1

void MessageBox1 (int hwnd, char *message, char *titre, int type)
{
 printf ("%s: %s\n", titre, message);
}

#define hwnd 0
#define MB_OK 0

/* WSADATA wsadata; */
int port;
struct sockaddr_in sa;
int status;
char buf[1000];
char mes[1000];
char rbuf[5000];
char abuf[10];
struct hostent *host;
int s;
/*IN_ADDR addr;*/
int i;
FILE *out;
int h, l, p;

/*
void bcopy (void *source, void *destination, int size)
{
	int i;
	char *src = (char *)source;
	char *dst = (char *)destination;
	for (i=0; i<size; i++)
		dst[i] = src[i];
}
*/

/*
traiter (char c)
{
	if (h)
	{
		if (l)
		{
			if (c == 
}
*/

void testweb ()
{
	
	MessageBox (hwnd, "Test", "Message", MB_OK);

	/* status = WSAStartup (0x101, &wsadata); */

	s = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s < 0)
	{
		MessageBox (hwnd, "Impossible de cr�er socket", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Socket cr��", "Message", MB_OK);

	memset (&sa, 0, sizeof(sa));
	port = htons(80);
	sa.sin_family = AF_INET;
	sa.sin_port = port;
	sa.sin_addr.s_addr = INADDR_ANY;

	/* sin_addr */
	host = gethostbyname ("membres.lycos.fr");
	if (host == NULL)
	{
		MessageBox (hwnd, "probl�me gethost", "Erreur", MB_OK);
		return;
	}
	MessageBox (hwnd, "gethost correct", "Message", MB_OK);

	bcopy (host->h_addr, &sa.sin_addr.s_addr, host->h_length);  
	/* memcpy (&sa.sin_addr.s_addr, host->h_addr_list, host->h_length); */ 
        /* MessageBox (hwnd,  inet_ntoa(addr), "Adresse", MB_OK); */

	/* sa.sin_addr.s_addr = inet_addr(inet_ntoa(addr));  */

	/*
	abuf[0] = 209;
	abuf[1] = 202;
	abuf[2] = 230;
	abuf[3] = 30;
	*/
	abuf[3] = 209;
	abuf[2] = 202;
	abuf[1] = 230;
	abuf[0] = 30;
	/* memcpy (&sa.sin_addr, buf, 4); */

	status = connect (s, &sa, sizeof(sa));
	if (status)
	{
		MessageBox (hwnd, "Erreur connect", "Erreur", MB_OK);
		return;
       }
	MessageBox (hwnd, "Connect�", "Message", MB_OK);

	/*
	sprintf (buf, "GET /teledev/cam/test.htm HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);

	status = recv (s, rbuf, sizeof(rbuf), 0);
	if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		MessageBox (hwnd, rbuf, "Donn�es", MB_OK);
	}
	else
	{
		MessageBox (hwnd, "Fin des donn�es", "Message", MB_OK);
	}
	*/

	/*
	sprintf (buf, "POST /teledev/cam/traiter.php HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\ndata=testdatafromc\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	*/

	
	sprintf (buf, "GET /teledev/test.txt HTTP/1.1\r\nHost: membres.lycos.fr\r\n\r\n\r\n");
	status = send (s, buf, strlen(buf), 0);
	sprintf (mes, "%d octets envoy�s", status);
	MessageBox (hwnd, mes, "Message", MB_OK);
	
	out = fopen ("testr.txt", "wb");
	h = 1;
	l = 0;
	p = 0;
loop:
	p++;
	status = recv (s, rbuf, sizeof(rbuf), 0);
        if (status > 0 && status < sizeof(rbuf))
	{
		rbuf[status] = 0;
		/* printf ("Data received : <%s>\n", bigbuf); */
		printf ("%s", rbuf);
		if (p == 1)
		{
			for (i=0; i<status-4; i++)
			{
				if (!memcmp (rbuf+i, "\r\n\r\n", 4))
					break;
			}
			fwrite (rbuf+i+4, status-i-4, 1, out);
		}
		else
			fwrite (rbuf, status, 1, out);
		/*for (i=0; i<status; i++)
			traiter(rbuf[i]);*/
		goto loop;
	}
	else
	{
		/* printf ("recv failed %d\n", status); */
		printf ("\nDone.\n");
		fclose(out);
	}



	close(s);
	/* status = WSACleanup(); */

}

main ()
{
 testweb ();
}

