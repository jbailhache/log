
#include <stdio.h>

main ()
{
int i;
FILE *f;
	f = fopen ("grosfichier.txt", "w");
	for (i=1; i<=1000; i++)
		fprintf (f, "Ligne %d\n", i);
	fclose(f);
}

