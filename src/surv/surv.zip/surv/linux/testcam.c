
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/videodev.h>

#include <unistd.h> 
#include <sys/mman.h>

/* #include <pngdriver.h> */

#define VIDEO "/dev/video0"

main ()
{
  int fdv;
  int i;

  int width = 640;
  int height = 480;

  fdv = open (VIDEO, O_RDWR);
  if (fdv <= 0)
    {
      perror (VIDEO);
      exit(1);
    }

  struct video_capability vcap;
  struct video_mmap mm;

  if (ioctl (fdv, VIDIOCGCAP, &vcap) < 0)
    {
      perror("VIDIOCGCAP");
      exit(1);
    }

  printf ("video capture device name : %s\n", vcap.name);

  if (!(vcap.type & VID_TYPE_CAPTURE))
    {
      printf ("Le peripherique ne supporte pas la capture\n");
      exit(1);
    }

  struct video_window fenetre;
  fenetre.x = 0;
  fenetre.y = 0;
  fenetre.width = width;
  fenetre.height = height;
  fenetre.clipcount = 0;
  fenetre.chromakey = 0;

  if (ioctl (fdv, VIDIOCSWIN, &fenetre) < 0)
    {
      perror("VIDIOCSWIN");
      exit(1);
    }

  if (ioctl (fdv, VIDIOCGWIN, &fenetre) < 0)
    {
      perror ("VIDIOCGWIN");
      exit(1);
    }

  struct video_channel vc;
  for (i=0; i<vcap.channels; i++)
    {
      vc.channel = i;
      if (ioctl (fdv, VIDIOCGCHAN, &vc) < 0)
	{
	  perror ("VIDIOCGCHAN");
	  exit (1);
	}
      printf ("video source (%d) name : %s\n", i, vc.name);
    }
  
  vc.channel = 0;
  if (ioctl(fdv,VIDIOCSCHAN,&vc) < 0)
    {
      perror("VIDIOCSCHAN");
      exit(1);
    }

  /*
  if (ioctl (fdv, VIDIOCGMBUF, &mbuf) < 0)
    {
      perror("VIDIOCGMBUF");
      exit(1);
    }
  */

  unsigned char *framebuf;
  framebuf = (unsigned char *) mmap (0, 3 * width * height, PROT_READ | PROT_WRITE, MAP_SHARED, fdv, 0);
  if ((unsigned char *)-1 == (unsigned char *)framebuf)
    {
      perror ("mmap");
      exit(1);
    }

  mm.frame = 0;
  mm.height = height;
  mm.width = width;
  mm.format = VIDEO_PALETTE_RGB24;

  if (ioctl(fdv,VIDIOCMCAPTURE,&mm) < 0)
    {
      perror("VIDIOMCAPTURE");
      exit(1);
    }

  /*
  if (ioctl (fdv, VIDIOCSYNC, &mm.frame) < 0)
    {
      perror("VIDIOCSYNC");
      exit(1);
    }
  */

  i = -1;
  while (i<0)
    {
      i = ioctl (fdv, VIDIOCSYNC, &mm.frame);
      if (i < 0)
	{ 
	  perror ("VIDIOCSYNC");
	  exit(1);
	}
      if (errno == EINTR)
	continue;
      else
	break;
    }


  /* write_ppm ("img.ppm", framebuf, width, height); */

  FILE *fp;
  fp = fopen ("capture.ppm", "wb");
  if (fp == NULL)
    {
      perror ("Impossible de créer le fichier PPM");
      exit(1);
    }
  fprintf (fp, "P6\n%d %d\n255\n", width, height);
  int x, y, p, r, g, b;
  p = 0;
  for (y=0; y<height; y++)
    {
      for (x=0; x<width; x++)
	{
	  b = framebuf[p++];
	  g = framebuf[p++];
	  r = framebuf[p++];
	  putc (r, fp);
	  putc (g, fp);
	  putc (b, fp);
	}
    }
  fflush(fp);
  fclose(fp);

  close(fdv);


}
