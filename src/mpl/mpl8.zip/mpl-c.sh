./mplc_labels.pl $1.mpls $1.mpli
./mplc_ids.pl $1.mpli $1.mplo
./mpli $1.mplo

