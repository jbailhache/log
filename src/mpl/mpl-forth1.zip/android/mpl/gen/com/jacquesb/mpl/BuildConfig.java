/** Automatically generated file. DO NOT MODIFY */
package com.jacquesb.mpl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}