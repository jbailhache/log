package com.jacquesb.mpl;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*; 
import android.view.View.OnClickListener;
import android.util.Log;

import java.io.*;

public class MainActivity extends Activity
 implements View.OnClickListener
{
    TextView t1 = null;
	EditText e0 = null;
    EditText e1 = null;
	EditText e2 = null; 
	EditText e3 = null;
	EditText e4 = null; 
    Button b = null;

    int wordsize=8;
    int i;
    int pc, r0, r1, rc, ru, ri, ro;
    int t;
    int state;
	char exs = 'Q'; 
    
    int memsize = 0xF000;
    int mem[] = new int[memsize];
	
    // String mplo = ";;;;;;;;;#7000,i#|o#H{#,#6000?}#6000H{#7001r,#7003wQ}Q";
	// String mplo = "#7000,i#|o#7001r,#7003wQ";
	// String mplo = "#2000H{#3FPG,#1+PG,#2+PG,#3+PQ}#,#2000?";
    String mplo = ";;;;;;;;;#7000,i#|o#H{#,#6000?}#6000H{#7001r,#7003w#41P#42P#43PG,#1+P#45PQ}Q";
	String input = "";
	String output = ""; 
	String ti = "";
	
    public void trace (String s) 
    {
        // Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); 
	    Log.d ("mpl", s);
    }	
	
	public String readfile1 (String filename)
	{
		return "Q("+filename+")";
	}
	
	public String readfile (String filename)
	{	
	    String s = "";
		String line = "";
		try
		{
		 BufferedReader f = new BufferedReader 
		  (new InputStreamReader 
		   (new FileInputStream (filename)));
		 while (true)
		 {
			try
			{
				line = f.readLine();
				s += line;
				if (line == null)
				 break;
			}
			catch (Exception e)
			{
				break;
			}
		 }
		 f.close(); 
		 return s;
		}
		catch (Exception e)
		{
			 return "Q "+e.getMessage();
		}		
	}
	
    public void mpli ()
    {
       boolean cont = true;
	   
       char instr;
       while (cont)
       {
           instr = (char)(mem[pc++]);
		   ti += instr;
           trace ("pc="+new Integer(pc).toString()+" instr="+new Character(instr).toString());
           if (state == 1)
           {
               if (instr == '}')
                   state = 0;
               else
                   mem[rc++] = (int)instr;
           }
           else if (state == 0)
           {
             switch (instr)
             {
               case ',': r1=r0; break;
               case 'X': t=r0; r0=r1; r1=t; break;
               case 'p': r0=pc; break;
               case '?': if (r1==0) { r1=pc; pc=r0; } break;
               case 'R': case 'r': r0=mem[r0]; break;
               case 'W': case 'w': mem[r0]=r1; break;
               case '#': r0=0; break;

               case '0': r0=r0*16; break;
               case '1': r0=r0*16+1; break;
               case '2': r0=r0*16+2; break;
               case '3': r0=r0*16+3; break;
               case '4': r0=r0*16+4; break;
               case '5': r0=r0*16+5; break;
               case '6': r0=r0*16+6; break;
               case '7': r0=r0*16+7; break;
               case '8': r0=r0*16+8; break;
               case '9': r0=r0*16+9; break;
               case 'A': r0=r0*16+10; break;
               case 'B': r0=r0*16+11; break;
               case 'C': r0=r0*16+12; break;
               case 'D': r0=r0*16+13; break;
               case 'E': r0=r0*16+14; break;
               case 'F': r0=r0*16+15; break;

               case '~': r0 = ~r0; break;
               case '+': r0=r0+r1; break;
               case '-': r0=r0-r1; break;
               case '*': r0=r0*r1; break;
               case '/': r0=r0/r1; break;
               case '%': r0=r0%r1; break;
               case '&': r0=r0&r1; break;
               case '^': r0=r0^r1; break;
               case '|': r0=r0|r1; break;
               case '<': r0=r0<<r1; break;
               case '>': r0=r0>>r1; break;

               case 'H': rc=r0; break;
               case 'h': r0=rc; break;
               case '{': state = 1; break;
               case '}': mem[rc++] = (int)(instr); break;
               case '_': mem[rc++]=r0; break;
               case 's': r0=wordsize; break;

               case 'e': break;

               case 'u': r0=ru; break;
               case 'U': ru=r0; break;
               case 'J': t=r0; 
                         r0=mem[t]; 
                         r1=mem[t+wordsize]; 
                         pc=mem[t+2*wordsize]; 
                         break;

               // case 'd': t=rd; rd=r0; r0=t; break;
               case 'i': t=ri; ri=r0; r0=t; break; 
			   case 'o': t=ro; ro=r0; r0=t; break; 
			   
			   case 'G':
			    if (input.equals(""))
				{
					pc -= 1;
					exs = 'G';
					cont = false;
				}
				else
				{
					r0 = (int)input.charAt(0);
					input = input.substring(1);
				}
			    break;
				
			   case 'P':
			    output += (char)r0;
				break; 
				
               case 'Q': cont=false; exs='Q'; break; 

               case ';': case ' ': case '\n': case '\r': case '\t': break;

               default: mem[ru]=r0; 
                        mem[ru+wordsize]=r1; 
                        mem[ru+2*wordsize]=pc; 
                        pc=ru+3*wordsize; 
                        break;
             }
          }
       } 
    }

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		t1 = (TextView) findViewById(R.id.text1);
		e0 = (EditText) findViewById(R.id.edit0); 
        e1 = (EditText) findViewById(R.id.edit1);
		e2 = (EditText) findViewById(R.id.edit2);
        e3 = (EditText) findViewById(R.id.edit3);
		e4 = (EditText) findViewById(R.id.edit4);
        b = (Button) findViewById(R.id.button1);
       
	    b.setOnClickListener(this);

        trace ("mplo="+mplo);
		e1.setText(mplo); 
        int iq=(int)'Q';
        String sq=new Integer(iq).toString();
        trace("sq="+sq);
        for (i=0; i<mplo.length(); i++)
        {
            mem[i] = (int)(mplo.charAt(i));
            trace("mem["+new Integer(i).toString()+"]="+new Integer(mem[i]).toString());
        }
		
        pc = 0;
        r0 = 0;
        r1 = 0;
        rc = 0;
        ru = 0;
        ri = 0;
		ro = 0;
		/*
        mpli();
		*/
		String mplo1 = "";
		i = 0;
		while (mem[i]!=0)
		{
			mplo1 = mplo1 + (char)(mem[i]);
			i++;
		}
		e1.setText (mplo1);

    }
	
    @Override
    public void onClick (View v)
    {
		String mplo1;
		String filename = "";
	    if (exs == 'Q')
		{
		 t1.setText("init");
		 filename = e0.getText().toString();
		 if (filename.length()>0)
		 {
			 mplo1 = readfile (filename);
			 if (mplo1.length() > 0) 
			  e1.setText(mplo1);
			 else
			  mplo1 = e1.getText().toString()+" Error";
		 }
		 else
		  mplo1 = e1.getText().toString(); 
	 	 for (i=0; i<mplo1.length(); i++)
		  mem[i] = (int)(mplo1.charAt(i));
		 
		 pc = 0; 
		 r0 = 0;
		 r1 = 0; 
		 rc = 0;
		 ru = 0;
		 ro = 0;
		 
		 input = "";
		 output = "";
		 ti = "";
		 // if (filename.length()==0)
	 	 mpli(); 
		}
		else
		 t1.setText("cont ");
		
        // e.setText (e.getText().toString()+ e.getText().toString());
        String s = e2.getText().toString();
		trace("s="+s+".");
        for (i=0; i<s.length(); i++)
            mem[ri+i] = (char)(s.charAt(i));
        mem[ri+s.length()] = 0;
		
		input = e4.getText().toString();
		if (exs == 'Q')
	 	 pc=0;
		// if (filename.length()==0)
        mpli();
        i = 0;
        String t = "";
        while (mem[ro+i] != 0)
		{
			trace("ro="+new Integer(ro).toString()+" mem[rd+"+new Integer(i).toString()+"]="+new Integer(mem[ro+i]).toString());
            // t = t + new Character((char)(mem[rd+i])).toString();
			t = t + (char)(mem[ro+i]);
	        i = i+1;
		}
		trace("t="+t+".");
        e2.setText(t);
		e3.setText(output);
		output = ""; 
		t1.setText (" "+exs+" "+ti);
		ti = "";
    }
}
