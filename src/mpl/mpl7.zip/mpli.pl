#!/usr/bin/perl

my $trace = 0;

my $nargs = @ARGV;
my $script;
my $inputf;
my $outputf;
my $input;
my $output;

if ($nargs >= 1)
{ 
	$script = $ARGV[0]; 
	$inputf = $ARGV[1];
	$outputf = $ARGV[2];
} 
else
{
	print "Script ? ";
	$script = <STDIN>;
	chomp $script;

	print "Input file ? ";
	$inputf = <STDIN>;
	chomp $inputf;
	
	print "Output file ? ";
	$outputf = <STDIN>;
	chomp $outputf;
}

open SCRIPT, $script or die "$script: $!\n";

if (($inputf eq '') or ($inputf eq '-'))
{
	$input = *STDIN;
}
else
{
	open INPUT, $inputf or die "$inputf: $!\n";
	$input = *INPUT;
}

if (($outputf eq '') or ($outputf eq '-'))
{
	$output = *STDOUT;
}
else
{
	open OUTPUT, ">$outputf" or die "$outputf: $!\n";
	$output = *OUTPUT;
}
 

my @mem = ();
my $adr = 0;
my $state = 'normal';

# print "Reading code...\n";
while (<SCRIPT>)
{
	if ($trace != 0) { print $_; }
	@chars = split //, $_;
	foreach $char (@chars)
	{
		$mem[$adr++] = ord $char;				
	}
}
# print (sprintf "program size: %X\n", $adr);

my $goon = 1;
my $pc = 0;
my $r0 = 0;
my $r1 = 0;
my $rc = $adr;
my $t;
my $instr;
$state = 'normal';

# print "Running...\n";
while (($goon != 0) and ($pc < 30000))
{
	$instr = chr($mem[$pc++]);
	if ($trace & 1) { print $instr; }

	if ($trace & 2) { print ((sprintf "\nr0=%4X\tr1=%4X\trc=%4X\tpc=%4X\tinstr=%s ",$r0,$r1,$rc,$pc,$instr) . (ord $instr) . " "); my $r = <STDIN>; }

	if ($state eq 'code') 
	{
		if ($instr eq '}') { $state = 'normal'; }
		else { $mem[$rc++] = ord $instr; }
	}
	elsif ($instr eq ',') { $r1 = $r0; }
	elsif ($instr eq '^') { $r0 = $pc; }
	elsif ($instr eq 'Q') { $goon = 0; }
	elsif ($instr eq '?') { if ($r1 == 0) { $r1 = $pc; $pc = $r0; } }
	elsif ($instr eq 'R') { $r0 = $mem[$r0]; }
	elsif ($instr eq 'W') { $mem[$r0] = $r1; }
	elsif ($instr eq 'r') { $r0 = $mem[$r0]; }
	elsif ($instr eq 'w') { $mem[$r0] = $r1; }
	elsif ($instr eq '#') { $r0 = 0; }

	elsif ($instr eq '0') { $r0 = $r0*16; }
	elsif ($instr eq '1') { $r0 = $r0*16+1; }
	elsif ($instr eq '2') { $r0 = $r0*16+2; }
	elsif ($instr eq '3') { $r0 = $r0*16+3; }
	elsif ($instr eq '4') { $r0 = $r0*16+4; }
	elsif ($instr eq '5') { $r0 = $r0*16+5; }
	elsif ($instr eq '6') { $r0 = $r0*16+6; }
	elsif ($instr eq '7') { $r0 = $r0*16+7; }
	elsif ($instr eq '8') { $r0 = $r0*16+8; }
	elsif ($instr eq '9') { $r0 = $r0*16+9; }
	elsif ($instr eq 'A') { $r0 = $r0*16+10; }
	elsif ($instr eq 'B') { $r0 = $r0*16+11; }
	elsif ($instr eq 'C') { $r0 = $r0*16+12; }
	elsif ($instr eq 'D') { $r0 = $r0*16+13; }
	elsif ($instr eq 'E') { $r0 = $r0*16+14; }
	elsif ($instr eq 'F') { $r0 = $r0*16+15; }

	elsif ($instr eq '~') { $r0 = !$r0; }
	elsif ($instr eq '+') { $r0 = $r0 + $r1; }
	elsif ($instr eq '-') { $r0 = $r0 - $r1; }
	elsif ($instr eq '*') { $r0 = $r0 * $r1; }
	elsif ($instr eq '/') { $r0 = $r0 / $r1; }
	elsif ($instr eq '%') { $r0 = $r0 % $r1; }
	elsif ($instr eq '&') { $r0 = $r0 & $r1; }
	elsif ($instr eq '|') { $r0 = $r0 | $r1; }
	elsif ($instr eq '<') { $r0 = $r0 << $r1; }
	elsif ($instr eq '>') { $r0 = $r0 >> $r1; }

	elsif ($instr eq 'G') { if (eof($input)) { $r0 = -1; } else { $r0 = ord getc($input); } }
	elsif ($instr eq 'P') { print $output chr($r0); }
	elsif ($instr eq 'H') { $rc = $r0; }
	elsif ($instr eq 'h') { $r0 = $rc; }
	elsif ($instr eq '{') { $state = 'code'; }
	elsif ($instr eq '}') { $mem[$rc++] = ord $instr; }
	elsif ($instr eq '_') { $mem[$rc++] = $r0; }

	elsif ($instr eq 'T') { $trace = 2; }
  	elsif ($instr eq 't') { $trace=1; } 
	elsif ($instr eq 'e') { print "\nError\n"; $goon = 0; }

}

# print "\nDone.\n";


