
#include <stdio.h>

main (int argc, char **argv)
{
FILE *script;
FILE *input;
FILE *output;

#define MEMSIZE 0x3000
union
{
 char c[4*MEMSIZE];
 int i[MEMSIZE];
} mem;

int adr;
char c;
int goon;
int trace;
char instr;
int pc, r0, r1, rc;
int state;
#define RUN 0
#define CODE 1
char buf[1000];


	script = fopen (argv[1], "r");
	if (script == NULL)
	{
		perror (argv[1]);
		exit(0);
	}
	if ((argc < 3) || !strcmp (argv[2], "-"))
		input = stdin;
	else
	{
		input = fopen (argv[2], "r");
		if (input == NULL)
		{
			perror (argv[2]);
			exit(0);
		}
	}
	if ((argc < 4) || !strcmp (argv[3], "-"))
		output = stdout;
	else
	{
		output = fopen (argv[3], "w");
		if (output == NULL)
		{
			perror (argv[3]);
			exit(0);
		}
	}

	adr = 0;
	while (!feof(script))
	{
		c = fgetc (script);
		mem.c[adr++] = c;
	}

	trace = 0;
	goon = 1;
	pc = 0;
	r0 = 0;
	r1 = 0;
	rc = adr;

	/* printf ("Running...\n"); */
	while (goon)
	{
		instr = mem.c[pc++];
		if (trace & 1) putchar(instr);
		if (trace & 2)
		{
			printf ("\nR0=%4X\tR1=%4X\tRC=%4X\tPC=%4X\tinstr=%c ",
				r0, r1, rc, pc, instr);
	printf ("%X ",mem.c[0x2000]);
			gets(buf);
		}
		if (state == CODE)
		{
			if (instr == '}')
				state = RUN;
			else
				mem.c[rc++] = instr;
		}
		else switch (instr)
		{
			case ',': r1 = r0; break;
			case '^': r0 = pc; break;
			case 'Q': goon = 0; break;
			case '?': if (r1 == 0) { r1 = pc; pc = r0; } break;
			case 'R': r0 = mem.i[r0>>2]; break;
			case 'W': mem.i[r0>>2] = r1; break;
			case 'r': r0 = mem.c[r0]; break;
			case 'w': mem.c[r0] = r1; break;
			case '#': r0 = 0; break;

			case '0': r0 = r0*16; break;
			case '1': r0 = r0*16+1; break;
			case '2': r0 = r0*16+2; break;
			case '3': r0 = r0*16+3; break;
			case '4': r0 = r0*16+4; break;
			case '5': r0 = r0*16+5; break;
			case '6': r0 = r0*16+6; break;
			case '7': r0 = r0*16+7; break;
			case '8': r0 = r0*16+8; break;
			case '9': r0 = r0*16+9; break;
			case 'A': r0 = r0*16+10; break;
			case 'B': r0 = r0*16+11; break;
			case 'C': r0 = r0*16+12; break;
			case 'D': r0 = r0*16+13; break;
			case 'E': r0 = r0*16+14; break;
			case 'F': r0 = r0*16+15; break;

			case '~': r0 = ~r0; break;
			case '+': r0 = r0 + r1; break;
			case '-': r0 = r0 - r1; break;
			case '*': r0 = r0 * r1; break;
			case '/': r0 = r0 / r1; break;
			case '%': r0 = r0 % r1; break;
			case '&': r0 = r0 & r1; break;
			case '|': r0 = r0 | r1; break;
			case '<': r0 = r0 << r1; break;
			case '>': r0 = r0 >> r1; break;

			case 'G': if (feof(input)) r0 = -1; else r0 = fgetc(input); break;
			case 'P': fputc (r0, output); break;
			case 'H': rc = r0; break;
			case 'h': r0 = rc; break;
			case '{': state = CODE; break;
			case '}': mem.c[rc++] = instr; break;
			case '_': mem.c[rc++] = r0; break;
			case 'T': trace = 2; break;
			case 't': trace = 1; break;
			case 'e': printf ("\nError\n"); goon = 0; break;
			default: break;
		}
	}
}
